﻿namespace Pwc.vProfile.Core
{
    public static class BussTypeEnum
    {
        public   const string User = "user";
        public   const string Role = "role";
        public const string Group = "group";
    }
}
