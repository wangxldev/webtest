﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core
{
    public static class ProfileClaimTypes
    {
        public static string TenantId { get; } = "tid";

        public static string UserId { get; } = "uid";

        public static string Email { get; } = "email";

        public static string SignId { get; } = "sid";

        public static string UserName { get; } = "name";
    }
}
