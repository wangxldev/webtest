﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp;
using Pwc.vProfile.Core.Auth.Roles;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Configuration
{

    public class AuthEntityTypes : IAuthEntityTypes
    {

        public Type User
        {
            get { return _user; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException(nameof(value));
                }

                if (!typeof(User).IsAssignableFrom(value))
                {
                    throw new AbpException(value.AssemblyQualifiedName + " should be derived from " + typeof(User).AssemblyQualifiedName);
                }

                _user = value;
            }
        }
        private Type _user;

        public Type Role
        {
            get { return _role; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException(nameof(value));
                }

                if (!typeof(Role).IsAssignableFrom(value))
                {
                    throw new AbpException(value.AssemblyQualifiedName + " should be derived from " + typeof(Role).AssemblyQualifiedName);
                }

                _role = value;
            }
        }
        private Type _role;

        public Type Tenant { get; set; }
    }
}
