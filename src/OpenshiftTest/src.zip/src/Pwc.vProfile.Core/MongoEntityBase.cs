﻿using Abp.Domain.Entities;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Pwc.vProfile.Core
{
    //public class MongoEntityBase : MongoEntityBase<ObjectId>
    //{
    //    [BsonId]
    //    public ObjectId Id { get; set; }
    //}

    //public class MongoEntityBase<T> : Entity<T>
    //{
    //    public new T Id { get; set; }
    //}


    public class MongoEntityBase : IEntity<ObjectId>
    {
        public bool IsTransient()
        {
            return false;
        }

        [BsonId]
        [BsonIgnoreIfDefault]
        public ObjectId Id { get; set; }
    }

    public class MongoEntityBase<T> : Entity<T>
    {
        [BsonId]
        public new T Id { get; set; }
    }
}
