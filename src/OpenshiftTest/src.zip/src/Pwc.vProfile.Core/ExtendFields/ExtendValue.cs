﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.ExtendFields
{
    public class ExtendValue
    {
        public string FieldId { get; set; }

        public string Value { get; set; }
    }
}
