﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Pwc.vProfile.Core.ExtendFields
{
    [Table("tnt_extend_fields")]
    public class ExtendField: MongoEntityBase
    {
        public const string CollectionName = "tnt_extend_fields";

        public string Label { get; set; }

        public string Name { get; set; }

        public bool IsRequired { get; set; }

        /// <summary>
        /// 业务类型判断
        /// <see cref="BussTypeEnum"/>
        /// </summary>
        public string BussType { get; set; }

        public int Order { get; set; }

        public string Type { get; set; }

        public List<string>  Scope { get; set; }

        public string DefaultValue { get; set; }

    }
}
