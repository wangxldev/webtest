﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Pwc.vProfile.Core.ExtendFields
{
    public interface IExtendFieldManager
    {
        Task<List<string>> GetBussTypeList();
        Task Add(ExtendField extendField);
        Task<List<ExtendField>> GetListAll();
        Task<List<ExtendField>> GetList(string name,string bussType);
        Task<List<ExtendField>> GetListByBussType( string bussType);

        Task Update(ExtendField extendField);

        Task UpdateList(List<ExtendField> extendFieldList);

        Task Delete(string name, string bussType);

        Task DeleteAll();
    }
}
