﻿using Abp.Configuration;
using Abp.Dependency;
using Abp.Runtime.Caching;
using Abp.UI;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Data.TenantDb;
using Pwc.vProfile.Utility;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Pwc.vProfile.Core.ExtendFields
{
    public class ExtendFieldManager : IExtendFieldManager, ITransientDependency
    {
        private readonly ITenantDbContext _tenantDbContext;
        private readonly ICacheManager _cacheManager;
        private readonly ISettingManager _settingManager;
        public ExtendFieldManager(ITenantDbContext tenantDbContext,
            ICacheManager cacheManager, 
            ISettingManager settingManager)
        {
            _tenantDbContext = tenantDbContext;
            _cacheManager = cacheManager;
            _settingManager = settingManager;
        }
        public IMongoCollection<ExtendField> Collection => _tenantDbContext.DbSet<ExtendField>(ExtendField.CollectionName);
        public async Task Add(ExtendField extendField)
        {
            var existExtendField = await Collection.Find(_ => _.Name == extendField.Name&&_.BussType== extendField.BussType).FirstOrDefaultAsync();
            if (existExtendField != null)
            {
                throw new UserFriendlyException("The same extend Field is exist!");
            }
            await Collection.InsertOneAsync(extendField);

        }
        public  async  Task<List<string>>  GetBussTypeList()
        {
            string bussTypeCacheKey = string.Format("{0}_{1}","TenantCode",CacheKeys.BussType);

            return await _cacheManager
                        .GetCache("ExtendFieldManager")
                        .GetAsync(bussTypeCacheKey,() => Task.Run(() =>
                        {
                            return GetBussTypeListFromEnum();
                        }));

            //List<string> bussTypeList = new List<string>();
            //Type t = typeof(BussTypeEnum);
            //FieldInfo[] fields = t.GetFields(BindingFlags.Public);

            //foreach (FieldInfo fi in fields)
            //{
            //    Console.WriteLine(fi.Name);
            //    bussTypeList.Add(fi.GetValue(null).ToString());
            //}
            //return bussTypeList;
        }
        private List<string> GetBussTypeListFromEnum()
        {
            List<string> bussTypeList = new List<string>();
            Type t = typeof(BussTypeEnum);
            //FieldInfo[] fields = t.GetFields(BindingFlags.Public);
            FieldInfo[] fields = t.GetFields( );

            foreach (FieldInfo fi in fields)
            {
                //Console.WriteLine(fi.Name);
                bussTypeList.Add(fi.GetValue(null).ToString());
            }
            return bussTypeList;
        }
        public async Task<List<ExtendField>> GetListAll()
        {
            return await Collection.Find(Builders<ExtendField>.Filter.Empty).ToListAsync();
        }
        public async Task<List<ExtendField>> GetList(string name,string bussType)
        {
            var filter = Builders<ExtendField>.Filter.And(
                    Builders<ExtendField>.Filter.Eq(u => u.BussType, bussType),
                    Builders<ExtendField>.Filter.Regex(u => u.Name, new BsonRegularExpression(name, "i"))
                );

            var extendFieldList = await Collection.Find(filter).ToListAsync();
            return extendFieldList;
        }
        public async Task<List<ExtendField>> GetListByBussType(string bussType)
        {
            var extendFieldList = await Collection.Find(_=>_.BussType== bussType).ToListAsync();
            return extendFieldList;
        }
        public async Task Update(ExtendField extendField)
        {
            var filter = Builders<ExtendField>.Filter.And(
                Builders<ExtendField>.Filter.Eq(u => u.Name, extendField.Name),
                Builders<ExtendField>.Filter.Eq(u => u.BussType, extendField.BussType)
            );

            var update = Builders<ExtendField>.Update.Combine(
                   Builders<ExtendField>.Update.Set(u => u.DefaultValue, extendField.DefaultValue),
                   Builders<ExtendField>.Update.Set(u => u.IsRequired, extendField.IsRequired),
                   Builders<ExtendField>.Update.Set(u => u.Label, extendField.Label),
                   Builders<ExtendField>.Update.Set(u => u.Order, extendField.Order),
                   Builders<ExtendField>.Update.Set(u => u.Scope, extendField.Scope),
                   Builders<ExtendField>.Update.Set(u => u.Type, extendField.Type)
            );

            await Collection.UpdateOneAsync( filter,  update);
        }

        public async Task UpdateList(List<ExtendField> extendFieldList)
        {
            foreach (var ef in extendFieldList)
            {
                await Update(ef);
            }
        }

        public async Task Delete(string name,string bussType)
        {
            await Collection.DeleteOneAsync(item => item.Name == name&&item.BussType== bussType);
        }

        public async Task DeleteAll()
        {
            await Collection.DeleteManyAsync(Builders<ExtendField>.Filter.Empty);
        }

         
    }
}
