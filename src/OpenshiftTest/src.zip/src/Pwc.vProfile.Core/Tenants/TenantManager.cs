﻿using Abp.Dependency;
using Pwc.vProfile.Data.Seed;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.UI;
using Pwc.vProfile.Data;
using MongoDB.Driver;
using Microsoft.Extensions.Logging;
using Pwc.vProfile.Data.Seed.Tenants;
using Pwc.vProfile.Utility;

namespace Pwc.vProfile.Core.Tenants
{
    public class TenantManager: ITenantManager, ITransientDependency
    {
        private readonly IProfileDbContext _dbContext;
        private readonly ILogger<TenantManager> _logger;

        public TenantManager(IProfileDbContext dbContext,ILogger<TenantManager> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }
        public IMongoCollection<Tenant> Collection => _dbContext.DbSet<Tenant>(Tenant.CollectionName);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectString">mongodb://localhost:27020/mydb</param>
        /// <param name="dbName">equal tenant name</param>
        /// <returns></returns>
        //public void InitTenantDb(string connectString, string dbName)
        public async Task InitTenantDb(Tenant tenant)
        {
            try
            {
                SeedHelper.SeedTenantDb(tenant.DbConnStr,tenant.FullName.Trim());
                await Add(tenant);
                //add user and role
            }
            catch(Exception ex)
            {
                _logger.LogInformation(ex.Message);
                throw new UserFriendlyException("create tenant failed!");
            }
            
        }
        public async Task Add(Tenant tenant)
        {
            //update user and password
            var preConnectionString = tenant.DbConnStr;

            var hostInfoArray = preConnectionString.Split('@');
            if (hostInfoArray.Length < 2)
            {
                throw new UserFriendlyException("invalid mongodb connect string");
            }
            var hostInfo = hostInfoArray[1];
            var defaultAdmin = string.Format("{0}_{1}", tenant.FullName.Trim(), TenantDefault.Admin);
            var defaultPassword = RandomGenerator.RandomStringByText(tenant.FullName.Trim(), TenantDefault.PasswordLength);
            var updatedConnectionString = string.Format("mongodb://{0}:{1}@{2}", defaultAdmin, defaultPassword, hostInfo);

            var updatedConnectionStringWithDbNameArray = updatedConnectionString.Split('?');
            if (updatedConnectionStringWithDbNameArray.Length < 2)
            {
                throw new UserFriendlyException("invalid mongodb connect string,...localhost:29033/?replicaSet=... the '?' is needed");
            }
            string updatedConnectionStringWithDbName = string.Format("{0}{1}?{2}", updatedConnectionStringWithDbNameArray[0], tenant.FullName.Trim(), updatedConnectionStringWithDbNameArray[1]);

            tenant.DbConnStr = updatedConnectionStringWithDbName;
            await Collection.InsertOneAsync(tenant);
        }
        public async Task UpdateGroupRule(Tenant tenant)
        {
            var filter = Builders<Tenant>.Filter.And(
                Builders<Tenant>.Filter.Eq(u => u.Name, tenant.Name)
            );


            var update = Builders<Tenant>.Update.Set(u => u.Name, tenant.Name)  ;

            await Collection.UpdateOneAsync( filter, update);
        }
    }
}
