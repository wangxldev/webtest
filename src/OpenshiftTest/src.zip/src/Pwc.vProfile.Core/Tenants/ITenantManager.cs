﻿using Abp.Dependency;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Pwc.vProfile.Core.Tenants
{
    public interface ITenantManager
    {
        Task InitTenantDb(Tenant tenant);

        Task Add(Tenant tenant);

        Task UpdateGroupRule(Tenant tenant);
    }
}
