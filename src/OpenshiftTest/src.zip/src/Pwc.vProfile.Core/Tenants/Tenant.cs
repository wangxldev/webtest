﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Pwc.vProfile.Core.Tenants
{
    [Table("tnt_tenants")]
    public class Tenant:MongoEntityBase
    {
        public const string CollectionName = "tnt_tenants";

        public string Name { get; set; }

        public string FullName { get; set; }

        public string LogoUrl { get; set; }

        public string DbConnStr { get; set; }

        /// <summary>
        /// <see cref="AuthTypeEnum"/>
        /// </summary>
        public string AuthType { get; set; }

        public bool AllowRegister { get; set; }

        public string SecretKey { get; set; }

        public string LdapPath { get; set; }

        public string GroupRule { get; set; }

    }
}
