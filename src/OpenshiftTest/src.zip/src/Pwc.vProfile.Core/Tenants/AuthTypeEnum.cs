﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Tenants
{
    /// <summary>
    /// tenant auth type enum
    /// </summary>
    public static class AuthTypeEnum
    {
        public const string EmailPwd = "email_pwd";
        public const string EmailGuid = "email_guid";
        public const string Ldap = "ldap";
        public const string idAM = "idAM";
    }
}
