﻿using Abp;
using Abp.AutoMapper;
using Abp.Dependency;
using Abp.Modules;
using Abp.Reflection.Extensions;
using IdentityServer4.Models;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Serializers;
using Pwc.vProfile.Core.Auth.Ids;
using Pwc.vProfile.Core.Auth.Permissions;

namespace Pwc.vProfile.Core
{
    [DependsOn(
        typeof(AbpKernelModule),
        typeof(AbpAutoMapperModule))
    ]
    public class ProfileCoreModule:AbpModule
    {
        public override void PreInitialize()
        {
            BsonSerializer.RegisterSerializer(DateTimeSerializer.UtcInstance);

            Configuration.Authorization.Providers.Add<AppAuthProvider>();

            Configuration.Modules.AbpAutoMapper().Configurators.Add(config =>
            {
                //PersistedGrant -> PersistedGrantEntity
                config.CreateMap<PersistedGrant, IdsGrant>()
                    .ForMember(d => d.Id, c => c.MapFrom(s => s.Key));

                //PersistedGrantEntity -> PersistedGrant
                config.CreateMap<IdsGrant, PersistedGrant>()
                    .ForMember(d => d.Key, c => c.MapFrom(s => s.Id));
            });

            IocManager.Register<Ids4TokenHelper>(DependencyLifeStyle.Singleton);
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ProfileCoreModule).GetAssembly());
        }

        public override void PostInitialize()
        {

        }
    }
}
