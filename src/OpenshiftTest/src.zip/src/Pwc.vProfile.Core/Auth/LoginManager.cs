﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Abp.Configuration;
using Abp.Dependency;
using Abp.Domain.Repositories;
using Abp.Domain.Uow;
using Abp.Extensions;
using Abp.Timing;
using Microsoft.AspNetCore.Identity;
using Pwc.vProfile.Core.Auth.Roles;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Auth
{
    public class LogInManager: ITransientDependency
    {
        public LogInManager(
           UserManager userManager,
           ISettingManager settingManager,
//           IRepository<UserLoginAttempt, long> userLoginAttemptRepository,
           IIocResolver iocResolver,
           IPasswordHasher<User> passwordHasher,
           RoleManager roleManager,
           UserClaimsPrincipalFactory claimsPrincipalFactory)
        {
            _passwordHasher = passwordHasher;
            _claimsPrincipalFactory = claimsPrincipalFactory;
            SettingManager = settingManager;
//            UserLoginAttemptRepository = userLoginAttemptRepository;
            IocResolver = iocResolver;
            RoleManager = roleManager;
            UserManager = userManager;
        }

        protected IUnitOfWorkManager UnitOfWorkManager { get; }
        protected UserManager UserManager { get; }
        protected ISettingManager SettingManager { get; }
//        protected IRepository<UserLoginAttempt, long> UserLoginAttemptRepository { get; }
        protected IIocResolver IocResolver { get; }
        protected RoleManager RoleManager { get; }

        private readonly IPasswordHasher<User> _passwordHasher;

        private readonly UserClaimsPrincipalFactory _claimsPrincipalFactory;

        [UnitOfWork]
        public virtual async Task<LogInResult> LoginAsync(UserLoginInfo login)
        {
            var result = await LoginAsyncInternal(login);
//            await SaveLoginAttempt(result, login.ProviderKey + "@" + login.LoginProvider);
            return result;
        }

        protected virtual async Task<LogInResult> LoginAsyncInternal(UserLoginInfo login)
        {
            //            if (login == null || login.LoginProvider.IsNullOrEmpty() || login.ProviderKey.IsNullOrEmpty())
            //            {
            //                throw new ArgumentException("login");
            //            }
            //
            //
            //            var user = await UserManager.UserStore.FindAsync(login);
            //            if (user == null)
            //            {
            //                return new LogInResult(LogInResultTypeEnum.UnknownExternalLogin);
            //            }
            //
            //            return await CreateLoginResultAsync(user);

            throw new NotImplementedException();
        }

        [UnitOfWork]
        public virtual async Task<LogInResult> LoginAsync(string loginName, string plainPassword, bool shouldLockout = true)
        {
            var result = await LoginAsyncInternal(loginName, plainPassword, shouldLockout);
//            await SaveLoginAttempt(result, loginName);
            return result;
        }

        protected virtual async Task<LogInResult> LoginAsyncInternal(string userNameOrEmailAddress, string plainPassword, bool shouldLockout)
        {
            if (userNameOrEmailAddress.IsNullOrEmpty())
            {
                throw new ArgumentNullException(nameof(userNameOrEmailAddress));
            }

            if (plainPassword.IsNullOrEmpty())
            {
                throw new ArgumentNullException(nameof(plainPassword));
            }


                //                await UserManager.InitializeOptionsAsync();

            var user = await UserManager.UserStore.FindByNameOrEmailAsync(userNameOrEmailAddress);
            if (user == null)
            {
                return new LogInResult(LogInResultTypeEnum.InvalidUserNameOrEmailAddress);
            }

            if (await UserManager.IsLockedOutAsync(user))
            {
                return new LogInResult(LogInResultTypeEnum.LockedOut, user);
            }

            if (!await UserManager.CheckPasswordAsync(user, plainPassword))
            {
                if (shouldLockout)
                {
                    if (await TryLockOutAsync(user.SeqId))
                    {
                        return new LogInResult(LogInResultTypeEnum.LockedOut, user);
                    }
                }

                return new LogInResult(LogInResultTypeEnum.InvalidPassword, user);
            }

            // 设置signin token
            user.SetSignInToken();
            // 更新用户与登录相关的信息
            await UserManager.UpdateUserByLogin(user);

            return await CreateLoginResultAsync(user);

        }

        protected virtual async Task<LogInResult> CreateLoginResultAsync(User user)
        {
            if (!user.IsActive)
            {
                return new LogInResult(LogInResultTypeEnum.UserIsNotActive);
            }

            user.LastLoginTime = Clock.Now;

            // TODO 更新用户登录时间

            var principal = await _claimsPrincipalFactory.CreateAsync(user);

            return new LogInResult(
                user,
                principal.Identity as ClaimsIdentity
            );
        }

        protected virtual async Task<bool> TryLockOutAsync(long userId)
        {
            var user = await UserManager.FindByIdAsync(userId.ToString());

            (await UserManager.AccessFailedAsync(user)).CheckErrors();

            var isLockOut = await UserManager.IsLockedOutAsync(user);

            return isLockOut;
        }
    }
}
