﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Pwc.vProfile.Core.Auth.Permissions;
using Pwc.vProfile.Core.Auth.Roles;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Auth
{
    public static class IdentityRegistrar
    {

        public static void Register(IServiceCollection services)
        {
            services.AddLogging();

            services.AddProfileIdentity<User, Role>(null)
                .AddProfileRoleManager<RoleManager>()
                .AddProfileUserManager<UserManager>()
                .AddProfileSignInManager<SignInManager>()
                .AddProfileLogInManager<LogInManager>()
                .AddProfileUserClaimsPrincipalFactory<UserClaimsPrincipalFactory>()
                .AddProfileSecurityStampValidator<SecurityStampValidator>()
                .AddPermissionChecker<PermissionChecker>()
                .AddUserStore<UserStore>()
                .AddRoleStore<RoleStore>()
                .AddDefaultTokenProviders();
        }
    }
}
