﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Abp.Dependency;
using Abp.Domain.Uow;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Pwc.vProfile.Core.Auth.Roles;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Auth
{
    public class UserClaimsPrincipalFactory: UserClaimsPrincipalFactory<User, Role>, ITransientDependency
    {
        public UserClaimsPrincipalFactory(
            UserManager userManager,
            RoleManager roleManager,
            IOptions<IdentityOptions> options)
            : base(userManager, roleManager, options)
        {
        }

        public override async Task<ClaimsPrincipal> CreateAsync(User user)
        {
            //            var principal = await base.CreateAsync(user);

            //            var principal=new ClaimsPrincipal(new ClaimsIdentity(new []
            //            {
            //                new Claim(ProfileClaimTypes.TenantId,"1000"), 
            //                new Claim(ProfileClaimTypes.UserId,user.SeqId.ToString()), 
            //                new Claim(ProfileClaimTypes.Email,user.Email), 
            //                new Claim(ProfileClaimTypes.UserName,user.UserName),
            //            }));


            var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
            {
                new Claim(ProfileClaimTypes.TenantId,"1000"),
                new Claim(ClaimTypes.NameIdentifier,user.SeqId.ToString()),
                new Claim(ClaimTypes.Email,user.Email),
                new Claim(ClaimTypes.Name,user.UserName),
            }, CookieAuthenticationDefaults.AuthenticationScheme));

            return principal;
        }
    }
}
