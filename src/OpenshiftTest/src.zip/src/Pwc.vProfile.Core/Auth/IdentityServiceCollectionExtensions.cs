﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Pwc.vProfile.Core.Auth.Roles;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.Core.Configuration;

namespace Pwc.vProfile.Core.Auth
{
    public static class IdentityServiceCollectionExtensions
    {
        public static IdentityBuilder AddProfileIdentity<TUser, TRole>(this IServiceCollection services, Action<IdentityOptions> setupAction)
        where TRole : Role, new()
        where TUser : User
        {
            services.AddSingleton<IAuthEntityTypes>(new AuthEntityTypes
            {
                Role = typeof(TRole),
                User = typeof(TUser)
            });

            //AbpTenantManager
            //            services.TryAddScoped<AbpTenantManager<TTenant, TUser>>();

            //AbpEditionManager
            //            services.TryAddScoped<AbpEditionManager>();

            //AbpRoleManager
            services.TryAddScoped<RoleManager>();
            services.TryAddScoped(typeof(RoleManager<TRole>), provider => provider.GetService(typeof(RoleManager)));

            //AbpUserManager
            services.TryAddScoped<UserManager>();
            services.TryAddScoped(typeof(UserManager<TUser>), provider => provider.GetService(typeof(UserManager)));

            //SignInManager
//            services.TryAddScoped<AuthSignInManager>();
//            services.TryAddScoped(typeof(SignInManager<TUser>), provider => provider.GetService(typeof(AuthSignInManager)));

            //AbpLogInManager
//            services.TryAddScoped<AuthLogInManager>();

            //AbpUserClaimsPrincipalFactory
//            services.TryAddScoped<AuthUserClaimsPrincipalFactory>();
//            services.TryAddScoped(typeof(UserClaimsPrincipalFactory<TUser, TRole>), provider => provider.GetService(typeof(AuthUserClaimsPrincipalFactory)));
//            services.TryAddScoped(typeof(IUserClaimsPrincipalFactory<TUser>), provider => provider.GetService(typeof(AuthUserClaimsPrincipalFactory)));

            //AbpSecurityStampValidator
            services.TryAddScoped<SecurityStampValidator>();
            services.TryAddScoped(typeof(SecurityStampValidator<TUser>), provider => provider.GetService(typeof(SecurityStampValidator)));
            services.TryAddScoped(typeof(ISecurityStampValidator), provider => provider.GetService(typeof(SecurityStampValidator)));

            //PermissionChecker
            //            services.TryAddScoped<PermissionChecker<TRole, TUser>>();
            //            services.TryAddScoped(typeof(IPermissionChecker), provider => provider.GetService(typeof(PermissionChecker<TRole, TUser>)));

            //AbpUserStore
            services.TryAddScoped<UserStore>();
            services.TryAddScoped(typeof(IUserStore<TUser>), provider => provider.GetService(typeof(UserStore)));

            //AbpRoleStore
            services.TryAddScoped<RoleStore>();
            services.TryAddScoped(typeof(IRoleStore<TRole>), provider => provider.GetService(typeof(RoleStore)));

            //AbpFeatureValueStore
            //            services.TryAddScoped<AbpFeatureValueStore<TTenant, TUser>>();
            //            services.TryAddScoped(typeof(IFeatureValueStore), provider => provider.GetService(typeof(AbpFeatureValueStore<TTenant, TUser>)));

            services.AddIdentity<TUser, TRole>(setupAction);

            return new IdentityBuilder(typeof(TUser),typeof(TRole), services);
        }
    }
}
