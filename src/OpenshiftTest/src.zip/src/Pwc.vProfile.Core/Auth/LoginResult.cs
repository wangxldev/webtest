﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Auth
{
    public class LogInResult
    {
        public LogInResult(LogInResultTypeEnum result, User user = null)
        {
            Result = result;
            User = user;
        }

        public LogInResult(User user, ClaimsIdentity identity)
            : this(LogInResultTypeEnum.Success)
        {
            User = user;
            Identity = identity;
        }

        public LogInResultTypeEnum Result { get; private set; }

        public User User { get; private set; }

        public ClaimsIdentity Identity { get; private set; }
    }
}
