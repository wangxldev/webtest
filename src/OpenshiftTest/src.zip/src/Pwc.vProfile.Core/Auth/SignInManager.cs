﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Abp.Configuration;
using Abp.Dependency;
using Abp.Domain.Uow;
using Abp.Extensions;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Auth
{
    public class SignInManager : SignInManager<User>, ITransientDependency
    {
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly ISettingManager _settingManager;

        public SignInManager(
            UserManager userManager,
            IHttpContextAccessor contextAccessor,
            UserClaimsPrincipalFactory claimsFactory,
            IOptions<IdentityOptions> optionsAccessor,
            ILogger<SignInManager> logger,
            IAuthenticationSchemeProvider schemes,
            IUnitOfWorkManager unitOfWorkManager,
            ISettingManager settingManager)
            : base(
                userManager,
                contextAccessor,
                claimsFactory,
                optionsAccessor,
                logger,
                schemes)
        {
            _unitOfWorkManager = unitOfWorkManager;
            _settingManager = settingManager;
        }

        public virtual async Task<SignInResult> SignInOrTwoFactorAsync(LogInResult logInResult, bool isPersistent, bool? rememberBrowser = null, string loginProvider = null, bool bypassTwoFactor = false)
        {
            if (logInResult.Result != LogInResultTypeEnum.Success)
            {
                throw new ArgumentException("logInResult.Result should be success in order to sign in!");
            }


//                await UserManager.As<AbpUserManager<TRole, TUser>>().InitializeOptionsAsync(logInResult.Tenant?.Id);
//
//                if (!bypassTwoFactor && IsTrue(AbpZeroSettingNames.UserManagement.TwoFactorLogin.IsEnabled, logInResult.Tenant?.Id))
//                {
//                    if (await UserManager.GetTwoFactorEnabledAsync(logInResult.User))
//                    {
//                        if ((await UserManager.GetValidTwoFactorProvidersAsync(logInResult.User)).Count > 0)
//                        {
//                            if (!await IsTwoFactorClientRememberedAsync(logInResult.User) || rememberBrowser == false)
//                            {
//                                await Context.SignInAsync(
//                                    IdentityConstants.TwoFactorUserIdScheme,
//                                    StoreTwoFactorInfo(logInResult.User, loginProvider)
//                                );
//
//                                return SignInResult.TwoFactorRequired;
//                            }
//                        }
//                    }
//                }

                if (loginProvider != null)
                {
                    await Context.SignOutAsync(IdentityConstants.ExternalScheme);
                }

                await SignInAsync(logInResult.User, isPersistent, loginProvider);
                return SignInResult.Success;
        }

        public virtual async Task SignOutAndSignInAsync(ClaimsIdentity identity, bool isPersistent, String schema = null)
        {
            if (schema.IsNullOrWhiteSpace())
            {
                schema = IdentityConstants.ApplicationScheme;
            }
            await SignOutAsync();
            await SignInAsync(identity, isPersistent, schema);
        }

        public virtual async Task SignInAsync(ClaimsIdentity identity, bool isPersistent, String schema = null)
        {
            if (schema.IsNullOrWhiteSpace())
            {
                schema = IdentityConstants.ApplicationScheme;
            }

            await Context.SignInAsync(schema,
                new ClaimsPrincipal(identity),
                new Microsoft.AspNetCore.Authentication.AuthenticationProperties { IsPersistent = isPersistent }
            );

        }

        [UnitOfWork]
        public override Task SignInAsync(User user, bool isPersistent, string authenticationMethod = null)
        {
            return base.SignInAsync(user, isPersistent, authenticationMethod);
        }

        protected virtual ClaimsPrincipal StoreTwoFactorInfo(User user, string loginProvider)
        {
            var identity = new ClaimsIdentity(IdentityConstants.TwoFactorUserIdScheme);

            identity.AddClaim(new Claim(ClaimTypes.Name, user.Id.ToString()));

            if (loginProvider != null)
            {
                identity.AddClaim(new Claim(ClaimTypes.AuthenticationMethod, loginProvider));
            }

            return new ClaimsPrincipal(identity);
        }

        public override async Task<bool> IsTwoFactorClientRememberedAsync(User user)
        {
            var result = await Context.AuthenticateAsync(IdentityConstants.TwoFactorRememberMeScheme);

            return result?.Principal != null &&
                   result.Principal.FindFirstValue(ClaimTypes.Name) == user.Id.ToString();
        }

        public override async Task RememberTwoFactorClientAsync(User user)
        {
            var rememberBrowserIdentity = new ClaimsIdentity(IdentityConstants.TwoFactorRememberMeScheme);

            rememberBrowserIdentity.AddClaim(new Claim(ClaimTypes.Name, user.Id.ToString()));

            await Context.SignInAsync(IdentityConstants.TwoFactorRememberMeScheme,
                new ClaimsPrincipal(rememberBrowserIdentity),
                new Microsoft.AspNetCore.Authentication.AuthenticationProperties { IsPersistent = true });
        }

        

        private bool IsTrue(string settingName)
        {
            return _settingManager.GetSettingValueForApplication<bool>(settingName);
        }

    }
}
