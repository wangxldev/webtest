﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Auth.Permissions
{
    public static class AppPermissions
    {
        public const string Tenant = "Tenant";
        public const string Tenant_Admin = "Tenant.Admin";

        public const string Tenant_Admin_Users = "Tenant.Admin.Users";
        public const string Tenant_Admin_Users_Create = "Tenant.Admin.Users.Create";
        public const string Tenant_Admin_Users_Edit = "Tenant.Admin.Users.Edit";
        public const string Tenant_Admin_Users_Delete = "Tenant.Admin.Users.Delete";
        public const string Tenant_Admin_Users_ChangePermissions = "Tenant.Admin.Users.ChangePermissions";
    }
}
