﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.Authorization;
using Abp.Localization;

namespace Pwc.vProfile.Core.Auth.Permissions
{
    public class AppAuthProvider: AuthorizationProvider
    {
        public override void SetPermissions(IPermissionDefinitionContext context)
        {
            var tenant = context.GetPermissionOrNull(AppPermissions.Tenant)??context.CreatePermission(AppPermissions.Tenant, new FixedLocalizableString(AppPermissions.Tenant));

            var admin = tenant.CreateChildPermission(AppPermissions.Tenant_Admin, new FixedLocalizableString(AppPermissions.Tenant_Admin));

            var users = admin.CreateChildPermission(AppPermissions.Tenant_Admin_Users, new FixedLocalizableString(AppPermissions.Tenant_Admin_Users));
            users.CreateChildPermission(AppPermissions.Tenant_Admin_Users_Create, new FixedLocalizableString(AppPermissions.Tenant_Admin_Users_Create));
            users.CreateChildPermission(AppPermissions.Tenant_Admin_Users_Edit, new FixedLocalizableString(AppPermissions.Tenant_Admin_Users_Edit));
            users.CreateChildPermission(AppPermissions.Tenant_Admin_Users_Delete, new FixedLocalizableString(AppPermissions.Tenant_Admin_Users_Delete));
            users.CreateChildPermission(AppPermissions.Tenant_Admin_Users_ChangePermissions, new FixedLocalizableString(AppPermissions.Tenant_Admin_Users_ChangePermissions));
        }
    }
}
