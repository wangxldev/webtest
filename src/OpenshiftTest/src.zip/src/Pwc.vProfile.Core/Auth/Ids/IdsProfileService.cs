﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.Domain.Uow;
using IdentityServer4.AspNetIdentity;
using Microsoft.AspNetCore.Identity;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Auth.Ids
{
    public class IdsProfileService<TUser> : ProfileService<TUser> where TUser : User
    {
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly UserManager<TUser> _userManager;

        public IdsProfileService(
            UserManager<TUser> userManager,
            IUserClaimsPrincipalFactory<TUser> claimsFactory,
            IUnitOfWorkManager unitOfWorkManager
        ) : base(userManager, claimsFactory)
        {
            _unitOfWorkManager = unitOfWorkManager;
            _userManager = userManager;
        }
    }
}
