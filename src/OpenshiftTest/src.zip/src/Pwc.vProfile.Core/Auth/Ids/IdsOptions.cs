﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Pwc.vProfile.Core.Auth.Ids
{
    public class IdsOptions
    {
        /// <summary>
        /// <see cref="JwtSecurityTokenHandler.DefaultInboundClaimTypeMap"/>
        /// Default: true.
        /// </summary>
        public bool UpdateJwtSecurityTokenHandlerDefaultInboundClaimTypeMap { get; set; } = true;

        /// <summary>
        /// <see cref="ClaimTypes"/>
        /// Default: true.
        /// </summary>
        public bool UpdateAuthClaimTypes { get; set; } = true;
    }
}
