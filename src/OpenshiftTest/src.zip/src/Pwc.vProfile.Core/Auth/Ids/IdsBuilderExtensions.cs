﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Abp.Runtime.Security;
using IdentityModel;
using IdentityServer4.Services;
using IdentityServer4.Stores;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Auth.Ids
{
    public static class IdsBuilderExtensions
    {
        public static IIdentityServerBuilder AddIds<TUser>(this IIdentityServerBuilder builder, Action<IdsOptions> optionsAction = null)
            where TUser : User
        {
            var options = new IdsOptions();
            optionsAction?.Invoke(options);

            builder.AddAspNetIdentity<TUser>();

            builder.AddProfileService<IdsProfileService<TUser>>();
            builder.AddResourceOwnerValidator<IdsResourceOwnerPasswordValidator<TUser>>();

            builder.Services.Replace(ServiceDescriptor.Transient<IClaimsService, IdsClaimsService>());

            if (options.UpdateAuthClaimTypes)
            {
                AbpClaimTypes.UserId = JwtClaimTypes.Subject;
                AbpClaimTypes.UserName = JwtClaimTypes.Name;
                AbpClaimTypes.Role = JwtClaimTypes.Role;
            }

            if (options.UpdateJwtSecurityTokenHandlerDefaultInboundClaimTypeMap)
            {
                JwtSecurityTokenHandler.DefaultInboundClaimTypeMap[AbpClaimTypes.UserId] = AbpClaimTypes.UserId;
                JwtSecurityTokenHandler.DefaultInboundClaimTypeMap[AbpClaimTypes.UserName] = AbpClaimTypes.UserName;
                JwtSecurityTokenHandler.DefaultInboundClaimTypeMap[AbpClaimTypes.Role] = AbpClaimTypes.Role;
            }

            return builder;
        }

        public static IIdentityServerBuilder AddIdsPersistedGrants(this IIdentityServerBuilder builder)
        {
            builder.Services.AddTransient<IPersistedGrantStore, IdsPersistedGrantStore>();
            return builder;
        }
    }
}
