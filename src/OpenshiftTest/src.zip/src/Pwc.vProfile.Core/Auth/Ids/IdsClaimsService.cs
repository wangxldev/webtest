﻿using System;
using System.Collections.Generic;
using System.Text;
using IdentityServer4.Services;
using Microsoft.Extensions.Logging;

namespace Pwc.vProfile.Core.Auth.Ids
{
    public class IdsClaimsService: DefaultClaimsService
    {
        public IdsClaimsService(IProfileService profile, ILogger<DefaultClaimsService> logger) : base(profile, logger)
        {
        }
    }
}
