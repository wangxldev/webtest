﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Auth.Roles
{
    public class RolePermissionCacheItem
    {
        public const string CacheStoreName = "role-permissions";

        public string RoleName { get; set; }

        public HashSet<string> GrantedPermissions { get; set; }

        public RolePermissionCacheItem()
        {
            GrantedPermissions = new HashSet<string>();
        }

        public RolePermissionCacheItem(string roleName)
            : this()
        {
            RoleName = roleName;
        }
    }
}
