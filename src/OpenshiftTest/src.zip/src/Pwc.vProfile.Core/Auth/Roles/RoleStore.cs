﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Abp;
using Abp.Dependency;
using Abp.Domain.Repositories;
using Abp.Domain.Uow;
using Abp.Timing;
using Castle.Core.Logging;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Core.Auth.Permissions;
using Pwc.vProfile.Data;
using Pwc.vProfile.Data.TenantDb;
using Pwc.vProfile.Utility.Extensions;
using PermissionGrantInfo = Pwc.vProfile.Core.Auth.Permissions.PermissionGrantInfo;

namespace Pwc.vProfile.Core.Auth.Roles
{
    public class RoleStore : IRoleStore<Role>,
        IRoleClaimStore<Role>,
        IRolePermissionStore,
        IQueryableRoleStore<Role>,

        ITransientDependency
    {

        private readonly ITenantDbContext _tenantDbContext;

        public RoleStore(ITenantDbContext profileDbContext)
        {
            _tenantDbContext = profileDbContext;
        }

        public IMongoCollection<Role> Collection => _tenantDbContext.DbSet<Role>(Role.CollectionName);

        public IQueryable<Role> Roles => Collection.AsQueryable();

        public async Task<IdentityResult> CreateAsync(Role role, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(role, nameof(role));
            await Collection.InsertOneAsync(role, cancellationToken: cancellationToken);
            return IdentityResult.Success;
        }

        public async Task<IdentityResult> UpdateAsync(Role role, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(role, nameof(role));
            var filter = Builders<Role>.Filter.And(
                    Builders<Role>.Filter.Eq(r=>r.Name,role.Name)
                );
            var update = Builders<Role>.Update.Set(r => r.DisplayName, role.DisplayName)
                    .Set(r => r.IsDefault, role.IsDefault)
                    .Set(r => r.Desc, role.Desc)
                    .Set(r => r.Permissions, role.Permissions)
                    .Set(r=>r.LastModificationTime,Clock.Now)
                    .Set(r=>r.LastModifierUserId,role.LastModifierUserId)
                ;

            await Collection.UpdateOneAsync(filter,update, cancellationToken: cancellationToken);
            return IdentityResult.Success;
        }

        public async Task<IdentityResult> DeleteAsync(Role role, CancellationToken cancellationToken = default(CancellationToken))
        {
            Check.NotNull(role, nameof(role));
            return await DeleteAsync(role.Name,cancellationToken);
        }

        public async Task<IdentityResult> DeleteAsync(string roleName, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(roleName, nameof(roleName));

            var filter = Builders<Role>.Filter.And(
                Builders<Role>.Filter.Eq(r => r.Name, roleName),
                Builders<Role>.Filter.Eq(r => r.IsStatic, false)
            );

            var result = await Collection.DeleteOneAsync(filter, cancellationToken);

            if (result.DeletedCount <= 0)
            {
                return IdentityResult.Failed(new []{new IdentityError()
                {
                    Description = "occur error when delete role"
                }, });
            }

            return IdentityResult.Success;
        }

        public Task<string> GetRoleIdAsync(Role role, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(role, nameof(role));

            return Task.FromResult(role.Id.ToString());
        }

        public Task<string> GetRoleNameAsync(Role role, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(role, nameof(role));

            return Task.FromResult(role.Name);
        }

        public Task SetRoleNameAsync(Role role, string roleName, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(role, nameof(role));

            role.Name = roleName;
            return Task.CompletedTask;
        }

        public Task<string> GetNormalizedRoleNameAsync(Role role, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(role, nameof(role));

            return Task.FromResult(role.Name);
        }

        public Task SetNormalizedRoleNameAsync(Role role, string normalizedName, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(role, nameof(role));

            role.Name = normalizedName;

            return Task.CompletedTask;
        }

        public Task<Role> FindByIdAsync(string roleId, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var role =  Collection.Find(r => r.Id == ObjectId.Parse(roleId)).FirstOrDefaultAsync(cancellationToken: cancellationToken);

            return role;
        }

        public Task<Role> FindByNameAsync(string normalizedRoleName, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var role = Collection.Find(r => r.Name == normalizedRoleName).FirstOrDefaultAsync(cancellationToken: cancellationToken);

            return role;
        }

        public Task<IList<Claim>> GetClaimsAsync(Role role, CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task AddClaimAsync(Role role, Claim claim, CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task RemoveClaimAsync(Role role, Claim claim, CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public async Task AddPermissionAsync(ObjectId roleId, PermissionGrantInfo permissionGrant)
        {
            throw new NotImplementedException();
        }

        Task IRolePermissionStore.RemovePermissionAsync(ObjectId roleId, PermissionGrantInfo permissionGrant)
        {
            return RemovePermissionAsync(roleId, permissionGrant);
        }

        Task<IList<PermissionGrantInfo>> IRolePermissionStore.GetPermissionsAsync(Role role)
        {
            return GetPermissionsAsync(role);
        }

        Task<IList<PermissionGrantInfo>> IRolePermissionStore.GetPermissionsAsync(string roleName)
        {
            return GetPermissionsAsync(roleName);
        }

        Task<bool> IRolePermissionStore.HasPermissionAsync(int roleId, PermissionGrantInfo permissionGrant)
        {
            return HasPermissionAsync(roleId, permissionGrant);
        }

        public async Task AddPermissionAsync(string name, PermissionGrantInfo permissionGrant)
        {
            if (await HasPermissionAsync(name, permissionGrant))
            {
                return;
            }

            var filter = Builders<Role>.Filter.And(
                    Builders<Role>.Filter.Eq(r=>r.Name,name)
                );

            var update = Builders<Role>.Update.Push(r=>r.Permissions,permissionGrant.Name);

            await Collection.UpdateOneAsync(filter,update);
        }

        public Task RemovePermissionAsync(ObjectId roleId, PermissionGrantInfo permissionGrant)
        {
            throw new NotImplementedException();
        }

        public async Task RemovePermissionAsync(string name, PermissionGrantInfo permissionGrant)
        {
            var filter = Builders<Role>.Filter.And(
                Builders<Role>.Filter.Eq(r => r.Name, name)
            );
            var update = Builders<Role>.Update.Pull(r => r.Permissions, permissionGrant.Name);
            await Collection.UpdateOneAsync(filter, update);
        }

        public Task<IList<PermissionGrantInfo>> GetPermissionsAsync(Role role)
        {
            return GetPermissionsAsync(role.Name);
        }

        public async Task<IList<PermissionGrantInfo>> GetPermissionsAsync(string roleName)
        {
            var filter = Builders<Role>.Filter.And(
                Builders<Role>.Filter.Eq(r => r.Name, roleName)
            );
           
            var role = await Collection.Find(filter).FirstOrDefaultAsync();

            return role?.Permissions?.Select(p => new PermissionGrantInfo(p,true)).ToList()??new List<PermissionGrantInfo>();
        }

        [Obsolete("this method is obsolete")]
        public Task<bool> HasPermissionAsync(int roleId, PermissionGrantInfo permissionGrant)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> HasPermissionAsync(string name, PermissionGrantInfo permissionGrant)
        {
            var filter = Builders<Role>.Filter.And(
                    Builders<Role>.Filter.Eq(r=>r.Name,name),
                    Builders<Role>.Filter.AnyEq(r=>r.Permissions,permissionGrant.Name)
                    );

            var count = await Collection.CountDocumentsAsync(filter);

            return count > 1;
        }

        public Task RemoveAllPermissionSettingsAsync(ObjectId roleId)
        {
            throw new NotImplementedException();
        }

        public async Task RemoveAllPermissionSettingsAsync(string name)
        {
            var filter = Builders<Role>.Filter.And(
                Builders<Role>.Filter.Eq(r => r.Name, name)
            );
            var update = Builders<Role>.Update.PullFilter(r => r.Permissions,p=>true);
            await Collection.UpdateOneAsync(filter, update);
        }

        public void Dispose()
        {

        }

        #region extension

        public async Task<Role> GetPartialRoleByName(string name,ProjectionDefinition<Role> project, CancellationToken cancellationToken = default(CancellationToken))
        {
            var filter = Builders<Role>.Filter.And(
                    Builders<Role>.Filter.Eq(r=>r.Name,name),
                    Builders<Role>.Filter.Eq(r=>r.IsStatic,false)
                );

            var doc = await Collection.Find(filter).Project(project).FirstOrDefaultAsync(cancellationToken: cancellationToken);

            return doc.BsonTo<Role>();
        }

        #endregion



    }
}
