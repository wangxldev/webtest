﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Auth.Roles
{
    public class RolePermissionsRel
    {
        public string Name { get; set; }

        public string DisplayName { get; set; }
    }
}
