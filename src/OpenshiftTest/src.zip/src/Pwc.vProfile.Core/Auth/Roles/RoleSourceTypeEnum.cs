﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Auth.Roles
{
    public static class RoleSourceTypeEnum
    {
        public const string Tenant = "tenant";

        public const string App = "app";
    }
}
