﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using MongoDB.Bson.Serialization.Attributes;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Auth.Roles
{
    [Table("tnt_roles")]
    public class Role:MongoEntityBase
    {
        public const string CollectionName = "tnt_roles";

        public const int MaxConcurrencyStampLength = 128;

        public const int MaxDisplayNameLength = 64;

        public const int MaxNameLength = 32;

        public Role()
        {
        }

        public Role(string displayName)
            : this()
        {
            DisplayName = displayName;
        }

        public Role(string name, string displayName)
            : this(displayName)
        {
            Name = name;
        }

        [Required]
        [StringLength(MaxNameLength)]
        [BsonElement("name")]
        public string Name { get; set; }

        [Required]
        [StringLength(MaxDisplayNameLength)]
        [BsonElement("display_name")]
        public string DisplayName { get; set; }

        [BsonElement("is_static")]
        public bool IsStatic { get; set; }

        [BsonElement("is_default")]
        public bool IsDefault { get; set; }

        [BsonElement("desc")]
        public String Desc { get; set; }

        [BsonElement("creation_time")]
        public DateTime CreationTime { get; set; }

        [BsonElement("creator_user_id")]
        public long CreatorUserId { get; set; }

        [BsonElement("last_modification_time")]
        public DateTime? LastModificationTime { get; set; }

        [BsonElement("last_modifier_user_id")]
        public long? LastModifierUserId { get; set; }

        [BsonElement("permissions")]
        public List<string> Permissions { get; set; }=new List<string>();

    }
}
