﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Abp;
using Abp.Authorization;
using Abp.Dependency;
using Abp.Domain.Services;
using Abp.Domain.Uow;
using Abp.MultiTenancy;
using Abp.Runtime.Caching;
using Abp.Runtime.Session;
using Abp.Timing;
using Abp.UI;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Core.Auth.Permissions;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.Core.Sequences;
using Pwc.vProfile.Utility.Extensions;

namespace Pwc.vProfile.Core.Auth.Roles
{
    public class RoleManager: RoleManager<Role>, IDomainService
    {
        private readonly IPermissionManager _permissionManager;
        private readonly ICacheManager _cacheManager;
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly ISequenceIdManager _sequenceIdManager;

        public RoleManager(
            RoleStore store,
            IEnumerable<IRoleValidator<Role>> roleValidators,
            ILookupNormalizer keyNormalizer,
            IdentityErrorDescriber errors,
            ILogger<RoleManager> logger,
            IPermissionManager permissionManager,
            ICacheManager cacheManager,
            IUnitOfWorkManager unitOfWorkManager, ISequenceIdManager sequenceIdManager)
            : base(
                store,
                roleValidators,
                keyNormalizer,
                errors,
                logger)
        {
            RoleStore = store;

            _permissionManager = permissionManager;
            _cacheManager = cacheManager;
            _unitOfWorkManager = unitOfWorkManager;
            _sequenceIdManager = sequenceIdManager;
        }

        protected RoleStore RoleStore { get; }

        public IMongoCollection<Role> Collection => RoleStore.Collection;

        public IAbpSession AbpSession { get; set; }

        private IRolePermissionStore RolePermissionStore
        {
            get
            {
                if (!(Store is IRolePermissionStore))
                {
                    throw new AbpException("Store is not IRolePermissionStore");
                }

                return Store as IRolePermissionStore;
            }
        }

        /// <summary>
        /// Checks if a role is granted for a permission.
        /// </summary>
        /// <param name="roleName">The role's name to check it's permission</param>
        /// <param name="permissionName">Name of the permission</param>
        /// <returns>True, if the role has the permission</returns>
        public virtual async Task<bool> IsGrantedAsync(string roleName, string permissionName)
        {
            return await IsGrantedAsync((await GetRoleByNameAsync(roleName)).Name, _permissionManager.GetPermission(permissionName));
        }

        /// <summary>
        /// Checks if a role is granted for a permission.
        /// </summary>
        /// <param name="role">The role</param>
        /// <param name="permission">The permission</param>
        /// <returns>True, if the role has the permission</returns>
        public Task<bool> IsGrantedAsync(Role role, Permission permission)
        {
            return IsGrantedAsync(role.Name, permission);
        }

        /// <summary>
        /// Checks if a role is granted for a permission.
        /// </summary>
        /// <param name="roleName">role id</param>
        /// <param name="permission">The permission</param>
        /// <returns>True, if the role has the permission</returns>
        public virtual async Task<bool> IsGrantedAsync(string roleName, Permission permission)
        {
            //Get cached role permissions
            var cacheItem = await GetRolePermissionCacheItemAsync(roleName);
//
//            //Check the permission
            return cacheItem.GrantedPermissions.Contains(permission.Name);
        }

        /// <summary>
        /// Gets granted permission names for a role.
        /// </summary>
        /// <param name="roleId">Role id</param>
        /// <returns>List of granted permissions</returns>
        public virtual async Task<IReadOnlyList<Permission>> GetGrantedPermissionsAsync(int roleId)
        {
            return await GetGrantedPermissionsAsync(await GetRoleByIdAsync(roleId));
        }

        /// <summary>
        /// Gets granted permission names for a role.
        /// </summary>
        /// <param name="roleName">Role name</param>
        /// <returns>List of granted permissions</returns>
        public virtual async Task<IReadOnlyList<Permission>> GetGrantedPermissionsAsync(string roleName)
        {
            return await GetGrantedPermissionsAsync(await GetRoleByNameAsync(roleName));
        }

        /// <summary>
        /// Gets granted permissions for a role.
        /// </summary>
        /// <param name="role">Role</param>
        /// <returns>List of granted permissions</returns>
        public virtual async Task<IReadOnlyList<Permission>> GetGrantedPermissionsAsync(Role role)
        {
            var permissionList = new List<Permission>();

            foreach (var permission in _permissionManager.GetAllPermissions())
            {
                if (await IsGrantedAsync(role.Name, permission))
                {
                    permissionList.Add(permission);
                }
            }

            return permissionList;
        }

        /// <summary>
        /// Sets all granted permissions of a role at once.
        /// Prohibits all other permissions.
        /// </summary>
        /// <param name="roleId">Role id</param>
        /// <param name="permissions">Permissions</param>
        public virtual async Task SetGrantedPermissionsAsync(int roleId, IEnumerable<Permission> permissions)
        {
            await SetGrantedPermissionsAsync(await GetRoleByIdAsync(roleId), permissions);
        }

        /// <summary>
        /// Sets all granted permissions of a role at once.
        /// Prohibits all other permissions.
        /// </summary>
        /// <param name="role">The role</param>
        /// <param name="permissions">Permissions</param>
        public virtual async Task SetGrantedPermissionsAsync(Role role, IEnumerable<Permission> permissions)
        {
            var oldPermissions = await GetGrantedPermissionsAsync(role);
            var newPermissions = permissions.ToArray();

            foreach (var permission in oldPermissions.Where(p => !newPermissions.Contains(p, PermissionEqualityComparer.Instance)))
            {
                await ProhibitPermissionAsync(role, permission);
            }

            foreach (var permission in newPermissions.Where(p => !oldPermissions.Contains(p, PermissionEqualityComparer.Instance)))
            {
                await GrantPermissionAsync(role, permission);
            }
        }

        /// <summary>
        /// Grants a permission for a role.
        /// </summary>
        /// <param name="role">Role</param>
        /// <param name="permission">Permission</param>
        public async Task GrantPermissionAsync(Role role, Permission permission)
        {
            if (await IsGrantedAsync(role.Name, permission))
            {
                return;
            }

            await RolePermissionStore.AddPermissionAsync(role.Id, new PermissionGrantInfo(permission.Name, true));
        }

        /// <summary>
        /// Prohibits a permission for a role.
        /// </summary>
        /// <param name="role">Role</param>
        /// <param name="permission">Permission</param>
        public async Task ProhibitPermissionAsync(Role role, Permission permission)
        {
            if (!await IsGrantedAsync(role.Name, permission))
            {
                return;
            }

            await RolePermissionStore.RemovePermissionAsync(role.Id, new PermissionGrantInfo(permission.Name, true));
        }

        /// <summary>
        /// Prohibits all permissions for a role.
        /// </summary>
        /// <param name="role">Role</param>
        public async Task ProhibitAllPermissionsAsync(Role role)
        {
            foreach (var permission in _permissionManager.GetAllPermissions())
            {
                await ProhibitPermissionAsync(role, permission);
            }
        }

        /// <summary>
        /// Resets all permission settings for a role.
        /// It removes all permission settings for the role.
        /// Role will have permissions those have <see cref="Permission.IsGrantedByDefault"/> set to true.
        /// </summary>
        /// <param name="role">Role</param>
        public async Task ResetAllPermissionsAsync(Role role)
        {
            await RolePermissionStore.RemoveAllPermissionSettingsAsync(role.Id);
        }

        /// <summary>
        /// Creates a role.
        /// </summary>
        /// <param name="role">Role</param>
        public override async Task<IdentityResult> CreateAsync(Role role)
        {
            Check.NotNull(role, nameof(role));

            var project = Builders<Role>.Projection.Include(r => r.Name).Include(r => r.DisplayName);

            var dbRole = await RoleStore.GetPartialRoleByName(role.Name, project);

            if (dbRole != null)
            {
                throw new UserFriendlyException("can not create role , because the role is exists");
            }

            role.CreationTime = Clock.Now;
            role.CreatorUserId = 0;
            return  await RoleStore.CreateAsync(role);
        }

        [Obsolete("please use CreateOrUpdate method")]
        public override async Task<IdentityResult> UpdateAsync(Role role)
        {
            Check.NotNull(role, nameof(role));

            var project = Builders<Role>.Projection.Include(r => r.Name).Include(r => r.DisplayName);

            var dbRole = await RoleStore.GetPartialRoleByName(role.Name, project);

            if (dbRole == null)
            {
                throw new UserFriendlyException("can not update role , because the role isn't exists");
            }

            role.LastModificationTime = Clock.Now;
            role.LastModifierUserId = 0;
            return await RoleStore.UpdateAsync(role);
        }

        public async Task<IdentityResult> CreateOrUpdateAsync(Role role)
        {
            Check.NotNull(role, nameof(role));

            var project = Builders<Role>.Projection.Include(r => r.Name).Include(r => r.DisplayName);

            var dbRole = await RoleStore.GetPartialRoleByName(role.Name, project);

            // TODO 如果针对特定的角色要进行特殊处理,需要在这里判断

            var result = IdentityResult.Success;

            if (dbRole == null)
            {
                role.CreationTime = Clock.Now;
                role.CreatorUserId = 0;
                result = await RoleStore.CreateAsync(role);
            }
            else
            {
                role.LastModificationTime = Clock.Now;
                role.LastModifierUserId = 0;
                result = await RoleStore.UpdateAsync(role);

                // 当检测到在role更新时DisplayName发生了变化,则需要更新User和Group关联的Role数据
                if (role.DisplayName != dbRole.DisplayName)
                {
                    // 更新User关联的Role数据
                    var userManager = IocManager.Instance.Resolve<UserManager>();
                    await userManager.UpdateUserRoleDisplayName(role.Name, role.DisplayName);
                }

                // TODO 更新Group关联的Role数据
            }

            return result;

        }


        /// <summary>
        /// Deletes a role.
        /// </summary>
        /// <param name="role">Role</param>
        public override async Task<IdentityResult> DeleteAsync(Role role)
        {
            if (role.IsStatic)
            {
                throw new UserFriendlyException(string.Format("CanNotDeleteStaticRole", role.Name));
            }

            await RoleStore.DeleteAsync(role);
            return IdentityResult.Success;
        }

        public async Task<IdentityResult> DeleteAsync(string roleName)
        {
            return await RoleStore.DeleteAsync(roleName);
        }

        /// <summary>
        /// Gets a role by given id.
        /// Throws exception if no role with given id.
        /// </summary>
        /// <param name="roleId">Role id</param>
        /// <returns>Role</returns>
        /// <exception cref="AbpException">Throws exception if no role with given id</exception>
        public virtual async Task<Role> GetRoleByIdAsync(int roleId)
        {
            var role = await RoleStore.FindByIdAsync(roleId.ToString());
            if (role == null)
            {
                throw new AbpException("There is no role with id: " + roleId);
            }

            return role;
        }

        /// <summary>
        /// Gets a role by given name.
        /// Throws exception if no role with given roleName.
        /// </summary>
        /// <param name="roleName">Role name</param>
        /// <returns>Role</returns>
        /// <exception cref="AbpException">Throws exception if no role with given roleName</exception>
        public virtual async Task<Role> GetRoleByNameAsync(string roleName)
        {
            var role = await RoleStore.FindByNameAsync(roleName);
            if (role == null)
            {
                throw new AbpException("There is no role with name: " + roleName);
            }

            return role;
        }

        public async Task<IList<PermissionGrantInfo>> GetPermissionsAsync(string name)
        {
            return await RoleStore.GetPermissionsAsync(name);
        }


        private async Task<RolePermissionCacheItem> GetRolePermissionCacheItemAsync(string roleName)
        {
            var cacheKey = roleName + "@" + 0;
        
            var cache = _cacheManager.GetCache<string, RolePermissionCacheItem>(RolePermissionCacheItem.CacheStoreName);
        
            return await cache.GetAsync(cacheKey, async () =>
            {
                var newCacheItem = new RolePermissionCacheItem(roleName);
        
                foreach (var permissionInfo in await RolePermissionStore.GetPermissionsAsync(roleName))
                {
                    if (permissionInfo.IsGranted)
                    {
                        newCacheItem.GrantedPermissions.Add(permissionInfo.Name);
                    }
                }
        
                return newCacheItem;
            });
        }

        /// <summary>
        /// 根据一个name列表获取role列表
        /// </summary>
        /// <param name="roleNames"></param>
        /// <param name="projection"></param>
        /// <returns></returns>
        public async Task<List<Role>> GetRoleByNames(List<string> roleNames,ProjectionDefinition<Role> projection=null)
        {
            var filter = Builders<Role>.Filter.And(
                    Builders<Role>.Filter.In(r=>r.Name,roleNames)
                );

            var project = projection;

            if (project == null)
            {
                project = Builders<Role>.Projection.Include(r => r.Name).Include(r => r.DisplayName);
            }

            var rolesDoc = await Collection.Find(filter).Project(project).ToListAsync();

            return rolesDoc.BsonToList<Role>();
        }
    }
}
