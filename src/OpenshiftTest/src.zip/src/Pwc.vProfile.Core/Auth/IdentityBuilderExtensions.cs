﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Pwc.vProfile.Core.Auth.Roles;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Core.Auth
{
    public static class IdentityBuilderExtensions
    {
        public static IdentityBuilder AddProfileTenantManager<TTenantManager>(this IdentityBuilder builder)
        {
            return builder;
        }

        public static IdentityBuilder AddProfileEditionManager<TEditionManager>(this IdentityBuilder builder)
        {
            return builder;
        }

        public static IdentityBuilder AddProfileRoleManager<TRoleManager>(this IdentityBuilder builder)
        where TRoleManager : class
        {
            var authManagerType = typeof(RoleManager);
            var managerType = typeof(RoleManager<>).MakeGenericType(builder.RoleType);
            builder.Services.AddScoped(authManagerType, services => services.GetRequiredService(managerType));
            builder.AddRoleManager<TRoleManager>();
            return builder;
        }

        public static IdentityBuilder AddProfileUserManager<TUserManager>(this IdentityBuilder builder)
            where TUserManager : class
        {
            var abpManagerType = typeof(UserManager);
            var managerType = typeof(UserManager<>).MakeGenericType(builder.UserType);
            builder.Services.AddScoped(abpManagerType, services => services.GetRequiredService(managerType));
            builder.AddUserManager<TUserManager>();
            return builder;
        }

        public static IdentityBuilder AddProfileSignInManager<TSignInManager>(this IdentityBuilder builder)
            where TSignInManager : class
        {
//            var abpManagerType = typeof(AuthSignInManager);
//            var managerType = typeof(SignInManager<>).MakeGenericType(builder.UserType);
//            builder.Services.AddScoped(abpManagerType, services => services.GetRequiredService(managerType));
//            builder.AddSignInManager<TSignInManager>();
            return builder;
        }

        public static IdentityBuilder AddProfileLogInManager<TLogInManager>(this IdentityBuilder builder)
            where TLogInManager : class
        {
//            var type = typeof(TLogInManager);
//            var abpManagerType = typeof(AuthLogInManager);
//            builder.Services.AddScoped(type, provider => provider.GetService(abpManagerType));
//            builder.Services.AddScoped(abpManagerType, type);
            return builder;
        }

        public static IdentityBuilder AddProfileUserClaimsPrincipalFactory<TUserClaimsPrincipalFactory>(this IdentityBuilder builder)
            where TUserClaimsPrincipalFactory : class
        {
//            var type = typeof(TUserClaimsPrincipalFactory);
//            builder.Services.AddScoped(typeof(UserClaimsPrincipalFactory<,>).MakeGenericType(builder.UserType, builder.RoleType), services => services.GetRequiredService(type));
//            builder.Services.AddScoped(typeof(SecurityStampValidator), services => services.GetRequiredService(type));
//            builder.Services.AddScoped(typeof(IUserClaimsPrincipalFactory<>).MakeGenericType(builder.UserType), services => services.GetRequiredService(type));
//            builder.Services.AddScoped(type);
            return builder;
        }

        public static IdentityBuilder AddProfileSecurityStampValidator<TSecurityStampValidator>(this IdentityBuilder builder)
            where TSecurityStampValidator : class, ISecurityStampValidator
        {
//            var type = typeof(TSecurityStampValidator);
//            builder.Services.AddScoped(typeof(SecurityStampValidator<>).MakeGenericType(builder.UserType), services => services.GetRequiredService(type));
//            builder.Services.AddScoped(typeof(SecurityStampValidator), services => services.GetRequiredService(type));
//            builder.Services.AddScoped(typeof(ISecurityStampValidator), services => services.GetRequiredService(type));
//            builder.Services.AddScoped(type);
            return builder;
        }

        public static IdentityBuilder AddPermissionChecker<TPermissionChecker>(this IdentityBuilder builder)
            where TPermissionChecker : class
        {
            //            var type = typeof(TPermissionChecker);
            //            var checkerType = typeof(PermissionChecker<,>).MakeGenericType(builder.RoleType, builder.UserType);
            //            builder.Services.AddScoped(type);
            //            builder.Services.AddScoped(checkerType, provider => provider.GetService(type));
            //            builder.Services.AddScoped(typeof(IPermissionChecker), provider => provider.GetService(type));
            return builder;
        }

        public static IdentityBuilder AddProfileUserStore<TUserStore>(this IdentityBuilder builder)
            where TUserStore : class
        {
            var type = typeof(TUserStore);
            var abpStoreType = typeof(UserStore);
            var storeType = typeof(IUserStore<>).MakeGenericType(builder.UserType);
            builder.Services.AddScoped(type);
            builder.Services.AddScoped(abpStoreType, services => services.GetRequiredService(type));
            builder.Services.AddScoped(storeType, services => services.GetRequiredService(type));
            return builder;
        }

        public static IdentityBuilder AddProfileRoleStore<TRoleStore>(this IdentityBuilder builder)
            where TRoleStore : class
        {
            var type = typeof(TRoleStore);
            var abpStoreType = typeof(RoleStore);
            var storeType = typeof(IRoleStore<>).MakeGenericType(builder.RoleType);
            builder.Services.AddScoped(type);
            builder.Services.AddScoped(abpStoreType, services => services.GetRequiredService(type));
            builder.Services.AddScoped(storeType, services => services.GetRequiredService(type));
            return builder;
        }

        public static IdentityBuilder AddFeatureValueStore<TFeatureValueStore>(this IdentityBuilder builder)
            where TFeatureValueStore : class
        {
            return builder;
        }
    }
}
