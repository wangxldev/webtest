﻿using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson.Serialization.Attributes;

namespace Pwc.vProfile.Core.Auth.Users
{
    public class UserRoleRel
    {
        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("display_name")]
        public string DisplayName { get; set; }
    }
}
