﻿using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson.Serialization.Attributes;

namespace Pwc.vProfile.Core.Auth.Users
{
    public class UserGroupsRel
    {
        [BsonElement("seq_id")]
        public int SeqId { get; set; }

        [BsonElement("name")]
        public string Name { get; set; }
    }
}
