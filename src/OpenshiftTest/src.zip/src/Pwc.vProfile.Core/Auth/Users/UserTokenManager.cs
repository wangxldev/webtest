﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Pwc.vProfile.Core.Auth.Users
{
    public class UserTokenManager: IUserTokenManager
    {
        public Task Create(UserToken token)
        {
            throw new NotImplementedException();
        }

        public Task Remove(string userId)
        {
            throw new NotImplementedException();
        }

        public Task<bool> Verify(string tenantCode, long userId, string token)
        {
            throw new NotImplementedException();
        }
    }
}
