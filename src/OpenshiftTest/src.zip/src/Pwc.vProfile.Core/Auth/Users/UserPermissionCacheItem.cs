﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Auth.Users
{
    public class UserPermissionCacheItem
    {
        public const String CacheStoreName = "user-permissions";

        public UserPermissionCacheItem()
        {
            RoleNames = new List<string>();
            GrantedPermissions = new HashSet<string>();
        }

        public UserPermissionCacheItem(long userId)
            : this()
        {
            UserId = userId;
        }

        public long UserId { get; set; }

        public List<string> RoleNames { get; set; }

        public HashSet<string> GrantedPermissions { get; set; }
    }
}
