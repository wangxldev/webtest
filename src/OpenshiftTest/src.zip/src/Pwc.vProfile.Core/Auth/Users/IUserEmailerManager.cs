﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Auth.Users
{
    public interface IUserEmailerManager
    {
    }
}
