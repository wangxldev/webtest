﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;

namespace Pwc.vProfile.Core.Auth.Users
{
    public class UserClaim
    {
        public UserClaim()
        {

        }

        public UserClaim(User user, Claim claim)
        {
            UserId = user.SeqId;
            ClaimType = claim.Type;
            ClaimValue = claim.Value;
        }

        public virtual long UserId { get; set; }

        public virtual string ClaimType { get; set; }

        public virtual string ClaimValue { get; set; }
    }
}
