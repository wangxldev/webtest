﻿using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson.Serialization.Attributes;

namespace Pwc.vProfile.Core.Auth.Users
{
    public class UserToken
    {
        public string TenantCode { get; set; }

        public long UserId { get; set; }

        public string LoginProvider { get; set; }

        //        public virtual string Name { get; set; }

        /// <summary>
        /// 用来获取token的ticket
        /// </summary>
        public string Ticket { get; set; }

        public string Token { get; set; }

        public DateTime? ExpireDate { get; set; }

        public string Device { get; set; }

        [BsonElement("creation_time")]
        public DateTime CreationTime { get; set; }
    }
}
