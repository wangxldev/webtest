﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Abp;
using Abp.Application.Features;
using Abp.Authorization;
using Abp.Configuration;
using Abp.Dependency;
using Abp.Domain.Services;
using Abp.Domain.Uow;
using Abp.Extensions;
using Abp.MultiTenancy;
using Abp.Runtime.Caching;
using Abp.Runtime.Session;
using Abp.Threading;
using Abp.Timing;
using Abp.UI;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Pwc.vProfile.Core.Auth.Roles;
using Pwc.vProfile.Core.Groups;
using Pwc.vProfile.Core.Sequences;

namespace Pwc.vProfile.Core.Auth.Users
{
    public class UserManager: Microsoft.AspNetCore.Identity.UserManager<User>, ITransientDependency
    {
        private readonly IPermissionManager _permissionManager;
        private readonly ICacheManager _cacheManager;
        private readonly ISettingManager _settingManager;
        private readonly IUnitOfWorkManager _unitOfWorkManager;
        private readonly ISequenceIdManager _sequenceIdManager;
        private readonly IGroupManager _groupManager;

        public UserManager(
            RoleManager roleManager,
            UserStore store,
            IOptions<IdentityOptions> optionsAccessor,
            IPasswordHasher<User> passwordHasher,
            IEnumerable<IUserValidator<User>> userValidators,
            IEnumerable<IPasswordValidator<User>> passwordValidators,
            ILookupNormalizer keyNormalizer,
            IdentityErrorDescriber errors,
            IServiceProvider services,
            ILogger<UserManager> logger,
            IPermissionManager permissionManager,
            ICacheManager cacheManager, ISettingManager settingManager,
            IUnitOfWorkManager unitOfWorkManager, ISequenceIdManager sequenceIdManager, IGroupManager groupManager) :
            base(
                store,
                optionsAccessor,
                passwordHasher,
                userValidators,
                passwordValidators,
                keyNormalizer,
                errors,
                services,
                logger)
        {
            UserStore = store;
            _permissionManager = permissionManager;
            _cacheManager = cacheManager;
            _settingManager = settingManager;
            _unitOfWorkManager = unitOfWorkManager;
            _sequenceIdManager = sequenceIdManager;
            _groupManager = groupManager;
            RoleManager = roleManager;
            Collection = UserStore.Collection;
        }

        public IAbpSession AbpSession { get; set; }

        public FeatureDependencyContext FeatureDependencyContext { get; set; }

        protected RoleManager RoleManager { get; }

        public UserStore UserStore { get; }

        public IMongoCollection<User> Collection { get; }

        #region override

        public override async Task<IdentityResult> CreateAsync(User user)
        {
            var result = IdentityResult.Success;

            result = CheckDuplicateUsernameOrEmail(user.SeqId, user.UserName, user.Email);

            if (!result.Succeeded)
            {
                return result;
            }

            user.CreationTime = Clock.Now;

            // 统一Enable与IsLockoutEnabled的标志
            var isLockoutEnabled = user.IsLockoutEnabled;
            user.SeqId = await _sequenceIdManager.GetNewtUserId();

            var identityResult = await UserStore.CreateAsync(user);
            if (identityResult.Succeeded)
            {
                await _unitOfWorkManager.Current.SaveChangesAsync();
                await SetLockoutEnabledAsync(user, isLockoutEnabled);
            }
            return identityResult;
        }

        public override async Task<IdentityResult> UpdateAsync(User user)
        {
            var update = Builders<User>.Update.Combine(
                Builders<User>.Update.Set(u => u.Name, user.Name),
                Builders<User>.Update.Set(u => u.FirstName, user.FirstName),
                Builders<User>.Update.Set(u => u.LastName, user.LastName),
                Builders<User>.Update.Set(u => u.IsLockoutEnabled, user.IsLockoutEnabled),
                Builders<User>.Update.Set(u => u.LockoutEndDateUtc, user.LockoutEndDateUtc),
                Builders<User>.Update.Set(u => u.Phone, user.Phone),
                Builders<User>.Update.Set(u => u.IsTwoFactorEnabled, user.IsTwoFactorEnabled),
                Builders<User>.Update.Set(u => u.IsActive, user.IsActive),
                Builders<User>.Update.Set(u => u.Groups, user.Groups),
                Builders<User>.Update.Set(u => u.Permissions, user.Permissions),
                Builders<User>.Update.Set(u => u.Extends, user.Extends),
                Builders<User>.Update.Set(u => u.ShouldChangePasswordOnNextLogin, user.ShouldChangePasswordOnNextLogin),
                Builders<User>.Update.Set(u => u.LastModificationTime, Clock.Now)
            );

            //Admin user's username can not be changed!
            if (user.UserName != User.AdminUserName)
            {
                var oldName = await UserStore.GetOldUserNameBySeqId(user.SeqId);

                if (oldName == User.AdminUserName)
                {
                    throw new UserFriendlyException(string.Format("CanNotRenameAdminUser", User.AdminUserName));
                }
            }

            return await UserStore.PartUpdateAsync(user,update);
        }

        public virtual async Task<IdentityResult> ChangePasswordAsync(User user, string newPassword)
        {
            var errors = new List<IdentityError>();

            foreach (var validator in PasswordValidators)
            {
                var validationResult = await validator.ValidateAsync(this, user, newPassword);
                if (!validationResult.Succeeded)
                {
                    errors.AddRange(validationResult.Errors);
                }
            }

            if (errors.Any())
            {
                return IdentityResult.Failed(errors.ToArray());
            }

            await UserStore.SetPasswordHashAsync(user, PasswordHasher.HashPassword(user, newPassword));
            return IdentityResult.Success;
        }

        public virtual async Task<User> GetUserOrNullAsync(UserIdentifier userIdentifier)
        {
            return await UserStore.FindByIdAsync(userIdentifier.UserId.ToString());
        }

        public User GetUserOrNull(UserIdentifier userIdentifier)
        {
            return AsyncHelper.RunSync(() => GetUserOrNullAsync(userIdentifier));
        }

        public async Task<User> GetUserAsync(UserIdentifier userIdentifier)
        {
            var user = await GetUserOrNullAsync(userIdentifier);
            if (user == null)
            {
                throw new Exception("There is no user: " + userIdentifier);
            }

            return user;
        }

        public User GetUser(UserIdentifier userIdentifier)
        {
            return AsyncHelper.RunSync(() => GetUserAsync(userIdentifier));
        }

        public async Task SoftDeleteByIdAsync(long seqId)
        {
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, seqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            var oldName = await UserStore.GetOldUserNameBySeqId(seqId);

            if (oldName == User.AdminUserName)
            {
                throw new UserFriendlyException("Can not delete admin");
            }

            var update = Builders<User>.Update.Set(u => u.IsDeleted, true);

            await Collection.UpdateOneAsync(filter, update);
        }

        #endregion

        /// <summary>
        /// Gets a user by given id.
        /// Throws exception if no user found with given id.
        /// </summary>
        /// <param name="userId">User id</param>
        /// <returns>User</returns>
        /// <exception cref="AbpException">Throws exception if no user found with given id</exception>
        public virtual async Task<User> GetUserByIdAsync(long userId)
        {
            var filter = Builders<User>.Filter.And(
                    Builders<User>.Filter.Eq(u=>u.SeqId,userId),
                    Builders<User>.Filter.Eq(u=>u.IsDeleted,false)
                );

            var user = await UserStore.Collection.Find(filter).FirstOrDefaultAsync();

            if (user == null)
            {
                throw new AbpException("There is no user with id: " + userId);
            }

            return user;
        }


        public virtual IdentityResult CheckDuplicateUsernameOrEmail(long? expectedUserId, string userName, string email)
        {
            var filter = Builders<User>.Filter.And(
                    Builders<User>.Filter.Eq(u=>u.UserName,userName),
                    Builders<User>.Filter.Eq(u=>u.Email,email),
                    Builders<User>.Filter.Eq(u => u.IsDeleted, false)
                );

            var user = UserStore.Collection.Find(filter).FirstOrDefault();

            if (user != null && user.SeqId != expectedUserId)
            {
                if (user.UserName.ToUpper().Equals(userName.ToUpper()))
                {
                    throw new UserFriendlyException(string.Format("Identity.DuplicateUserName", userName));
                }
                else if (user.Email.ToUpper().Equals(email.ToUpper()))
                {
                    throw new UserFriendlyException(string.Format("Identity.DuplicateEmail", email));
                }
                else
                {
                    throw new UserFriendlyException("Duplicate");
                }
            }

            return IdentityResult.Success;
        }

        /// <summary>
        /// 解锁用户
        /// </summary>
        /// <param name="seqId"></param>
        /// <param name="IsLockout"></param>
        /// <returns></returns>
        public async Task SetLockAsync(long seqId,bool IsLockout)
        {
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, seqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false),
                Builders<User>.Filter.Eq(u => u.IsLockoutEnabled, IsLockout)
            );

            var update = Builders<User>.Update.Combine(
                    Builders<User>.Update.Set(u=>u.IsLockoutEnabled,false),
                    Builders<User>.Update.Set(u=>u.LockoutEndDateUtc,null)
                    );

            await Collection.UpdateOneAsync(filter, update);
        }

        /// <summary>
        /// 激活用户
        /// </summary>
        /// <param name="seqId"></param>
        /// <param name="isActive"></param>
        /// <returns></returns>
        public async Task SetActivateAsync(long seqId,bool isActive)
        {
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, seqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false),
                Builders<User>.Filter.Eq(u => u.IsActive, isActive)
            );

            var update = Builders<User>.Update.Combine(
                Builders<User>.Update.Set(u => u.IsActive, true)
            );

            await Collection.UpdateOneAsync(filter, update);
        }

        public async Task UpdateUserRoles(long seqId,List<string> roleNames)
        {
            // 获取角色列表
            var roles = await RoleManager.GetRoleByNames(roleNames);

            var userRoles = roles.Select(r => new UserRoleRel()
            {
                Name = r.Name,
                DisplayName = r.DisplayName
            });

            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, seqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            var update = Builders<User>.Update.Set(u => u.Roles, userRoles);

            await Collection.UpdateOneAsync(filter, update);
        }

        /// <summary>
        /// 用户登录成功后更新相关信息
        /// </summary>
        /// <returns></returns>
        public async Task UpdateUserByLogin(User user)
        {
            var filter = Builders<User>.Filter.And(
                    Builders<User>.Filter.Eq(u=>u.SeqId,user.SeqId),
                    Builders<User>.Filter.Eq(u=>u.IsActive,true),
                    Builders<User>.Filter.Eq(u=>u.IsDeleted,false),
                    Builders<User>.Filter.Gt(u=>u.LockoutEndDateUtc,DateTime.Now)
                );

            var update = Builders<User>.Update.Combine(
                    Builders<User>.Update.Set(u=>u.AccessFailedCount,0),
                    Builders<User>.Update.Set(u=>u.LastLoginTime,Clock.Now),
                    Builders<User>.Update.Set(u=>u.SignInToken,user.SignInToken),
                    Builders<User>.Update.Set(u=>u.SignInTokenExpireTimeUtc,user.SignInTokenExpireTimeUtc)
                    );

            await Collection.UpdateOneAsync(filter, update);
        }

        /// <summary>
        /// Check whether a user is granted for a permission.
        /// </summary>
        /// <param name="userId">User id</param>
        /// <param name="permission">Permission</param>
        public virtual async Task<bool> IsGrantedAsync(long userId, string permission)
        {

            //Get cached user permissions
            var cacheItem = await GetUserPermissionCacheItemAsync(userId);
            if (cacheItem == null)
            {
                return false;
            }

            //Check for user-specific value
            if (cacheItem.GrantedPermissions.Contains(permission))
            {
                return true;
            }


            //Check for roles
            foreach (var roleId in cacheItem.RoleNames)
            {
                if (await RoleManager.IsGrantedAsync(roleId, permission))
                {
                    return true;
                }
            }

            return false;
        }

        private async Task<UserPermissionCacheItem> GetUserPermissionCacheItemAsync(long userId)
        {
            var cacheKey = userId + "@" + 0;

            var cache = _cacheManager.GetCache<string, UserPermissionCacheItem>(UserPermissionCacheItem.CacheStoreName);

            return await cache.GetAsync(cacheKey, async () =>
            {
                var user = await FindByIdAsync(userId.ToString());
                if (user == null)
                {
                    return null;
                }

                var newCacheItem = new UserPermissionCacheItem(userId);

                foreach (var roleName in await GetRolesAsync(user))
                {
                    newCacheItem.RoleNames.Add((await RoleManager.GetRoleByNameAsync(roleName)).Name);
                }

                return newCacheItem;
            });
        }

        #region UserRoles

        public async Task UpdateUserRoleDisplayName(string roleName,string displayName)
        {
            var filter = Builders<User>.Filter.ElemMatch(u => u.Roles,r=>r.Name==roleName);

            var update = Builders<User>.Update.Set("roles.$.display_name", displayName);

            await Collection.UpdateManyAsync(filter, update);
        }

        #endregion

        #region UserGroups

        public async Task UpdateUserGroups(long seqId, List<int> groupIds)
        {
            var filter = Builders<User>.Filter.And(
                    Builders<User>.Filter.Eq(u=>u.SeqId,seqId),
                     Builders<User>.Filter.Eq(u=>u.IsDeleted,false)
                    );

            // 当groupIds为空时标识清除这个用户所有的组
            if (groupIds == null || groupIds.Count <= 0)
            {
                var update = Builders<User>.Update.Set(u => u.Groups, new List<UserGroupsRel>());

                await Collection.UpdateOneAsync(filter, update);
            }
            else
            {
                var project = Builders<Group>.Projection.Include(g => g.SeqId).Include(g => g.Name);
                
                var groups = await _groupManager.GetListByIds(groupIds, project);

                var userGroups = groups.Select(g => new UserGroupsRel()
                {
                    SeqId = g.SeqId,
                    Name = g.Name
                }).ToList();

                var update = Builders<User>.Update.Set(u => u.Groups, userGroups);
                await Collection.UpdateOneAsync(filter, update);
            }
        }

        public async Task UpdateUserGroupName(int groupId, string name)
        {
            var filter = Builders<User>.Filter.ElemMatch(u => u.Groups, r => r.SeqId == groupId);

            var update = Builders<User>.Update.Set("groups.$.name", name);

            await Collection.UpdateManyAsync(filter, update);
        }

        #endregion

    }
}
