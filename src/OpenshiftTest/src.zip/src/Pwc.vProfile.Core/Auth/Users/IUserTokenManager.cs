﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Dependency;

namespace Pwc.vProfile.Core.Auth.Users
{
    public interface IUserTokenManager:ITransientDependency
    {
        Task Create(UserToken token);

        Task Remove(string userId);

        Task<bool> Verify(string tenantCode, long userId, string token);
    }
}
