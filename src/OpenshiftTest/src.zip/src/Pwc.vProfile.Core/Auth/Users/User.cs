﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp;
using Abp.Extensions;
using Abp.Timing;
using IdentityServer4;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.Options;
using Pwc.vProfile.Core.ExtendFields;

namespace Pwc.vProfile.Core.Auth.Users
{
    [Table("tnt_users")]
    public class User: MongoEntityBase
    {
        public const string CollectionName = "tnt_users";

        public const int MaxUserNameLength = 32;

        public const int MaxEmailAddressLength = 256;

        public const int MaxNameLength = 64;

        public const int MaxAuthenticationSourceLength = 64;

        public const string AdminUserName = "admin";

        public const int MaxPasswordLength = 128;

        public const int MaxPlainPasswordLength = 16;

        public const int MinPlainPasswordLength = 6;

        public const int MaxEmailConfirmationCodeLength = 328;

        public const int MaxPasswordResetCodeLength = 328;

        public User()
        {
            IsActive = true;
            IsLockoutEnabled = true;
            SecurityStamp = SequentialGuidGenerator.Instance.Create().ToString();
//            Tokens = new Collection<UserToken>();
        }

        /// <summary>
        /// 顺序自增Id,在系统内部用来做数据关联
        /// </summary>
        [BsonElement("seq_id")]
        public long SeqId { get; set; }

        /// <summary>
        /// 员工编号
        /// </summary>
        [BsonElement("stuff_code")]
        public string StaffCode { get; set; }

        [BsonElement("international_code")]
        public string InternationalCode { get; set; }

        /// <summary>
        /// 用户唯一标识
        /// </summary>
        [Required]
        [StringLength(MaxUserNameLength)]
        [BsonElement("user_name")]
        public string UserName { get; set; }
        
        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("email")]
        [StringLength(MaxEmailAddressLength)]
        public string Email { get; set; }

        [BsonElement("is_email_confirmed")]
        public bool IsEmailConfirmed { get; set; }

        [BsonElement("first_name")]
        public string FirstName { get; set; }

        [BsonElement("last_name")]
        public string LastName { get; set; }

        [Required]
        [StringLength(MaxPasswordLength)]
        [BsonElement("password")]
        public string Password { get; set; }

        [BsonElement("email_confirmation_code")]
        [StringLength(MaxEmailConfirmationCodeLength)]
        public string EmailConfirmationCode { get; set; }

        [BsonElement("password_reset_code")]
        [StringLength(MaxPasswordResetCodeLength)]
        public string PasswordResetCode { get; set; }

        [BsonElement("access_failed_count")]
        public int AccessFailedCount { get; set; }

        [BsonElement("is_lockout_enabled")]
        public bool IsLockoutEnabled { get; set; }

        [BsonElement("lockout_end_date_utc")]
        public DateTime? LockoutEndDateUtc { get; set; }

        [BsonElement("phone")]
        public string Phone { get; set; }

        [BsonElement("is_phone_confirmed")]
        public bool IsPhoneConfirmed { get; set; }

        [BsonElement("security_stamp")]
        public string SecurityStamp { get; set; }

        [BsonElement("is_twoFactor_enabled")]
        public bool IsTwoFactorEnabled { get; set; }

        [BsonElement("is_active")]
        public bool IsActive { get; set; }

        [BsonElement("last_login_time")]
        public DateTime? LastLoginTime { get; set; }

        [BsonElement("concurrency_stamp")]
        public string ConcurrencyStamp { get; set; } = Guid.NewGuid().ToString();

        [BsonElement("signIn_token")]
        public string SignInToken { get; set; }

        [BsonElement("signIn_token_expire_time_utc")]
        public DateTime? SignInTokenExpireTimeUtc { get; set; }

        [BsonElement("roles")]
        public List<UserRoleRel> Roles { get; set; } = new List<UserRoleRel>();

        [BsonElement("groups")]
        public List<UserGroupsRel> Groups { get; set; } = new List<UserGroupsRel>();

        [BsonElement("permissions")]
        public List<string> Permissions { get; set; } = new List<string>();

        [BsonElement("extends")]
        [BsonDictionaryOptions(DictionaryRepresentation.Document)]
        public Dictionary<string, string> Extends { get; set; }

        [BsonElement("is_deleted")]
        public bool IsDeleted { get; set; }

        [BsonElement("should_change_password_on_next_login")]
        public bool ShouldChangePasswordOnNextLogin { get; set; }

        [BsonElement("creation_time")]
        public DateTime CreationTime { get; set; }

        [BsonElement("creator_user_id")]
        public long CreatorUserId { get; set; }

        [BsonElement("last_modification_time")]
        public DateTime? LastModificationTime { get; set; }

        [BsonElement("last_modifier_user_id")]
        public long? LastModifierUserId { get; set; }

        public void SetNewPasswordResetCode()
        {
            PasswordResetCode = Guid.NewGuid().ToString("N").Truncate(MaxPasswordResetCodeLength).ToUpperInvariant(); ;
        }

        public void SetNewEmailConfirmationCode()
        {
            EmailConfirmationCode = Guid.NewGuid().ToString("N").Truncate(MaxEmailConfirmationCodeLength);
        }

        public UserIdentifier ToUserIdentifier()
        {
            return new UserIdentifier(null, SeqId);
        }

        public static string CreateRandomPassword()
        {
            return Guid.NewGuid().ToString("N").Truncate(16);
        }

        public void Unlock()
        {
            AccessFailedCount = 0;
            LockoutEndDateUtc = null;
        }

        public void SetSignInToken()
        {
            // TODO 根据不同的登录类型来确定过期时间

            SignInToken = Guid.NewGuid().ToString("N");
            SignInTokenExpireTimeUtc = Clock.Now.AddMonths(12).ToUniversalTime();
        }

    }
}
