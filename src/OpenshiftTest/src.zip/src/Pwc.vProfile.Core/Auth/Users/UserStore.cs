﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Abp;
using Abp.Dependency;
using Abp.Extensions;
using Abp.Timing;
using Microsoft.AspNetCore.Identity;
using MongoDB.Driver;
using MongoDB.Driver.Core.Misc;
using Pwc.vProfile.Core.Auth.Permissions;
using Pwc.vProfile.Data;
using Pwc.vProfile.Data.TenantDb;
using Pwc.vProfile.Utility.Extensions;

namespace Pwc.vProfile.Core.Auth.Users
{
    public class UserStore : IUserLoginStore<User>,
        IUserRoleStore<User>,
        IUserClaimStore<User>,
        IUserPasswordStore<User>,
        IUserSecurityStampStore<User>,
        IUserEmailStore<User>,
        IUserLockoutStore<User>,
        IUserPhoneNumberStore<User>,
        IUserTwoFactorStore<User>,
        IUserAuthenticationTokenStore<User>,
        IQueryableUserStore<User>,
        IUserAuthenticatorKeyStore<User>,
        ITransientDependency
    {
        private readonly ITenantDbContext _tenantDbContext;

        public UserStore(ITenantDbContext tenantDbContext)
        {
            _tenantDbContext = tenantDbContext;
        }

        public IMongoCollection<User> Collection => _tenantDbContext.DbSet<User>(User.CollectionName);

        public IQueryable<User> Users => Collection.AsQueryable();

        public Task<string> GetUserIdAsync(User user, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.SeqId.ToString());
        }

        public Task<string> GetUserNameAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.UserName);
        }

        public Task SetUserNameAsync(User user, string userName,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.UserName = userName;
            return Task.FromResult(0);
        }

        public Task<string> GetNormalizedUserNameAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.UserName);
        }

        public Task SetNormalizedUserNameAsync(User user, string normalizedName,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.UserName = normalizedName;
            return Task.CompletedTask;
        }

        public async Task<IdentityResult> CreateAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            await Collection.InsertOneAsync(user, cancellationToken: cancellationToken).ConfigureAwait(false);
            return IdentityResult.Success;
        }

        public async Task<IdentityResult> UpdateAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.ConcurrencyStamp = Guid.NewGuid().ToString();
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, user.SeqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            var result = await Collection
                .ReplaceOneAsync(filter, user, new UpdateOptions() {IsUpsert = false}, cancellationToken)
                .ConfigureAwait(false);

            return result.IsModifiedCountAvailable && result.ModifiedCount == 1
                ? IdentityResult.Success
                : IdentityResult.Failed();
        }

        /// <summary>
        /// 部分更新
        /// </summary>
        /// <returns></returns>
        public async Task<IdentityResult> PartUpdateAsync(User user, UpdateDefinition<User> update,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.ConcurrencyStamp = Guid.NewGuid().ToString();
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, user.SeqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            var result = await Collection
                .UpdateOneAsync(filter, update, new UpdateOptions() {IsUpsert = false}, cancellationToken)
                .ConfigureAwait(false);

            return result.IsModifiedCountAvailable && result.ModifiedCount == 1
                ? IdentityResult.Success
                : IdentityResult.Failed();
        }

        public async Task<IdentityResult> DeleteAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(user, nameof(user));

            var filter = Builders<User>.Filter.Eq(u => u.SeqId, user.SeqId);
            var update = Builders<User>.Update.Set(u => u.IsDeleted, false);

            await Collection.UpdateOneAsync(filter, update).ConfigureAwait(false);

            return IdentityResult.Success;
        }

        public Task<User> FindByIdAsync(string userId, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, userId.To<long>()),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            return Collection.Find(filter).FirstOrDefaultAsync(cancellationToken);
        }

        public Task<User> FindByNameAsync(string normalizedUserName,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            Check.NotNull(normalizedUserName, nameof(normalizedUserName));

            var query = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.UserName, normalizedUserName),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            return Collection.Find(query).FirstOrDefaultAsync(cancellationToken);
        }

        public Task AddLoginAsync(User user, UserLoginInfo login,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task RemoveLoginAsync(User user, string loginProvider, string providerKey,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task<IList<UserLoginInfo>> GetLoginsAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task<User> FindByLoginAsync(string loginProvider, string providerKey,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public async Task AddToRoleAsync(User user, string roleName,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(user, nameof(user));
            Check.NotNull(roleName, nameof(roleName));

            if (await IsInRoleAsync(user, roleName, cancellationToken))
            {
                return;
            }

            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, user.SeqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );
            var update = Builders<User>.Update.PullFilter(u => u.Roles, ur => ur.Name == roleName);

            await this.Collection.UpdateOneAsync(filter, update, cancellationToken: cancellationToken);

        }

        public async Task RemoveFromRoleAsync(User user, string roleName,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(user, nameof(user));

            if (string.IsNullOrWhiteSpace(roleName))
            {
                throw new ArgumentException(nameof(roleName) + " can not be null or whitespace");
            }

            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, user.SeqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            var update = Builders<User>.Update.PullFilter(u => u.Roles, ur=>ur.Name== roleName);

            await this.Collection.UpdateOneAsync(filter, update, cancellationToken: cancellationToken);
        }

        public async Task<IList<string>> GetRolesAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(user, nameof(user));

            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, user.SeqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            var project = Builders<User>.Projection.Include(u => u.Roles).Include(u => u.SeqId);

            var doc = await this.Collection.Find(filter).Project(project)
                .FirstOrDefaultAsync(cancellationToken: cancellationToken);
            var userRoles = doc.BsonTo<User>()?.Roles ?? new List<UserRoleRel>();

            return userRoles.Select(ur => ur.Name).ToList();
        }

        public async Task<bool> IsInRoleAsync(User user, string roleName,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(user, nameof(user));

            if (string.IsNullOrWhiteSpace(roleName))
            {
                throw new ArgumentException(nameof(roleName) + " can not be null or whitespace");
            }

            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, user.SeqId),
                Builders<User>.Filter.ElemMatch(u => u.Roles, Builders<UserRoleRel>.Filter.Eq(ur=>ur.Name, roleName))
            );

            var count = await Collection.CountDocumentsAsync(filter, cancellationToken: cancellationToken);

            return count > 0;
        }

        public Task<IList<User>> GetUsersInRoleAsync(string roleName,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public async Task<IList<Claim>> GetClaimsAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(user, nameof(user));

            return new List<Claim>();
        }

        public Task AddClaimsAsync(User user, IEnumerable<Claim> claims,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task ReplaceClaimAsync(User user, Claim claim, Claim newClaim,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task RemoveClaimsAsync(User user, IEnumerable<Claim> claims,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task<IList<User>> GetUsersForClaimAsync(Claim claim,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task SetPasswordHashAsync(User user, string passwordHash,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.Password = passwordHash;
            return Task.CompletedTask;
        }

        public Task<string> GetPasswordHashAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.Password);
        }

        public Task<bool> HasPasswordAsync(User user, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.Password != null);
        }

        public Task SetSecurityStampAsync(User user, string stamp,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.SecurityStamp = stamp;
            return Task.CompletedTask;
        }

        public Task<string> GetSecurityStampAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.SecurityStamp);
        }

        public Task SetEmailAsync(User user, string email,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.Email = email;
            return Task.CompletedTask;
        }

        public Task<string> GetEmailAsync(User user, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.Email);
        }

        public Task<bool> GetEmailConfirmedAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.IsEmailConfirmed);
        }

        public Task SetEmailConfirmedAsync(User user, bool confirmed,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.IsEmailConfirmed = confirmed;
            return Task.CompletedTask;
        }

        public Task<User> FindByEmailAsync(string normalizedEmail,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.Email, normalizedEmail),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            return Collection.Find(filter).FirstOrDefaultAsync(cancellationToken);
        }

        public Task<string> GetNormalizedEmailAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.Email);
        }

        public Task SetNormalizedEmailAsync(User user, string normalizedEmail,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.Email = normalizedEmail;
            return Task.CompletedTask;
        }

        public Task<DateTimeOffset?> GetLockoutEndDateAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            if (!user.LockoutEndDateUtc.HasValue)
            {
                return Task.FromResult<DateTimeOffset?>(null);
            }

            var lockoutEndDate = DateTime.SpecifyKind(user.LockoutEndDateUtc.Value, DateTimeKind.Utc);
            return Task.FromResult<DateTimeOffset?>(new DateTimeOffset(lockoutEndDate));
        }

        public Task SetLockoutEndDateAsync(User user, DateTimeOffset? lockoutEnd,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.LockoutEndDateUtc = lockoutEnd?.UtcDateTime;
            return Task.CompletedTask;
        }

        public async Task<int> IncrementAccessFailedCountAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();

            Check.NotNull(user, nameof(user));

            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, user.SeqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );
            var update = Builders<User>.Update.Inc(usr => usr.AccessFailedCount, 1);
            var findOneAndUpdateOptions = new FindOneAndUpdateOptions<User, int>
            {
                ReturnDocument = ReturnDocument.After,
                Projection = Builders<User>.Projection.Expression(usr => usr.AccessFailedCount)
            };

            var newCount = await Collection
                .FindOneAndUpdateAsync(filter, update, findOneAndUpdateOptions,
                    cancellationToken = default(CancellationToken))
                .ConfigureAwait(false);

            user.AccessFailedCount = newCount;

            return user.AccessFailedCount;
        }

        public Task ResetAccessFailedCountAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.AccessFailedCount = 0;
            return Task.CompletedTask;
        }

        public Task<int> GetAccessFailedCountAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.AccessFailedCount);
        }

        public Task<bool> GetLockoutEnabledAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.IsLockoutEnabled);
        }

        public Task SetLockoutEnabledAsync(User user, bool enabled,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.IsLockoutEnabled = enabled;
            return Task.CompletedTask;
        }

        public Task SetPhoneNumberAsync(User user, string phoneNumber,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.Phone = phoneNumber;
            return Task.CompletedTask;
        }

        public Task<string> GetPhoneNumberAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.Phone);
        }

        public Task<bool> GetPhoneNumberConfirmedAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.IsPhoneConfirmed);
        }

        public Task SetPhoneNumberConfirmedAsync(User user, bool confirmed,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.IsPhoneConfirmed = confirmed;
            return Task.CompletedTask;
        }

        public Task SetTwoFactorEnabledAsync(User user, bool enabled,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            user.IsTwoFactorEnabled = enabled;
            return Task.CompletedTask;
        }

        public Task<bool> GetTwoFactorEnabledAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            Check.NotNull(user, nameof(user));
            return Task.FromResult(user.IsTwoFactorEnabled);
        }

        public Task SetTokenAsync(User user, string loginProvider, string name, string value,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task RemoveTokenAsync(User user, string loginProvider, string name,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task<string> GetTokenAsync(User user, string loginProvider, string name,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task SetAuthenticatorKeyAsync(User user, string key,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public Task<string> GetAuthenticatorKeyAsync(User user,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
        }

        public async Task<string> GetOldUserNameBySeqId(long seqId)
        {
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, seqId),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );
            // 仅获取userName字段
            var project = Builders<User>.Projection.Include(u => u.UserName);

            var doc = await Collection.Find(filter).Project(project).FirstOrDefaultAsync();

            return doc.BsonTo<User>()?.UserName;
        }

        public virtual async Task<User> FindByNameOrEmailAsync(string userNameOrEmailAddress)
        {
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Or(
                    Builders<User>.Filter.Eq(u => u.Email, userNameOrEmailAddress),
                    Builders<User>.Filter.Eq(u => u.UserName, userNameOrEmailAddress)
                ),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            var project = Builders<User>.Projection.Exclude(u => u.Roles).Exclude(u => u.Groups)
                .Exclude(u => u.Permissions);

            var doc = await Collection.Find(filter).Project(project).FirstOrDefaultAsync();

            return doc.BsonTo<User>();
        }

        #region IUserPermissionStore

        public Task AddPermissionAsync(User user, PermissionGrantInfo permissionGrant)
        {
            throw new NotImplementedException();
        }

        public Task RemovePermissionAsync(User user, PermissionGrantInfo permissionGrant)
        {
            throw new NotImplementedException();
        }

        public Task<IList<PermissionGrantInfo>> GetPermissionsAsync(long userId)
        {
            throw new NotImplementedException();
        }

        public Task<bool> HasPermissionAsync(long userId, PermissionGrantInfo permissionGrant)
        {
            throw new NotImplementedException();
        }

        public Task RemoveAllPermissionSettingsAsync(User user)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
