﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using MongoDB.Bson.Serialization.Attributes;
using Pwc.vProfile.Core.Tenants;

namespace Pwc.vProfile.Core.Apps
{
    [Table("tnt_apps")]
    public class App:MongoEntityBase
    {
        public const string CollectionName = "tnt_apps";

        public App()
        {
            IsActive = true;
        }

        public string Name { get; set; }

        public bool IsActive { get; set; }

        public string ConnStr { get; set; }

        public string LogoUrl { get; set; }

        public string SubUrl { get; set; }

        /// <summary>
        /// <see cref="AuthTypeEnum"/>
        /// 表示App的认证方式
        /// </summary>
        public string AuthType { get; set; }

        public bool IsTwoFactorEnabled { get; set; }

        public string Desc { get; set; }

        public bool IsDeleted { get; set; }

        /// <summary>
        /// app被收藏的次数
        /// </summary>
        public int FavCount { get; set; }

        public int LikeCount { get; set; }

        [BsonElement("creation_time")]
        public DateTime CreationTime { get; set; }

        [BsonElement("creator_user_id")]
        public long CreatorUserId { get; set; }

        [BsonElement("last_modification_time")]
        public DateTime? LastModificationTime { get; set; }

        [BsonElement("last_modifier_user_id")]
        public long? LastModifierUserId { get; set; }

        [BsonElement("deletion_time")]
        public DateTime? DeletionTime { get; set; }

        [BsonElement("deleter_user_id")]
        public long? DeleterUserId { get; set; }

    }
}
