﻿using System;
using System.Threading.Tasks;
using Abp;
using Abp.Timing;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Data;
using Pwc.vProfile.Data.TenantDb;

namespace Pwc.vProfile.Core.Apps
{
    public class AppManager:IAppManager
    {
        private readonly ITenantDbContext _tenantDbContext;

        public AppManager(ITenantDbContext tenantDbContext)
        {
            _tenantDbContext = tenantDbContext;
        }

        public IMongoCollection<App> Collection => _tenantDbContext.DbSet<App>(App.CollectionName);

        public async Task Create(App app)
        {
            Check.NotNull(app,nameof(app));

            app.CreationTime = Clock.Now;
            app.CreatorUserId = 0;
            app.FavCount = 0;
            app.LikeCount = 0;

            await Collection.InsertOneAsync(app);
        }

        public async Task Delete(string id)
        {
            Check.NotNullOrWhiteSpace(id, nameof(id));
            var objId = ObjectId.Parse(id);
            var filter = Builders<App>.Filter.Eq(a => a.Id, objId);
            await Collection.DeleteOneAsync(filter);
        }

        public async Task Update(App app)
        {
            Check.NotNull(app, nameof(app));

            var filter = Builders<App>.Filter.Eq(a => a.Id, app.Id);
            var update = Builders<App>.Update.Combine(
                    Builders<App>.Update.Set(a=>a.Name,app.Name),
                    Builders<App>.Update.Set(a=>a.Name,app.Name),
                    Builders<App>.Update.Set(a=>a.IsActive, app.IsActive),
                    Builders<App>.Update.Set(a=>a.LogoUrl, app.LogoUrl),
                    Builders<App>.Update.Set(a=>a.AuthType, app.AuthType),
                    Builders<App>.Update.Set(a=>a.IsTwoFactorEnabled, app.IsTwoFactorEnabled),
                    Builders<App>.Update.Set(a=>a.Desc, app.Desc)
                );

            await Collection.UpdateOneAsync(filter, update);
        }
    }
}
