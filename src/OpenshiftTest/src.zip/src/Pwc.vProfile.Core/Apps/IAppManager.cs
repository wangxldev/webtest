﻿using System.Threading.Tasks;
using Abp.Dependency;
using MongoDB.Bson;
using MongoDB.Driver;

namespace Pwc.vProfile.Core.Apps
{
    public interface IAppManager:ITransientDependency
    {
        IMongoCollection<App> Collection { get; }

        Task Create(App app);

        Task Delete(string id);

        Task Update(App app);
    }
}
