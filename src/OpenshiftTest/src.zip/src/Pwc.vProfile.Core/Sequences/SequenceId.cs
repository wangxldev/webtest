﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using MongoDB.Bson.Serialization.Attributes;

namespace Pwc.vProfile.Core.Sequences
{
    [Table("tnt_sequence")]
    public class SequenceId:MongoEntityBase
    {
        public const string CollectionName = "tnt_sequence";

        /// <summary>
        /// <see cref="BussTypeEnum"/>
        /// </summary>
        [BsonElement("buss_type")]
        public string BussType { get; set; }

        [BsonElement("counter")]
        public long Counter { get; set; } = 0;
    }
}
