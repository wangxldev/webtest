﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using Pwc.vProfile.Data;
using Pwc.vProfile.Data.TenantDb;

namespace Pwc.vProfile.Core.Sequences
{
    public class SequenceIdManager:ISequenceIdManager
    {
        private readonly ITenantDbContext _tenantDbContext;

        public SequenceIdManager(ITenantDbContext tenantDbContext)
        {
            _tenantDbContext = tenantDbContext;
        }


        public IMongoCollection<SequenceId> Collection => _tenantDbContext.DbSet<SequenceId>(SequenceId.CollectionName);


        public async Task<long> GetNewtUserId()
        {
            return await GetNewId(BussTypeEnum.User);
        }

        public async Task<long> GetNewRoleId()
        {
            return await GetNewId(BussTypeEnum.Role);
        }

        public async Task<long> GetNewGroupId()
        {
            return await GetNewId(BussTypeEnum.Group);
        }

        public async Task<long> GetNewId(string bussType)
        {
            var filter = Builders<SequenceId>.Filter.Eq(s => s.BussType,value:bussType);
            var update = Builders<SequenceId>.Update.Inc(s => s.Counter, 1);

            var sequenceId = await Collection.FindOneAndUpdateAsync(filter, update, new FindOneAndUpdateOptions<SequenceId>()
            {
                BypassDocumentValidation = true,
                IsUpsert = true,
            });

            // 在这里,当没有改bussType对应的Counter时,第一次调用会返回null,这时候则直接返回1

            return sequenceId?.Counter + 1 ?? 1;
        }
    }
}
