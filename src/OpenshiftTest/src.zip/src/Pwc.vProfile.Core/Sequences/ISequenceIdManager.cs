﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Dependency;
using MongoDB.Driver;

namespace Pwc.vProfile.Core.Sequences
{
    public interface ISequenceIdManager:ITransientDependency
    {
        IMongoCollection<SequenceId> Collection { get; }

        Task<long> GetNewtUserId();

        Task<long> GetNewRoleId();

        Task<long> GetNewGroupId();

        Task<long> GetNewId(string bussType);


    }
}
