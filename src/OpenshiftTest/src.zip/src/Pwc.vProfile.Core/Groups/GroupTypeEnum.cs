﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Groups
{
  

    public static class GroupTypeEnum
    {
        public const string SuperGroup = "~";
        public const string MasterGroup = "MasterGroup";
        public const string AppGroup = "AppGroup";
    }
}
