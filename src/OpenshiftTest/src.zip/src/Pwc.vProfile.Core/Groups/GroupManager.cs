﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Dependency;
using Abp.UI;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.Core.Sequences;
using Pwc.vProfile.Data;
using Pwc.vProfile.Data.TenantDb;
using Pwc.vProfile.Utility.Extensions;

namespace Pwc.vProfile.Core.Groups
{
    public class GroupManager:IGroupManager, ITransientDependency
    {
        private readonly ITenantDbContext _tenantDbContext;
        private readonly ISequenceIdManager _sequenceIdManager;

        public GroupManager(ITenantDbContext tenantDbContext, ISequenceIdManager sequenceIdManager)
        {
            _tenantDbContext = tenantDbContext;
            _sequenceIdManager = sequenceIdManager;
        }
        public IMongoCollection<Group> Collection => _tenantDbContext.DbSet <Group>(Group.CollectionName);
        public async Task Add(Group group)
        {
            //need update exist group tree node
            //1. update node
            //2. add parent node (a. IsSupper ;b. IsInsert)
            //3. add subnode
            //to do 

            var currDateTime = DateTime.Now;

            var sequenceId = await _sequenceIdManager.GetNewGroupId() ;
            group.SeqId = (Int32)sequenceId;
            group.Name = FormatSpecialCharacters(group.Name);

            if (sequenceId == 1)
            {
                //init root
                Group _grp = new Group()
                {
                    SeqId= 0,
                    Name = GroupTypeEnum.SuperGroup,
                    ParentId = -1,
                    Path = "",
                    Level = 0,
                    Remark = GroupTypeEnum.SuperGroup,
                    CreationTime = currDateTime,
                    CreatorUserId = 999999999
                };
                await Collection.InsertOneAsync(_grp);
            }


            //the oldest
            ////check exist
            var existGroup = await Collection.Find(_ => _.Name == group.Name).FirstOrDefaultAsync();
            if (existGroup!=null)
            {
                throw new UserFriendlyException("The same group is exist!");
            }
            //await Collection.ReplaceOneAsync(
            //            filter: new BsonDocument("Name", group.Name),
            //            replacement: group, options: new UpdateOptions { IsUpsert = true });


            //await  Collection.InsertOneAsync(group);

            //but if one group belonging to two group, then it will be not ok
            //1.Get current node via parent node
            //var parentNode =  Collection.Find(_ => _.Name == group.ParentId).Single();
            //if (parentNode == null)
            //{
            //    //is root
            //    group.ParentId = "";//need pass in
            //    group.Path = "";    //auto recalc
            //    group.Level = 0;    //auto recalc
            //    await Collection.ReplaceOneAsync(
            //            filter: new BsonDocument("Name", group.Name),
            //            replacement: group, options: new UpdateOptions { IsUpsert = true });
            //}
            //else
            //{
            //    //get the parentnode and verify, org path, recalc level
            //    var parentPath = parentNode.Path;
            //    var parentName = parentNode.Name;
            //    var currentPath = string.Format("{0}/{1}/", parentPath.TrimEnd('/'), parentName);
            //    var currentLevel = currentPath.Split('/').Length - 2;
            //}

            //only need CurrentNode and ParentId, calc in this method, org the path and calc the level
            //Add root node, update all
            if (group.ParentId==0)
            {
                group.Level = 1;
                group.Path = string.Format("/{0}/", GroupTypeEnum.SuperGroup);
                group.CreationTime = currDateTime;
                await Collection.InsertOneAsync(group);
            }
            else
            {
                //get parent path
                var parentNode= await Collection.Find(_ => _.SeqId == group.ParentId).SingleOrDefaultAsync();
                if (parentNode != null)
                {
                    var parentPath = parentNode.Path;
              
                    var currSinglePath = string.Format("/{0}/", parentNode.Name);
                    var currPath = string.Format("{0}{1}", parentPath.TrimEnd('/'),currSinglePath);
                    group.Path = currPath;
                    group.Level= CalcLevelByPath(currPath);
                    group.CreationTime = currDateTime;
                    await Collection.InsertOneAsync(group);
                }
                else
                {
                    throw new UserFriendlyException("There is no such node!");
                }
            }

            //add sub node, only add

            //ignore insert
            //insert node, update the path contains, level and parentid
        }
        private int CalcLevelByPath(string currPath)
        {
            return currPath.Split('/').Length - 2;
        }
        private string FormatSpecialCharacters(string input)
        {
            if (input.Length == 1)
            {
                input = string.Format("{0}1", input);
            }
            return input.Replace('/', '_');
        }
        //add a method update node name
        public async Task<List<Group>> GetListAll()
        {
            return await Collection.Find(Builders<Group>.Filter.Empty).ToListAsync();
        }
        public async Task<List<Group>> GetList(string name)
        {
            return await Collection.Find(_ => _.Name.Contains(name)).ToListAsync();
        }
        public async Task<Group> Get(string name)
        {
            return await Collection.Find(_ => _.Name == name).SingleAsync();
        }
        public async Task MoveGroup (string movingGroupName,string targetGroupName)
        {
            //check the old node and new node
            var moving = await Collection.Find(_ => _.Name == movingGroupName).SingleOrDefaultAsync();
            //var movingUpper = Collection.Find(_ => _.SeqId ==  moving.ParentId).Single();

            var target= await Collection.Find(_ => _.Name == targetGroupName).SingleOrDefaultAsync();
            if (target == null)
            {
                throw new UserFriendlyException("The target is not exist!");
            }

            //if (movingUpper==null)
            if (string.IsNullOrEmpty(moving.Path))
            {
                throw new UserFriendlyException("The root node is not exist!");
            }
            else
            {
                //1.get his path and splice itself
                //var movingUpperPath = movingUpper.Path;
                //var movingItself = movingGroupName;
                //var movingSplicePath = string.Format("{0}|{1}|", movingUpperPath.TrimEnd('|'), movingItself);
                var movingSplicePath = moving.Path;

                //2.get target node's path and splice itself
                var targetUpperPath = target.Path;
                var targetItself = targetGroupName;
                var targetSplicePath = string.Format("{0}/{1}/", targetUpperPath.TrimEnd('/'), targetItself);

                //3.mongodb replace path where parent node is moving
                //var filter = Builders<Group>.Filter.And(
                //    Builders<Group>.Filter.Eq(u => u.ParentId, moving.SeqId)
                //);

                var filter = Builders<Group>.Filter.And(
                    Builders<Group>.Filter.Gte(u => u.Level, moving.Level),
                    Builders<Group>.Filter.Regex(u => u.Path, new BsonRegularExpression(movingSplicePath, "i"))
                );

                //var regex = string.Format("^{0}", movingSplicePath);
                //var filter = Builders<Group>.Filter.Regex(u=>u.Path, new BsonRegularExpression(movingSplicePath,"i"));

                var toUpdateList = await Collection.Find(filter).ToListAsync();
                for (int i=0;i< toUpdateList.Count; i++)
                {
                    toUpdateList[i].Path = toUpdateList[i].Path.Replace(movingSplicePath, targetSplicePath);
                    toUpdateList[i].Level = CalcLevelByPath(toUpdateList[i].Path);
                }

                moving.ParentId = target.SeqId;
                await Update(moving);

                await UpdatePathList(toUpdateList);
            }


            //get current


            //get new 

            //update

            //same like delete
        }
        public async Task Update(Group group)
        {
            //need update exist group tree node
            //1. update node
            //2. add parent node (a. IsSupper ;b. IsInsert)
            //3. add subnode
            //to do

            var filter = Builders<Group>.Filter.And(
                Builders<Group>.Filter.Eq(u => u.Name, group.Name)
            );

            var update = Builders<Group>.Update.Combine(
                   Builders<Group>.Update.Set(u => u.ParentId, group.ParentId),
                   Builders<Group>.Update.Set(u => u.Remark, group.Remark),
                   Builders<Group>.Update.Set(u => u.UserCount, group.UserCount),
                   Builders<Group>.Update.Set(u => u.GroupType, group.GroupType),
                   Builders<Group>.Update.Set(u => u.RoleIds, group.RoleIds)
            );

            await Collection.UpdateOneAsync(
                        filter,
                        update);
 
        }

        private async Task UpdatePath(Group group)
        {
            //need update exist group tree node
            //1. update node
            //2. add parent node (a. IsSupper ;b. IsInsert)
            //3. add subnode
            //to do

            var filter = Builders<Group>.Filter.And(
                Builders<Group>.Filter.Eq(u => u.Id, group.Id)
            );

 
            var update = Builders<Group>.Update.Combine(
               Builders<Group>.Update.Set(u => u.Path, group.Path),
               Builders<Group>.Update.Set(u => u.Level, group.Level) 
            );

            await Collection.UpdateOneAsync(
                        filter,
                        update);

        }
        /// <summary>
        /// Group Name is unique
        /// </summary>
        /// <param name="grouplist"></param>
        /// <returns></returns>
        public async Task UpdateList(List<Group> grouplist)
        {
            foreach (var grp in grouplist)
            {
                //need update exist group tree node
                //to do

                //await Collection.ReplaceOneAsync(
                //        item => item.Name == grp.Name,
                //        grp,
                //        new UpdateOptions { IsUpsert = true });
                await Update(grp);
            }
        }
        private async Task UpdatePathList(List<Group> grouplist)
        {
            foreach (var grp in grouplist)
            {
                //need update exist group tree node
                //to do

                //await Collection.ReplaceOneAsync(
                //        item => item.Name == grp.Name,
                //        grp,
                //        new UpdateOptions { IsUpsert = true });
                await UpdatePath(grp);
            }
        }
        public async Task Delete(string name)
        {
            var deleting =await Collection.Find(_ => _.Name == name).SingleOrDefaultAsync();

            var deletingUpperPath = deleting.Path;
            var deletingItself = name;
            var deletingSplicePath = string.Format("{0}/{1}/", deletingUpperPath.TrimEnd('/'), deletingItself);
  
            //need update exist group tree node
            //to do
            await Collection.DeleteOneAsync(item => item.Name == name);

            //
            
            var filter = Builders<Group>.Filter.And(
                    Builders<Group>.Filter.Gte(u => u.Level, deleting.Level),
                    Builders<Group>.Filter.Regex(u => u.Path, new BsonRegularExpression(deletingSplicePath, "i"))
                );

            await Collection.DeleteManyAsync(filter);
        }

        public async Task DeleteList(List<Group> grouplist)
        {
            //need update exist group tree node
            //to do
            foreach (var grp in grouplist)
            {
                //await Collection.DeleteOneAsync(
                //        item => item.Name == grp.Name );
                await Delete(grp.Name);
            }
        }
        public async Task DeleteAll()
        {
            await Collection.DeleteManyAsync(Builders<Group>.Filter.Empty);
        }

        public async Task IncGroupUserCount(long groupSeqId)
        {
            var filter = Builders<Group>.Filter.Eq(u => u.SeqId, groupSeqId);

            var update =Builders<Group>.Update.Inc(s => s.UserCount, 1);

            await Collection.FindOneAndUpdateAsync(
                        filter,
                        update,
                        new FindOneAndUpdateOptions<Group>()
                        {
                            BypassDocumentValidation = true,
                            IsUpsert = true
                        });
        }
        public async Task DecGroupUserCount(long groupSeqId)
        {
            var filter = Builders<Group>.Filter.Eq(u => u.SeqId, groupSeqId);

            var update = Builders<Group>.Update.Inc(s => s.UserCount, -1);

            await Collection.FindOneAndUpdateAsync(
                        filter,
                        update,
                        new FindOneAndUpdateOptions<Group>()
                        {
                            BypassDocumentValidation = true,
                            IsUpsert = true
                        });
        }

        public async Task<int> GetUserCountByGroupName(long groupSeqId)
        {
            
            var Group= await Collection.Find(_ => _.SeqId == groupSeqId).SingleAsync();
            if (Group != null)
            {
                return Group.UserCount;
            }
            else
            {
                return 0;
            }

        }

        public async Task<List<Group>> GetListByIds(List<int> groupIds, ProjectionDefinition<Group> projection=null)
        {
            var filter = Builders<Group>.Filter.And(
                    Builders<Group>.Filter.In(g=>g.SeqId,groupIds)
                    );

            if (projection != null)
            {
                var docList = await Collection.Find(filter).Project(projection).ToListAsync();
                return docList.BsonToList<Group>();
            }

            return await Collection.Find(filter).ToListAsync();
        }
    }
}
