﻿using Abp.Dependency;
using Newtonsoft.Json.Linq;
using Pwc.vProfile.Core.Auth.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pwc.vProfile.Core.Groups
{
    public class GroupRule:ITransientDependency
    {
        public  void CheckGroupRule(string orgcode,string groupRules, string groupRuleName,User user,Group rootgroup)
        {
            if (!string.IsNullOrEmpty(groupRules))
            {

                //get org grouprules
                List<Dictionary<string, object>> grouprulelist = new List<Dictionary<string, object>>();
                JArray rules = new JArray();
                //string grouprulecontenttype = org["GroupRules"].GetType().Name;
                //if (grouprulecontenttype == "JArray")
                //{
                //    rules = org["GroupRules"] as JArray;
                //}
                //else
                //{
                //    rules = JArray.Parse(org["GroupRules"].ToJson());
                //}
                rules = JArray.Parse(groupRules);
                foreach (var rule in rules)
                {
                    Dictionary<string, object> rulesetting = new Dictionary<string, object>();
                    rulesetting.Add("Name", rule["Name"].ToString());
                    rulesetting.Add("Expression", rule["Expression"]);
                    rulesetting.Add("Groups", rule["Groups"].ToArray());
                    if (string.IsNullOrEmpty(groupRuleName) || rule["Name"].ToString() == groupRuleName)
                        grouprulelist.Add(rulesetting);
                }

                //get groups dic
                foreach (Dictionary<string, object> kvp in grouprulelist)
                {

                    JObject exp = (kvp["Expression"] as JObject);

                    string jname = string.Empty;
                    if (exp.HasValues)
                        jname = exp.Properties().Select(p => p.Name).ToList().First();
                    string subparserlog = string.Empty;
                    //The result of expression: string.IsNullOrEmpty(jname) is default all true that will join to group.
                    if (string.IsNullOrEmpty(jname) || ComputeRule(jname, exp[jname], user, out subparserlog))
                    {
                        foreach (JToken group in JToken.FromObject(kvp["Groups"]).Children())
                        {
                            //string groupstatusmsg = StatusMsgEnum.Success.ToString();
                            bool autogenerate = group["AutoGenerate"].Value<bool>();
                            string grouppath = group["GroupName"].ToString();
                            string currentgrouppath = rootgroup.Name;

                            //find leafgroup and create group if it's not existed
                            if (!string.IsNullOrEmpty(grouppath))
                            {
                                Dictionary<string, object> currentgroup = null;
                                string parentgroupid = rootgroup.ParentId.ToString();
                                foreach (string levelgroupname in grouppath.Split('.'))
                                {
                                    //build one level group name
                                    string currentgroupname = string.Empty;
                                    foreach (string groupnameitem in levelgroupname.Split('+'))
                                    {
                                        if (groupnameitem.Contains("->") && groupnameitem.Contains("*"))
                                        {
                                            string[] foreignkeyvalue = groupnameitem.Split("->".ToArray());
                                            string foreignkey = foreignkeyvalue[0].TrimStart('*');
                                            string[] codetablekeyvalue = foreignkeyvalue[2].Split('[');
                                            string codetablename = codetablekeyvalue[0];
                                            string codetablecolumnname = codetablekeyvalue[1].TrimEnd(']');

                                            //what logic buss?  get data from code table?
                                            Dictionary<string, object> codetablerow = new Dictionary<string, object>();// get from masterdata GetCodeTableSingleRowByUniqueID(orgcode, codetablename, user.Extends[foreignkey]);
                                            if (codetablerow!=null)
                                            {
                                                string codetableattribute = codetablerow.TryGetStringValue(codetablecolumnname);
                                                if (!string.IsNullOrEmpty(codetableattribute))
                                                {
                                                    currentgroupname += codetableattribute;
                                                }
                                                else
                                                {
                                                    currentgroupname = string.Empty;
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                currentgroupname = string.Empty;
                                                break;
                                            }
                                        }
                                        else if (groupnameitem.Contains("*"))
                                        {
                                            string userattribute = user.Extends[groupnameitem.TrimStart('*')];
                                            if (!string.IsNullOrEmpty(userattribute))
                                            {
                                                currentgroupname += userattribute;
                                            }
                                            else
                                            {
                                                currentgroupname = string.Empty;
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            currentgroupname += groupnameitem;
                                        }
                                    }

                                    // find group or generate group
                                    if (!string.IsNullOrEmpty(currentgroupname))
                                    {
                                        //orggroups = GetGroupsByOrgCode(orgcode);  //tenane different database so needn't
                                        //var groupquery = orggroups.Where(o => o.TryGetStringValue("GroupName") == currentgroupname);
                                        //if (!groupquery.IsNull() && groupquery.Count() > 0)
                                        //{
                                        //    currentgroup = groupquery.First();

                                        //    parentgroupid = currentgroup["GroupID"].ToString();
                                        //}
                                        if (1==2)
                                        {
                                            //query group from group table?
                                        }
                                        else if (autogenerate)
                                        {
                                            currentgrouppath += "." + currentgroupname;
                                            currentgroup = new Dictionary<string, object>();
                                            string currentgroupid = Guid.NewGuid().ToString();
                                            currentgroup.Add("GroupID", currentgroupid);
                                            currentgroup.Add("GroupName", currentgroupname);
                                            currentgroup.Add("ParentID", parentgroupid);
                                            currentgroup.Add("OrganizationCode", orgcode);
                                            currentgroup.Add("GroupDescription", currentgrouppath);

                                            //add group
                                            //groupstatusmsg = SyncUser_AddGroup(currentgroup);
                                            //groupstatusmsg = AddGroup(currentgroup);
                                            //if (groupstatusmsg.IsMsgSuccess()) parentgroupid = currentgroupid;
                                        }
                                        else
                                        {
                                            currentgroup = null;
                                            //groupstatusmsg = "not found group and user cancel generate group:'" + currentgroupname + "'\n";
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        //groupstatusmsg = StatusMsgEnum.InvalidGroupName.ToString() + "(" + currentgroupname + ")\n";
                                        break;
                                    }
                                }

                                //add user to leafgroup
                                //if (groupstatusmsg.IsMsgSuccess())
                                //{
                                //    if (!currentgroup.IsNull())
                                //    {
                                //        if (!neodao.FindRelation(currentgroup.TryGetStringValue("GroupID"), "Groups", user.TryGetStringValue("UserID"), "Users", Neo4jMappingEnum.MappingGroupUser.ToString(), RelationLevelEnum.System.ToString()))
                                //        {
                                //            groupstatusmsg = SyncUser_AddUserToGroup(user.TryGetStringValue("UserID"), currentgroup.TryGetStringValue("GroupID"), RelationLevelEnum.System.ToString());
                                //        }
                                //    }
                                //    else
                                //    {
                                //        groupstatusmsg = StatusMsgEnum.NotFoundGroup.ToString() + "(" + currentgrouppath + ")";
                                //    }
                                //}
                            }
                        }
                    }
                }
            }
        }


        private   bool ComputeRule(string expname, JToken expvalue, User user, out string subparserlog)
        {
            subparserlog = "";
            try
            {
                if (expvalue != null)
                {
                    switch (expname)
                    {
                        case "NOT":
                            var jname = (expvalue as JObject).Properties().Select(o => o.Name).First();
                            return !ComputeRule(jname, expvalue[jname], user, out subparserlog);

                        case "AND":
                            var andchilds = expvalue.Children();
                            if (andchilds.Count() == 2)
                            {
                                var andarr = andchilds.ToArray();
                                JObject c1 = andarr[0] as JObject;
                                string c1key = c1.Properties().Select(o => o.Name).First();
                                JObject c2 = andarr[1] as JObject;
                                string c2key = c2.Properties().Select(o => o.Name).First();
                                //JToken c1exp = c1.GetValue(c1key).Children().First();
                                //JToken c2exp = c2.GetValue(c2key).Children().First();
                                JToken c1exp = c1.GetValue(c1key);
                                JToken c2exp = c2.GetValue(c2key);
                                return ComputeRule(c1key, c1exp, user, out subparserlog) && ComputeRule(c2key, c2exp, user, out subparserlog);
                            }
                            else
                            {
                                throw new Exception(expname + "'s value error");
                            }
                        case "OR":
                            var orchilds = expvalue.Children();
                            if (orchilds.Count() == 2)
                            {
                                var orarr = orchilds.ToArray();
                                JObject c1 = orarr[0] as JObject;
                                string c1key = c1.Properties().Select(o => o.Name).First();
                                JObject c2 = orarr[1] as JObject;
                                string c2key = c2.Properties().Select(o => o.Name).First();
                                //JToken c1exp = c1.GetValue(c1key).Children().First();
                                //JToken c2exp = c2.GetValue(c2key).Children().First();
                                JToken c1exp = c1.GetValue(c1key);
                                JToken c2exp = c2.GetValue(c2key);
                                return ComputeRule(c1key, c1exp, user, out subparserlog) || ComputeRule(c2key, c2exp, user, out subparserlog);
                            }
                            else
                            {
                                throw new Exception(expname + "'s value error");
                            }
                        case "EQ":

                            string jeqkey = string.Empty;
                            string jeqvalue = string.Empty;
                            GetExpressionValues(expvalue, out jeqkey, out jeqvalue);
                            if (jeqkey.Contains("*") && jeqvalue.Contains("*"))
                            {
                                return user.Extends[jeqkey.TrimStart('*')].ToString() != user.Extends[jeqvalue.TrimStart('*')].ToString();
                            }
                            else if (jeqkey.Contains('*'))
                            {
                                string usereqcolumnname = jeqkey.TrimStart('*');
                                return user.Extends[usereqcolumnname].ToString() == jeqvalue;
                            }
                            else if (jeqvalue.Contains("*"))
                            {
                                string usereqcolumnname = jeqvalue.TrimStart('*');
                                return jeqkey == user.Extends[usereqcolumnname].ToString();
                            }
                            else
                            {
                                return jeqkey.Equals(jeqvalue);
                            }
                        case "NE":
                            string jnekey = string.Empty;
                            string jnevalue = string.Empty;
                            GetExpressionValues(expvalue, out jnekey, out jnevalue);
                            if (jnekey.Contains("*") && jnevalue.Contains("*"))
                            {
                                return user.Extends[jnekey.TrimStart('*')].ToString() != user.Extends[jnevalue.TrimStart('*')].ToString();
                            }
                            else if (jnekey.Contains("*"))
                            {
                                string usernecolumnname = jnekey.TrimStart('*');
                                return user.Extends[usernecolumnname].ToString() != jnevalue;
                            }
                            else if (jnevalue.Contains("*"))
                            {
                                string usernecolumnname = jnevalue.TrimStart('*');
                                return jnekey != user.Extends[usernecolumnname].ToString();
                            }
                            else
                            {
                                return !jnekey.Equals(jnevalue);
                            }
                        case "ICEQ":
                            return ComputeRule("EQ",
                                GetLeafExpressionProperties(expvalue, user, IgnoreCaseType.tolower.ToString())
                                , user, out subparserlog);

                        case "ICNE":
                            return ComputeRule("NE",
                                GetLeafExpressionProperties(expvalue, user, IgnoreCaseType.tolower.ToString())
                                , user, out subparserlog);

                        case "CONTAINS":
                            string jcontainskey = string.Empty;
                            string jcontainsvalue = string.Empty;
                            GetExpressionValues(expvalue, out jcontainskey, out jcontainsvalue);
                            if (jcontainskey.Contains("*"))
                            {
                                string usernecolumnname = jcontainskey.TrimStart('*');
                                jcontainskey = user.Extends[usernecolumnname].ToString();
                            }
                            return jcontainskey.Contains(jcontainsvalue);

                        case "ICCONTAINS":
                            return ComputeRule("CONTAINS",
                                GetLeafExpressionProperties(expvalue, user, IgnoreCaseType.tolower.ToString())
                                , user, out subparserlog);

                        case "IN":
                            string jinkey = string.Empty;
                            string jinvalue = string.Empty;
                            GetExpressionValues(expvalue, out jinkey, out jinvalue);
                            JArray jarray = JArray.Parse(jinvalue);
                            string item = jinkey;
                            if (jinkey.Contains("*"))
                            {
                                string usernecolumnname = jinkey.TrimStart('*');
                                jinkey = user.Extends[usernecolumnname].ToString();
                            }
                            var res = jarray.Where(o => o.ToString() == jinkey).Count() > 0;
                            return res;

                        case "ICIN":
                            return ComputeRule("IN",
                                               GetLeafExpressionProperties(expvalue, user, IgnoreCaseType.tolower.ToString()),
                                               user, out subparserlog);
                    }
                    subparserlog = "Can not found operator.";
                    return false;
                }
                else
                {
                    subparserlog = "Expression values error.";
                    return false;
                }
            }
            catch
            {
                subparserlog = "an expression while ComputeRule.";
                return false;
            }
        }
        private   void GetExpressionValues(object expvalue, out string value1, out string value2, string ignorecase = "none")
        {
            value1 = null;
            value2 = null;
            JProperty jpexp;
            switch (expvalue.GetType().Name)
            {
                case "JProperty":
                    jpexp = (JProperty)expvalue;
                    break;

                case "JObject":
                    JObject joexp = (JObject)expvalue;
                    jpexp = joexp.Properties().First();
                    break;

                default:
                    jpexp = null;
                    break;
            }
            if (jpexp != null)
            {
                value1 = jpexp.Name;
                value2 = jpexp.Value.ToString();
                switch (ignorecase)
                {
                    case "tolower":
                        value1 = value1.ToLower();
                        value2 = value2.ToLower();
                        break;

                    case "toupper":
                        value1 = value1.ToUpper();
                        value2 = value2.ToUpper();
                        break;
                }
            }
        }

        private   JToken GetLeafExpressionProperties(object expvalue, User user, string ignorecase = "none")
        {
            JToken jresult = null;
            string value1 = null;
            string value2 = null;
            string usernecolumnname = string.Empty;
            JProperty jpexp;
            switch (expvalue.GetType().Name)
            {
                case "JProperty":
                    jpexp = (JProperty)expvalue;
                    break;

                case "JObject":
                    JObject joexp = (JObject)expvalue;
                    jpexp = joexp.Properties().First();
                    break;

                default:
                    jpexp = null;
                    break;
            }
            if (jpexp != null)
            {
                value1 = jpexp.Name;
                value2 = jpexp.Value.ToString().Replace("\r\n", "");
                switch (ignorecase)
                {
                    case "tolower":
                        if (value1.Contains('*'))
                        {
                            usernecolumnname = value1.TrimStart('*');
                            value1 = user.Extends[usernecolumnname].ToString().ToLower();
                        }
                        else
                        {
                            value1 = value1.ToLower();
                        }
                        if (value2.Contains('*'))
                        {
                            usernecolumnname = value2.TrimStart('*');
                            value2 = user.Extends[usernecolumnname].ToString().ToLower();
                        }
                        else
                        {
                            value2 = value2.ToLower();
                        }
                        break;

                    case "toupper":
                        if (value1.Contains('*'))
                        {
                            usernecolumnname = value1.TrimStart('*');
                            value1 = user.Extends[usernecolumnname].ToString().ToUpper();
                        }
                        else
                        {
                            value1 = value1.ToUpper();
                        }
                        if (value2.Contains('*'))
                        {
                            usernecolumnname = value2.TrimStart('*');
                            value2 = user.Extends[usernecolumnname].ToString().ToUpper();
                        }
                        else
                        {
                            value2 = value2.ToUpper();
                        }
                        break;
                }
                jresult = JProperty.Parse(
                    (value2.Contains("\"") || value2.Contains("[")) ?
                    "{\"" + value1 + "\":" + value2 + "}" :
                    "{\"" + value1 + "\":\"" + value2 + "\"}"
                    );
            }
            return jresult;
        }


    }

    public enum IgnoreCaseType
    {
        none,
        tolower,
        toupper,
    }
    public static class RefExtend
    {
        public static string TryGetStringValue(this Dictionary<string, object> self, string key)
        {
            string result = string.Empty;
            if (self!=null)
            {
                object value = null;
                if (self.TryGetValue(key, out value))
                {
                    try
                    {
                        result = value.ToString();
                    }
                    catch { }
                }
            }
            return result;
        }
    }
}
