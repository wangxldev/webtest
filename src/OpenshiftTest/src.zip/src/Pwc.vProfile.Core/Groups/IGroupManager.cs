﻿using Abp.Dependency;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;

namespace Pwc.vProfile.Core.Groups
{
    public interface IGroupManager : ITransientDependency
    {
        Task Add(Group group);
        Task<List<Group>> GetListAll();
        Task<List<Group>> GetList(string name );
        Task<Group> Get(string name);
        Task Update(Group group);
        Task UpdateList(List<Group> grouplist);

        Task Delete(string name);

        Task DeleteList(List<Group> grouplist);
        Task DeleteAll();

        Task MoveGroup(string movingGroupName, string targetGroupName);

        Task< int> GetUserCountByGroupName(long groupSeqId);

        Task<List<Group>> GetListByIds(List<int> groupIds, ProjectionDefinition<Group> projection = null);


    }
}
