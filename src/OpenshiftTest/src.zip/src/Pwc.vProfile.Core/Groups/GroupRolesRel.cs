﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Groups
{
    public class GroupRolesRel
    {
    }
}
