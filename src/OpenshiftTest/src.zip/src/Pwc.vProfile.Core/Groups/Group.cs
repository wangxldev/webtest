﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Pwc.vProfile.Core.Groups
{
    [Table("tnt_group")]
    public class Group: MongoEntityBase
    {
        public const string CollectionName = "tnt_group";

        public string Name { get; set; }

        public int Level { get; set; }
        
        /// <summary>
        /// 完整父路径
        /// /a/b/c/
        /// </summary>
        public string Path { get; set; }

        public long ParentId { get; set; }


        public string Remark { get; set; }

        public List<string> RoleIds { get; set; }

        public DateTime CreationTime { get; set; }

        public long CreatorUserId { get; set; }

        public string GroupType { get; set; }

        public int UserCount { get; set; }

        [BsonElement("seq_id")]
        public int SeqId { get; set; }
    }
}
