﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Dependency;
using MongoDB.Driver;

namespace Pwc.vProfile.Core.Favourites
{
    public interface IFavouriteManager
    {
        IMongoCollection<Favourite> Collection { get; }

        Task<List<Favourite>> GetListByUserId(long userId);

        Task Add(Favourite favourite);
    }
}
