﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Core.Favourites
{
    public static class FavoTypeEnum
    {
        public const string App = "app";
    }
}
