﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Dependency;
using Abp.Extensions;
using Abp.UI;
using MongoDB.Driver;
using Pwc.vProfile.Data;
using Pwc.vProfile.Data.TenantDb;

namespace Pwc.vProfile.Core.Favourites
{
    public class FavouriteManager: IFavouriteManager,ITransientDependency
    {
        private readonly ITenantDbContext _tenantDbContext;

        public FavouriteManager(ITenantDbContext tenantDbContext)
        {
            _tenantDbContext = tenantDbContext;
        }

        public IMongoCollection<Favourite> Collection => _tenantDbContext.DbSet<Favourite>(Favourite.CollectionName);

        public async Task<List<Favourite>> GetListByUserId(long userId)
        {
            var filter = Builders<Favourite>.Filter.Eq(s => s.UserId, userId);

            var list= await Collection.Find(filter).ToListAsync();

            return list;
        }

        public Task Add(Favourite favourite)
        {
//            if (favourite.UserId <= 0)
//            {
//                throw new UserFriendlyException("user id is invalid!");
//            }
//
//            if (favourite.ObjectId.IsNullOrWhiteSpace())
//            {
//                throw new UserFriendlyException("object id is invalid!");
//
//                throw new UserFriendlyException(XXX("ObjectIdInValid"));
//            }

            return null;
        }
    }
}
