﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Pwc.vProfile.Core.Favourites
{
    [Table("tnt_favorite")]
    public class Favourite:MongoEntityBase
    {
        public const string CollectionName = "tnt_favorite";

        public long UserId { get; set; }

        public string ObjectId { get; set; }

        /// <summary>
        /// <see cref="FavoTypeEnum"/>
        /// </summary>
        public string FavoTypeEnum { get; set; }

        public string CreationTime { get; set; }
    }
}
