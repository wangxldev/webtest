﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Pwc.vProfile.Utility
{
    public class RandomGenerator
    {
        private static readonly Random random = new Random();
          
        public  static string RandomString(int length)
        {
            const string pool = "abcdefghijklmnopqrstuvwxyz0123456789";
            var builder = new StringBuilder();

            for (var i = 0; i < length; i++)
            {
                var c = pool[random.Next(0, pool.Length)];
                builder.Append(c);
            }

            return builder.ToString();
        }

        public static string RandomStringByText(string text, int length)
        {
            //return Convert.ToBase64String( ProtectedData.Protect( Encoding.Unicode.GetBytes(text),null, DataProtectionScope.LocalMachine));
            if (text.Length< length)
            {
                text = text.PadRight(length);
            }
            return Convert.ToBase64String(Encoding.Unicode.GetBytes(text)).Substring(0, length);
        }
    }
}
