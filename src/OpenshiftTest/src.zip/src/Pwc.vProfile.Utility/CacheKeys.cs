﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Utility
{
    public static class CacheKeys
    {
        public static string BussType { get { return "BussType"; } }
    }
}
