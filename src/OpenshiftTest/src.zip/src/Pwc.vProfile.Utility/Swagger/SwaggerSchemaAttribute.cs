﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Utility.Swagger
{
    [AttributeUsage(AttributeTargets.Class,AllowMultiple = false)]
    public class SwaggerSchemaAttribute:Attribute
    {
        public SwaggerSchemaAttribute(string id)
        {
            Id = id;
        }

        public string Id { get; }

    }
}
