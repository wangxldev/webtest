﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp;
using Abp.AspNetCore;
using Abp.AspNetCore.Mvc.Results.Wrapping;
using Abp.Dependency;
using Abp.Modules;
using Abp.Reflection.Extensions;


namespace Pwc.vProfile.Utility
{
    [DependsOn(
        typeof(AbpAspNetCoreModule))]
    public class ProfileUtilityModule:AbpModule
    {
        public override void PreInitialize()
        {
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ProfileUtilityModule).GetAssembly());
        }
    }
}
