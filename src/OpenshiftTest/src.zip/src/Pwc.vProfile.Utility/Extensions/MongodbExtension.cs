﻿using System.Collections.Generic;
using System.Linq;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Serializers;

namespace Pwc.vProfile.Utility.Extensions
{
    public static class MongodbExtension
    {
        public static T BsonTo<T>(this BsonDocument document)
        {
            if (document == null) return default(T);

            return BsonSerializer.Deserialize<T>(document);
        }

        public static List<T> BsonToList<T>(this IEnumerable<BsonDocument> documents)
        {
            if (documents == null) return default(List<T>);

            var list = new List<T>();

            foreach (var doc in documents)
            {
                list.Add(BsonSerializer.Deserialize<T>(doc));
            }

            return list;


            // TODO 优化

//           BsonArray.Create()
//
//               BsonArraySerializer.Instance.Serialize();
//
//            return BsonSerializer.Deserialize<T>(document);
        }
    }
}
