﻿using Abp.AutoMapper;
using Pwc.vProfile.Core.Tenants;
using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Tenants.Dto
{
    [AutoMapTo(typeof(Tenant))]
    public class UpdateGroupRuleInput
    {
        public string Name { get; set; }
        public string GroupRule { get; set; }

    }
}
