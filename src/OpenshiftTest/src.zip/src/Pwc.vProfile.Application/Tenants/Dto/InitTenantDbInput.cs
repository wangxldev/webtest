﻿using Abp.AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using  Pwc.vProfile.Core.Tenants;

namespace Pwc.vProfile.Application.Tenants.Dto
{
    [AutoMapTo(typeof(Tenant))]
    public class InitTenantDbInput
    {

        public string Name { get; set; }

        public string FullName { get; set; }

        public string LogoUrl { get; set; }

        public string DbConnStr { get; set; }

        /// <summary>
        /// <see cref="AuthTypeEnum"/>
        /// </summary>
        public string AuthType { get; set; }

        public bool AllowRegister { get; set; }

        public string SecretKey { get; set; }

        public string GroupRule { get; set; }
    }
}
