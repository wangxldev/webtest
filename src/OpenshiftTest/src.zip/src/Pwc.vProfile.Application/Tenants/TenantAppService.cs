﻿
using Abp.Dependency;
using AutoMapper;
using Pwc.vProfile.Application.Tenants.Dto;
using Pwc.vProfile.Core.Tenants;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Pwc.vProfile.Application.Tenants
{
    public class TenantAppService:ITenantAppService,ITransientDependency
    {
        private readonly ITenantManager _tenantManager;

        public TenantAppService(ITenantManager tenantManager)
        {
            _tenantManager = tenantManager;
        }

        public async Task InitTenantDb(InitTenantDbInput input)
        {
            var tenant = Mapper.Map<Tenant>(input);
            await _tenantManager.InitTenantDb(tenant);
        }
        public async Task UpdateGroupRule(UpdateGroupRuleInput input)
        {
            var tenant = Mapper.Map<Tenant>(input);
            await _tenantManager.UpdateGroupRule(tenant);
        }
    }
}
