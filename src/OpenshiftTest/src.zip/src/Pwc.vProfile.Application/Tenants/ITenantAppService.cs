﻿using Abp.Dependency;
using Pwc.vProfile.Application.Tenants.Dto;
 
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Pwc.vProfile.Application.Tenants
{
    public interface ITenantAppService
    {
        Task InitTenantDb(InitTenantDbInput input);
        Task UpdateGroupRule(UpdateGroupRuleInput input);
    }
}
