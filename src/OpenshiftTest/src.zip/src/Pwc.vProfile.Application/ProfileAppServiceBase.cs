﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.Application.Services;
using Microsoft.AspNetCore.Identity;

namespace Pwc.vProfile.Application
{
    public abstract class ProfileAppServiceBase: ApplicationService
    {

    }
}
