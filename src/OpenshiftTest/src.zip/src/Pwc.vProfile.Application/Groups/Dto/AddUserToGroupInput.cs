﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Groups.Dto
{
    public class AddUserToGroupInput
    {
        public string userName { get; set; } 
        public long groupSeqId { get; set; }
    }
}
