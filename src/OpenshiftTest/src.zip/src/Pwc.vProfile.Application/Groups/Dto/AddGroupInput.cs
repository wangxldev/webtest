﻿using Abp.AutoMapper;
using Pwc.vProfile.Core.Groups;
using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Groups.Dto
{
    [AutoMapTo(typeof(Group))]
    public class AddGroupInput
    {
        public string Name { get; set; }

        public int Level { get; set; }

        /// <summary>
        /// 完整父路径
        /// /a/b/c/
        /// </summary>
        public string Path { get; set; }

        public string ParentId { get; set; }

        public string Remark { get; set; }

        public List<string> RoleIds { get; set; }

        public DateTime CreationTime { get; set; }

        public long CreatorUserId { get; set; }
    }
}
