﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Groups.Dto
{
    public class UpdateGroupListInput
    {
        public List<GroupDto> grouplist { get; set; }
    }
}
