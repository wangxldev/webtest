﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Groups.Dto
{
    public class MoveGroupInput
    {
        public string movingGroupName { get; set; }
        public string targetGroupName { get; set; }
    }
}
