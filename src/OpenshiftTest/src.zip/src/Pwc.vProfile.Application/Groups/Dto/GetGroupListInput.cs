﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Groups.Dto
{
    public class GetGroupListInput
    {
        public string Name { get; set; }
    }
}
