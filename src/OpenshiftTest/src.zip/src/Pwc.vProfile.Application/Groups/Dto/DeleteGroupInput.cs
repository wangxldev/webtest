﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Groups.Dto
{
    public class DeleteGroupInput
    {
        public string Name { get; set; }
    }
}
