﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Groups.Dto
{
    public class GetUserCountByGroupNameInput
    {
        public long groupSeqId { get; set; }
    }
}
