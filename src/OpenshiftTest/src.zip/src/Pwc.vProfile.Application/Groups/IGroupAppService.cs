﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using Pwc.vProfile.Application.Groups.Dto;
using Pwc.vProfile.Core.Groups;

namespace Pwc.vProfile.Application.Groups
{
    public interface IGroupAppService
    {
        //Task<PagedResultDto<GroupDto>> GetGroups(GetGroupsInput input);

        Task AddGroup(AddGroupInput input);
        Task<PagedResultDto<GroupDto>> GetGroupListAll();
        Task<PagedResultDto<GroupDto>> GetGroupList(GetGroupListInput input);
        Task<GroupDto> GetGroup(GetGroupInput input);
        Task UpdateGroup(UpdateGroupInput input);
        Task UpdateGroupList(UpdateGroupListInput input);

        Task DeleteGroup(DeleteGroupInput input);

        Task DeleteGroupList(DeleteGroupListInput input);
        Task DeleteGroupAll();

        Task MoveGroup(MoveGroupInput input);

        Task<int> GetUserCountByGroupName(GetUserCountByGroupNameInput input);
    }
}
