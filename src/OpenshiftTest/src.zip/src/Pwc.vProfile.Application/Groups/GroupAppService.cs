﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using Pwc.vProfile.Application.Groups.Dto;
using Pwc.vProfile.Core.Groups;

namespace Pwc.vProfile.Application.Groups
{
    /// <summary>
    /// Group Service
    /// </summary>
    public class GroupAppService: IGroupAppService, ITransientDependency
    {
        private readonly IGroupManager _groupManager;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="groupManager"></param>
        public GroupAppService(IGroupManager groupManager)
        {
            _groupManager = groupManager;
        }

        //public Task<PagedResultDto<GroupDto>> GetGroups(GetGroupsInput input)
        //{
        //    throw new NotImplementedException();
        //}
        /// <summary>
        /// New save a group
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task AddGroup(AddGroupInput input)
        {
            var group = AutoMapper.Mapper.Map<Group>(input);
            await _groupManager.Add(group);
        }
        /// <summary>
        /// Query all groups
        /// </summary>
        /// <returns></returns>
        public async Task<PagedResultDto<GroupDto>> GetGroupListAll()
        {
            var groupListAll = await  _groupManager.GetListAll() ;
 
            var totalCount = groupListAll.Count;

            return new PagedResultDto<GroupDto>()
            {
                TotalCount = (Int32)totalCount,
                Items = AutoMapper.Mapper.Map<List<GroupDto>>(groupListAll)
            };
 
        }
        /// <summary>
        /// Query groups by the name match, like
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PagedResultDto<GroupDto>> GetGroupList(GetGroupListInput input)
        {
            var groupList = await _groupManager.GetList(input.Name);

            var totalCount = groupList.Count;

            return new PagedResultDto<GroupDto>()
            {
                TotalCount = (Int32)totalCount,
                Items = AutoMapper.Mapper.Map<List<GroupDto>>(groupList)
            };
        }
        /// <summary>
        /// Query group details by group name
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<GroupDto> GetGroup(GetGroupInput input)
        {
            var group  = await _groupManager.Get(input.Name);
            return AutoMapper.Mapper.Map<GroupDto>(group);
        }
        /// <summary>
        /// Update group
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task UpdateGroup(UpdateGroupInput input)
        {
            var group = AutoMapper.Mapper.Map<Group>(input);
            await _groupManager.Update(group);
        }
        /// <summary>
        /// Update Group list
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task UpdateGroupList(UpdateGroupListInput input)
        {
            var grouplist = AutoMapper.Mapper.Map<List<Group>>(input);
            await _groupManager.UpdateList(grouplist);
        }
        /// <summary>
        /// Delete group
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task DeleteGroup(DeleteGroupInput input)
        {
            await _groupManager.Delete(input.Name);
        }
        /// <summary>
        /// Delete group list
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task DeleteGroupList(DeleteGroupListInput input)
        {
            var grouplist = AutoMapper.Mapper.Map<List<Group>>(input);
            await _groupManager.DeleteList(grouplist);
        }
        /// <summary>
        /// Delete all group info
        /// </summary>
        /// <returns></returns>
        public async Task DeleteGroupAll()
        {
            await _groupManager.DeleteAll();
        }
        /// <summary>
        /// Move a group from Original node to target node
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task   MoveGroup(MoveGroupInput input)
        {
            await _groupManager.MoveGroup(input.movingGroupName,input.targetGroupName);
        }

        /// <summary>
        /// Get user total count of one group by group seqid
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<int> GetUserCountByGroupName(GetUserCountByGroupNameInput input)
        {
            return await _groupManager.GetUserCountByGroupName(input.groupSeqId);
        }
    }
}
