﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Dependency;
using Pwc.vProfile.Application.SSO.Dto;

namespace Pwc.vProfile.Application.SSO
{
    public interface ISSOAppService:ITransientDependency
    {
        /// <summary>
        /// 验证sid是否有效
        /// </summary>
        /// <param name="sid"></param>
        /// <param name="tid"></param>
        /// <param name="uId"></param>
        /// <returns></returns>
        Task<bool> Verify(string sid, long tid, long uId);

        /// <summary>
        /// 获取用户基本信息
        /// </summary>
        /// <param name="sid"></param>
        /// <param name="tid"></param>
        /// <param name="uId"></param>
        /// <returns></returns>
        Task<UserInfoDto> GetUser(string sid, long tid, long uId);

        /// <summary>
        /// 用户登录成功后将用户信息写入缓存
        /// </summary>
        /// <param name="input"></param>
        Task SignInAsync(SignInInput input);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sid"></param>
        /// <param name="tid"></param>
        /// <param name="uId"></param>
        /// <returns></returns>
        Task SignOutAsync(string sid, long tid, long uId);

        /// <summary>
        /// 创建st
        /// </summary>
        /// <returns></returns>
        Task<string> CreateServiceTicket();

    }
}
