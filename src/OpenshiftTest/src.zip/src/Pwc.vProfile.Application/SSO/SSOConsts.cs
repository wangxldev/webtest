﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.SSO
{
    public class SSOConsts
    {
        /// <summary>
        /// sid redis缓存
        /// </summary>
        public static string CacheName = "sid-redis";

        /// <summary>
        /// 缓存的sid模板    {0}:tenantId {1}:sid
        /// </summary>
        public const string SidKey = "{0}-{1}";

        /// <summary>
        /// sid缓存相对过期时间
        /// </summary>
        public static TimeSpan SidCacheExpire = TimeSpan.FromDays(14);

        public const string ServiceTicketPrefix = "st";

        /// <summary>
        /// service ticket prefix
        /// </summary>
        public const string ServiceTicketKey = ServiceTicketPrefix+"_{0}";

    }
}
