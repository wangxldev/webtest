﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.SSO.Dto
{
    public class SignInInput
    {
        public UserInfoDto User { get; set; }

        public string SignInToken { get; set; }
    }
}
