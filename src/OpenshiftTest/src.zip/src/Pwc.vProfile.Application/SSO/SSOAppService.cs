﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Extensions;
using Abp.Runtime.Caching;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Application.SSO.Dto;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.Utility.Extensions;

namespace Pwc.vProfile.Application.SSO
{
    public class SSOAppService: ISSOAppService
    {
        private readonly ICacheManager _cacheManager;
        private readonly UserManager _userManager;

        public SSOAppService(ICacheManager cacheManager, UserManager userManager)
        {
            _cacheManager = cacheManager;
            _userManager = userManager;
        }

        public async Task<bool> Verify(string sid, long tid, long uId)
        {
            if (sid.IsNullOrWhiteSpace() || tid <= 0 || uId <= 0)
            {
                return false;
            }

            var sidKey = string.Format(SSOConsts.SidKey, tid.ToString(), sid);

            var user = await _cacheManager.GetCache(SSOConsts.CacheName).GetOrDefaultAsync<string, UserInfoDto>(sidKey);

            if (user == null)
            {
                // 当在缓存中不存在时,去数据库查询用户信息

                var filter = Builders<User>.Filter.And(
                        Builders<User>.Filter.Eq(u=>u.SeqId,uId),
                        Builders<User>.Filter.Eq(u=>u.IsDeleted,false),
                        Builders<User>.Filter.Eq(u=>u.IsActive,true)
                    );

                var project = Builders<User>.Projection.Include(u => u.SeqId).Include(u => u.UserName)
                    .Include(u => u.Email).Include(u => u.SignInToken);

                var userDoc = await _userManager.Collection.Find(filter).Project(project).FirstOrDefaultAsync();

                var dbUser = userDoc.BsonTo<User>();

                if (dbUser == null || !dbUser.SignInToken.Equals(sid, StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
                else
                {
                    // 将数据放入到redis中
//                    _cacheManager.g
                }
            }

            return true;
        }

        public async Task<UserInfoDto> GetUser(string sid, long tid, long uId)
        {
            if (sid.IsNullOrWhiteSpace() || tid <= 0 || uId <= 0)
            {
                return null;
            }

            var sidKey = string.Format(SSOConsts.SidKey, tid.ToString(), sid);

            var user = await _cacheManager.GetCache(SSOConsts.CacheName).GetOrDefaultAsync<string, UserInfoDto>(sidKey);

            return user;
        }

        public async Task SignInAsync(SignInInput input)
        {
//            var sid = input.SignInToken;
//
//            var sidKey = string.Format(SSOConsts.SidKey, input.User.TenantId.ToString(), sid);
//
//            await _cacheManager.GetCache(SSOConsts.CacheName).SetAsync(sidKey,input.User,slidingExpireTime:SSOConsts.SidCacheExpire);
        }

        public async Task SignOutAsync(string sid, long tid, long uId)
        {
            if (sid.IsNullOrWhiteSpace() || tid <= 0 || uId <= 0) return;

            var sidKey = string.Format(SSOConsts.SidKey, tid.ToString(), sid);

            await _cacheManager.GetCache(SSOConsts.CacheName).RemoveAsync(sidKey);
        }

        public async Task<string> CreateServiceTicket()
        {
            // 创建st,临时先采用guid的方式
            var st = string.Format(SSOConsts.ServiceTicketKey, "st-"+Guid.NewGuid().ToString("N").ToLower());

            // 写入cookie
            await SetAsync(st,null,absoluteExpireTime:TimeSpan.FromSeconds(10));

            return st;
        }
        
        private async Task SetAsync(string key,
            object value,
            TimeSpan? slidingExpireTime = null,
            TimeSpan? absoluteExpireTime = null)
        {
            await _cacheManager.GetCache(SSOConsts.CacheName).SetAsync(key,value, slidingExpireTime, absoluteExpireTime);
        }
    }
}
