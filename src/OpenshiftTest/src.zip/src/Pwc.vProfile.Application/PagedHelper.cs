﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application
{
    public static class PagedHelper
    {
        public const Int32 DefaultPageIndex = 1;   // 默认第一页 从1开始

        public const Int32 DefaultPageSize = 10;

        public const Int32 MaxPageSize = 1000;

        /// <summary>
        /// 验证分页
        /// </summary>
        /// <param name="index"></param>
        /// <param name="limit"></param>
        /// <returns>Item1:skipCount Item2:limit</returns>
        public static Tuple<int, int> PagedCheck(int index, int limit)
        {
            if (index <= 0) index = DefaultPageIndex;

            if (limit <= 0) limit = DefaultPageSize;

            var skipCount = (index-1) * limit;

            return new Tuple<int, int>(skipCount, limit);
        }
    }
}
