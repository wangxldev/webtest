﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.Dependency;

namespace Pwc.vProfile.Application.Profiles
{
    public interface IProfileAppService:ITransientDependency
    {
    }
}
