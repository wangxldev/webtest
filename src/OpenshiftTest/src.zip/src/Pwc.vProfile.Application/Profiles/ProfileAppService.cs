﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Profiles
{
    public class ProfileAppService: IProfileAppService
    {
    }
}
