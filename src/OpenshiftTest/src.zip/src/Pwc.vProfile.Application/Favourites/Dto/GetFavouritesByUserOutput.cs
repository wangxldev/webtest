﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using Abp.Domain.Entities;
using MongoDB.Bson;
using Pwc.vProfile.Core.Favourites;

namespace Pwc.vProfile.Application.Favourites.Dto
{
    [AutoMapFrom(typeof(Favourite))]
    public class GetFavouritesByUserOutput:EntityDto<ObjectId>
    {

    }
}
