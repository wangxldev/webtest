﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using AutoMapper;
using Pwc.vProfile.Application.Favourites.Dto;
using Pwc.vProfile.Core.Favourites;

namespace Pwc.vProfile.Application.Favourites
{
    public class FavouriteAppService: IFavouriteAppService,ITransientDependency
    {
        private readonly IFavouriteManager _favouriteManager;

        public FavouriteAppService(IFavouriteManager favouriteManager)
        {
            _favouriteManager = favouriteManager;
        }

        public async Task<PagedResultDto<GetFavouritesByUserOutput>> GetFavouritesByUser(EntityDto<long> id)
        {
            //  await          _favouriteManager.GetAll();

            //_favouriteManager.Facot.where

//            return Mapper.Map<GetFavouritesByUserOutput>(result);

             return new PagedResultDto<GetFavouritesByUserOutput>();
        }
    }
}
