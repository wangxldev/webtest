﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using Pwc.vProfile.Application.Favourites.Dto;

namespace Pwc.vProfile.Application.Favourites
{
    public interface IFavouriteAppService
    {
        Task<PagedResultDto<GetFavouritesByUserOutput>> GetFavouritesByUser(EntityDto<long> id);
    }
}
