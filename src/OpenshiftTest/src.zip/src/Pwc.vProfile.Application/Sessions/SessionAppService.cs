﻿using System;
using System.Text;
using System.Threading.Tasks;
using Abp.Runtime.Session;
using Abp.Threading;
using AutoMapper;
using Pwc.vProfile.Application.Sessions.Dto;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Application.Sessions
{
    public class SessionAppService: ISessionAppService
    {
        private readonly IAbpSession _abpSession;
        private readonly UserManager _userManager;

        public SessionAppService(IAbpSession abpSession, UserManager userManager)
        {
            _abpSession = abpSession;
            _userManager = userManager;
        }

        public async Task<UserLoginInfoDto> GetCurrentLoginInformations()
        {
            UserLoginInfoDto output=null;

            if (_abpSession.UserId.HasValue)
            {
                output = Mapper.Map<UserLoginInfoDto>(await GetCurrentUserAsync());
            }

            return output;
        }

        public async Task<UpdateUserSignInTokenOutput> UpdateUserSignInToken()
        {
            if (_abpSession.UserId <= 0)
            {
                throw new Exception("ThereIsNoLoggedInUser");
            }

            var user = await _userManager.GetUserAsync(_abpSession.ToUserIdentifier());
            user.SetSignInToken();
            return new UpdateUserSignInTokenOutput
            {
                SignInToken = user.SignInToken,
                EncodedUserId = Convert.ToBase64String(Encoding.UTF8.GetBytes(user.Id.ToString()))
            };
        }

        protected virtual async Task<User> GetCurrentUserAsync()
        {
            var user = await _userManager.FindByIdAsync(_abpSession.GetUserId().ToString());
            if (user == null)
            {
                throw new Exception("There is no current user!");
            }

            return user;
        }

        protected virtual User GetCurrentUser()
        {
            return AsyncHelper.RunSync(GetCurrentUserAsync);
        }
    }
}
