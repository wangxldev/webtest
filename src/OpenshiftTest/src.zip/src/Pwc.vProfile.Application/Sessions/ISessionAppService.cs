﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Dependency;
using Pwc.vProfile.Application.Sessions.Dto;

namespace Pwc.vProfile.Application.Sessions
{
    public interface ISessionAppService : ITransientDependency
    {
        Task<UserLoginInfoDto> GetCurrentLoginInformations();

        Task<UpdateUserSignInTokenOutput> UpdateUserSignInToken();
    }
}
