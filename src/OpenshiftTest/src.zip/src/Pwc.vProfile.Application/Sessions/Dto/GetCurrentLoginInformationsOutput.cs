﻿namespace Pwc.vProfile.Application.Sessions.Dto
{
    public class GetCurrentLoginInformationsOutput
    {
        public UserLoginInfoDto User { get; set; }

        public ApplicationInfoDto Application { get; set; }
    }
}