﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Application.Sessions.Dto
{
    [AutoMapFrom(typeof(User))]
    public class UserLoginInfoDto : EntityDto<long>
    {
        public string Name { get; set; }

        public string UserName { get; set; }

        public string Email { get; set; }
    }
}
