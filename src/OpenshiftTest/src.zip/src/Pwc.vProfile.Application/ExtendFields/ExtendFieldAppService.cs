﻿using Abp.Application.Services.Dto;
using Abp.Dependency;
using Pwc.vProfile.Application.ExtendFields.Dto;
using Pwc.vProfile.Core.ExtendFields;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Pwc.vProfile.Application.ExtendFields
{
    /// <summary>
    /// ExtendField Service
    /// </summary>
    public class ExtendFieldAppService: IExtendFieldAppService, ITransientDependency
    {
        private readonly IExtendFieldManager _extendFieldManager;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="extendFieldManager"></param>
        public ExtendFieldAppService(IExtendFieldManager extendFieldManager)
        {
            _extendFieldManager = extendFieldManager;
        }
        /// <summary>
        /// Get ExtendField BussType List
        /// </summary>
        /// <returns></returns>
        public async  Task<PagedResultDto<string>> GetExtendFieldBussTypeList()
        {
            var efList = await  _extendFieldManager.GetBussTypeList( ); 
            var totalCount = efList.Count;

            return new PagedResultDto<string>()
            {
                TotalCount = (Int32)totalCount,
                Items = AutoMapper.Mapper.Map<List<string>>(efList)
            };

        }
        /// <summary>
        /// Add ExtendField
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task AddExtendField(AddExtendFieldInput input)
        {
            var extendField = AutoMapper.Mapper.Map<ExtendField>(input);
            await _extendFieldManager.Add(extendField);
        }
        /// <summary>
        /// Get ExtendField List All
        /// </summary>
        /// <returns></returns>
        public async Task<PagedResultDto<ExtendFieldDto>> GetExtendFieldListAll()
        {
            var efList = await _extendFieldManager.GetListAll();
            var totalCount = efList.Count;

            return new PagedResultDto<ExtendFieldDto>()
            {
                TotalCount = (Int32)totalCount,
                Items = AutoMapper.Mapper.Map<List<ExtendFieldDto>>(efList)
            };
        }
        /// <summary>
        /// Get ExtendField List by name(match contain) and busstype
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PagedResultDto<ExtendFieldDto>> GetExtendFieldList(GetExtendFieldListInput input)
        {
            var efList = await _extendFieldManager.GetList(input.name, input.bussType);
            var totalCount = efList.Count;

            return new PagedResultDto<ExtendFieldDto>()
            {
                TotalCount = (Int32)totalCount,
                Items = AutoMapper.Mapper.Map<List<ExtendFieldDto>>(efList)
            };
        }
        /// <summary>
        /// Get ExtendField List of one BussType
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<PagedResultDto<ExtendFieldDto>> GetExtendFieldListByBussType(GetExtendFieldListByBussTypeInput input)
        {
            var efList = await _extendFieldManager.GetListByBussType(input.bussType);
            var totalCount = efList.Count;

            return new PagedResultDto<ExtendFieldDto>()
            {
                TotalCount = (Int32)totalCount,
                Items = AutoMapper.Mapper.Map<List<ExtendFieldDto>>(efList)
            };
        }
        /// <summary>
        /// Update ExtendField
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task UpdateExtendField(UpdateExtendFieldInput input)
        {

            var extendField = AutoMapper.Mapper.Map<ExtendField>(input);
            await _extendFieldManager.Update(extendField);
        }
        /// <summary>
        /// Update ExtendField List
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task UpdateExtendFieldList(List<UpdateExtendFieldInput> input)
        {
            var extendFieldList = AutoMapper.Mapper.Map<List<ExtendField>>(input);
            await _extendFieldManager.UpdateList(extendFieldList);
        }
        /// <summary>
        /// Delete ExtendField by name and bussType
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task DeleteExtendField(DeleteExtendFieldInput input)
        {
            await _extendFieldManager.Delete(input.name,input.bussType);
        }
        /// <summary>
        /// Delete ExtendField All
        /// </summary>
        /// <returns></returns>
        public async Task DeleteExtendFieldAll()
        {
            await _extendFieldManager.DeleteAll();
        }
    }
}
