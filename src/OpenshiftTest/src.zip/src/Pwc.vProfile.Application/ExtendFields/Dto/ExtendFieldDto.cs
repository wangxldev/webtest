﻿using Abp.AutoMapper;
using Abp.Domain.Entities;
using MongoDB.Bson;
using Pwc.vProfile.Core.ExtendFields;
using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.ExtendFields.Dto
{
    [AutoMapFrom(typeof(ExtendField))]
    public class ExtendFieldDto : Entity<ObjectId>
    {
        public string Label { get; set; }

        public string Name { get; set; }

        public bool IsRequired { get; set; }

        /// <summary>
        /// 业务类型判断
        /// <see cref="BussTypeEnum"/>
        /// </summary>
        public string BussType { get; set; }

        public int Order { get; set; }

        public string Type { get; set; }

        public string Scope { get; set; }

        public string DefaultValue { get; set; }
    }
}
