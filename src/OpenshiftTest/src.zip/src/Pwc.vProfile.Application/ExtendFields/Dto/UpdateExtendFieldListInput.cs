﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.ExtendFields.Dto
{
    public class UpdateExtendFieldListInput
    {
        public List<UpdateExtendFieldInput> efList { get; set; }
    }
}
