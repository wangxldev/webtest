﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.ExtendFields.Dto
{
    public class GetExtendFieldListByBussTypeInput
    {
        public string bussType { get; set; }
    }
}
