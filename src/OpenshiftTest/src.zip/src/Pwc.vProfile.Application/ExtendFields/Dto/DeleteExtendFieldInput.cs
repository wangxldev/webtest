﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.ExtendFields.Dto
{
    public class DeleteExtendFieldInput
    {
        public string name { get; set; }
        public string bussType { get; set; }
    }
}
