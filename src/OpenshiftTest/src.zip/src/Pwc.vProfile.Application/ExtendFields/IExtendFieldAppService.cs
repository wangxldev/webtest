﻿using Abp.Application.Services.Dto;
using Pwc.vProfile.Application.ExtendFields.Dto;
using Pwc.vProfile.Core.ExtendFields;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Pwc.vProfile.Application.ExtendFields
{
    public interface IExtendFieldAppService
    {
        Task<PagedResultDto<string>> GetExtendFieldBussTypeList();
        Task AddExtendField(AddExtendFieldInput input);
        Task<PagedResultDto<ExtendFieldDto>> GetExtendFieldListAll();
        Task<PagedResultDto<ExtendFieldDto>> GetExtendFieldList(GetExtendFieldListInput input);
        Task<PagedResultDto<ExtendFieldDto>> GetExtendFieldListByBussType(GetExtendFieldListByBussTypeInput input);
        Task UpdateExtendField(UpdateExtendFieldInput input);

        Task UpdateExtendFieldList(List<UpdateExtendFieldInput> input);

        Task DeleteExtendField(DeleteExtendFieldInput input);

        Task DeleteExtendFieldAll();
    }
}
