﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using Pwc.vProfile.Application.Auth.Roles.Dto;

namespace Pwc.vProfile.Application.Auth.Roles
{
    public interface IRoleAppService:ITransientDependency
    {
        Task CreateOrUpdate(CreateOrUpdateInput input);

        Task Delete(string name);

        Task<PagedResultDto<RoleListDto>> GetRoles(GetRolesInput input);

        Task<GetRoleForEditOutput> GetRoleForEdit(string name);

        Task<List<string>> GetRolePremissions(string name);
    }
}
