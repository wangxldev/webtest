﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Authorization;
using Abp.Extensions;
using AutoMapper;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Application.Auth.Permissions;
using Pwc.vProfile.Application.Auth.Roles.Dto;
using Pwc.vProfile.Core.Auth.Roles;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Application.Auth.Roles
{
    public class RoleAppService: IRoleAppService
    {
        private readonly UserManager _userManager;
        private readonly RoleManager _roleManager;
        private readonly IPermissionManager _permissionManager;

        public RoleAppService(UserManager userManager, RoleManager roleManager, IPermissionManager permissionManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _permissionManager = permissionManager;
        }

        public async Task CreateOrUpdate(CreateOrUpdateInput input)
        {
            var role = Mapper.Map<Role>(input.Role);

            var grantedPermissions = _permissionManager.GetPermissionsFromNamesByValidating(input.GrantedPermissionNames);
            role.Permissions = grantedPermissions.Select(p => p.Name).ToList();

            await _roleManager.CreateOrUpdateAsync(role);
        }

        public async Task Delete(string name)
        {
            await _roleManager.DeleteAsync(name);
        }

        public async Task<PagedResultDto<RoleListDto>> GetRoles(GetRolesInput input)
        {
            var filterList=new List<FilterDefinition<Role>>()
            {
                Builders<Role>.Filter.Empty
            };

            if (!input.Keyword.IsNullOrWhiteSpace())
            {
                var likeCond = Builders<Role>.Filter.Or(Builders<Role>.Filter.Regex(u => u.Name, new BsonRegularExpression(input.Keyword, "i")));
                filterList.Add(likeCond);
            }

            var filter = (Builders<Role>.Filter.And(filterList));

            var query = _roleManager.Collection.Find(filter);

            // 计算行数
//            var totalCount = await query.CountDocumentsAsync();
            // 获取列表
            var list = await query.ToListAsync();

            return new PagedResultDto<RoleListDto>()
            {
                TotalCount = (Int32)0,
                Items = Mapper.Map<List<RoleListDto>>(list)
            };
        }

        public async Task<GetRoleForEditOutput> GetRoleForEdit(string roleName)
        {
            var role = await _roleManager.GetRoleByNameAsync(roleName);
            RoleEditDto roleEditDto;
            if (role == null)
            {
                roleEditDto=new RoleEditDto();
            }
            else
            {
                roleEditDto = Mapper.Map<RoleEditDto>(role);
            }

            return new GetRoleForEditOutput()
            {
                Role = roleEditDto,
//                Permissions = ,
                GrantedPermissionNames =role==null?new List<string>() : role.Permissions
            };
        }

        public async Task<List<string>> GetRolePremissions(string name)
        {
            var rolePermissions = await _roleManager.GetPermissionsAsync(name);

            return rolePermissions.Select(rp => rp.Name).ToList();
        }
    }
}
