﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Pwc.vProfile.Utility.Swagger;

namespace Pwc.vProfile.Application.Auth.Roles.Dto
{
    [SwaggerSchema(id: "CreateOrUpdateRoleInput")]
    public class CreateOrUpdateInput
    {
        [Required]
        public RoleEditDto Role { get; set; }

        public List<String> GrantedPermissionNames { get; set; }
    }
}
