﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Auth.Roles.Dto
{
    public class GetRolesInput
    {
        public String Keyword { get; set; }
    }
}
