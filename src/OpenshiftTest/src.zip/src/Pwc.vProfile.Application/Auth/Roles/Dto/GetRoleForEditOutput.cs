﻿using System;
using System.Collections.Generic;
using System.Text;
using Pwc.vProfile.Application.Auth.Permissions.Dto;

namespace Pwc.vProfile.Application.Auth.Roles.Dto
{
    public class GetRoleForEditOutput
    {
        public RoleEditDto Role { get; set; }

        /// <summary>
        /// 所有权限列表
        /// </summary>
        public List<FlatPermissionDto> Permissions { get; set; }

        /// <summary>
        /// 分配到该角色的权限Name列表
        /// </summary>
        public List<String> GrantedPermissionNames { get; set; }
    }
}
