﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.AutoMapper;
using Pwc.vProfile.Core.Auth.Roles;

namespace Pwc.vProfile.Application.Auth.Roles.Dto
{
    [AutoMapFrom(typeof(Role))]
    public class RoleListDto
    {
        public String Name { get; set; }

        public String DisplayName { get; set; }

        public bool IsStatic { get; set; }

        public bool IsDefault { get; set; }

        public DateTime CreationTime { get; set; }

        public String Desc { get; set; }
    }
}
