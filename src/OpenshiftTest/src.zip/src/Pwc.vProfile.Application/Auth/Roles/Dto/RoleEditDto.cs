﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using Abp.AutoMapper;
using Pwc.vProfile.Core.Auth.Roles;

namespace Pwc.vProfile.Application.Auth.Roles.Dto
{
    [AutoMapTo(typeof(Role))]
    public class RoleEditDto
    {
        public string Name { get; set; }

//        [Required(ErrorMessage = "角色名称不能为空")]
        public String DisplayName { get; set; }

        public bool IsDefault { get; set; } = false;

        public String Desc { get; set; }
    }
}
