﻿using System;
using Abp.Dependency;
using Abp.UI;
using Microsoft.Extensions.Logging;
using Pwc.vProfile.Core.Auth;

namespace Pwc.vProfile.Application.Auth
{
    public class LoginResultTypeHelper : ITransientDependency
    {
        public UserFriendlyException CreateExceptionForFailedLoginAttempt(LogInResultTypeEnum result, string usernameOrEmailAddress)
        {
            switch (result)
            {
                case LogInResultTypeEnum.Success:
                    return new UserFriendlyException("Don't call this method with a success result!");
                case LogInResultTypeEnum.InvalidUserNameOrEmailAddress:
                case LogInResultTypeEnum.InvalidPassword:
                    return new UserFriendlyException("LoginFailed", "InvalidUserNameOrPassword");
                case LogInResultTypeEnum.InvalidTenancyName:
                    return new UserFriendlyException("LoginFailed", "ThereIsNoTenantDefinedWithName");
                case LogInResultTypeEnum.TenantIsNotActive:
                    return new UserFriendlyException("LoginFailed", "TenantIsNotActive");
                case LogInResultTypeEnum.UserIsNotActive:
                    return new UserFriendlyException("LoginFailed", "UserIsNotActiveAndCanNotLogin");
                case LogInResultTypeEnum.UserEmailIsNotConfirmed:
                    return new UserFriendlyException("LoginFailed", "UserEmailIsNotConfirmedAndCanNotLogin");
                case LogInResultTypeEnum.LockedOut:
                    return new UserFriendlyException("LoginFailed", "UserLockedOutMessage");
                default: //Can not fall to default actually. But other result types can be added in the future and we may forget to handle it
                    // TODO log
                    return new UserFriendlyException("LoginFailed");
            }
        }

        public string CreateLocalizedMessageForFailedLoginAttempt(LogInResultTypeEnum result, string usernameOrEmailAddress)
        {
            switch (result)
            {
                case LogInResultTypeEnum.Success:
                    throw new Exception("Don't call this method with a success result!");
                case LogInResultTypeEnum.InvalidUserNameOrEmailAddress:
                case LogInResultTypeEnum.InvalidPassword:
                    return "InvalidUserNameOrPassword";
                case LogInResultTypeEnum.InvalidTenancyName:
                    return "ThereIsNoTenantDefinedWithName";
                case LogInResultTypeEnum.TenantIsNotActive:
                    return "TenantIsNotActive";
                case LogInResultTypeEnum.UserIsNotActive:
                    return "UserIsNotActiveAndCanNotLogin";
                case LogInResultTypeEnum.UserEmailIsNotConfirmed:
                    return "UserEmailIsNotConfirmedAndCanNotLogin";
                case LogInResultTypeEnum.LockedOut:
                    return "UserLockedOutMessage";
                default: //Can not fall to default actually. But other result types can be added in the future and we may forget to handle it
                    // TODO log
                    return "LoginFailed";
            }
        }
    }
}
