﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using Pwc.vProfile.Application.Auth.Users.Dto;

namespace Pwc.vProfile.Application.Auth.Users
{
    public interface IUserAppService:ITransientDependency
    {
        Task CreateOrUpdate(CreateOrUpdateInput input);

        Task Delete(EntityDto<long> input);

        Task<PagedResultDto<GetUsersOutput>> GetUsers(GetUsersInput input);

        Task<GetUserForEditOutput> GetUserForEdit(NullableIdDto<long> input);

        Task<GetDetailOutput> GetDetail(NullableIdDto<long> input);

        Task SetLockout(SetLockoutInput input);

        Task SetActivate(SetActivateInput input);

        /// <summary>
        /// 获取用户的角色列表
        /// </summary>
        /// <returns></returns>
        Task<List<string>> GetUserRoles(EntityDto<long> input);


        /// <summary>
        /// 更新用户的角色信息
        /// </summary>
        /// <returns></returns>
        Task UpdateUserRoles(UpdateUserRolesInput input);

        /// <summary>
        /// 获取用户所属的组
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<List<GetUserGroupsOutput>> GetUserGroups(EntityDto<long> input);

        /// <summary>
        /// 更新用户组
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task UpdateUserGroups(UpdateUserGroupsInput input);
    }
}
