﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using Abp.Auditing;
using Abp.AutoMapper;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    [AutoMapTo(typeof(User))]
    public class UserEditDto
    {
        public long? Id { get; set; }

        [Required(ErrorMessage = "用户名不能为空")]
        [StringLength(User.MaxUserNameLength)]
        public string UserName { get; set; }

        [StringLength(User.MaxUserNameLength)]
        public String Name { get; set; }

        [Required(ErrorMessage = "邮箱不能为空")]
        [EmailAddress]
        public string Email { get; set; }

        public string Phone { get; set; }

        [StringLength(User.MaxPlainPasswordLength)]
        public string Password { get; set; }

        public bool IsActive { get; set; }

        public bool ShouldChangePasswordOnNextLogin { get; set; }

        public virtual bool IsTwoFactorEnabled { get; set; }

        public virtual bool IsLockoutEnabled { get; set; }
    }
}
