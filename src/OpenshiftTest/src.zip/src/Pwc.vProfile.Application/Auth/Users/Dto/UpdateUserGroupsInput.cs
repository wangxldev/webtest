﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    public class UpdateUserGroupsInput
    {
        public long Id { get; set; }

        public List<int> GroupIds { get; set; }
    }
}
