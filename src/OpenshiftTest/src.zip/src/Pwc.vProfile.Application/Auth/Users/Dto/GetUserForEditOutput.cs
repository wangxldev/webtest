﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.AutoMapper;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    [AutoMapFrom(typeof(User))]
    public class GetUserForEditOutput
    {
        public long? Id { get; set; }

        public string UserName { get; set; }

        public String Name { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public bool IsActive { get; set; }

        public bool ShouldChangePasswordOnNextLogin { get; set; }

        public virtual bool IsTwoFactorEnabled { get; set; }

        public virtual bool IsLockoutEnabled { get; set; }
    }
}
