﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    public class SetActivateInput
    {
        public long Id { get; set; }

        public bool IsActive{ get; set; }
    }
}
