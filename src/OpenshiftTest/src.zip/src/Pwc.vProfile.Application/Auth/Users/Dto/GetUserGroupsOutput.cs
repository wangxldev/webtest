﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.AutoMapper;
using Pwc.vProfile.Core.Auth.Users;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    [AutoMapFrom(typeof(UserGroupsRel))]
    public class GetUserGroupsOutput
    {
        public int SeqId { get; set; }

        public string Name { get; set; }
    }
}
