﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    public class UpdateUserRolesInput
    {
        public long Id { get; set; }

        /// <summary>
        /// 已分配的角色列表
        /// </summary>
        public List<string> RoleNames { get; set; }
    }
}
