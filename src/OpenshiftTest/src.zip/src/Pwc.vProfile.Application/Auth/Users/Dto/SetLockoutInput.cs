﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    public class SetLockoutInput
    {
        public long Id { get; set; }

        public bool IsLockout { get; set; }
    }
}
