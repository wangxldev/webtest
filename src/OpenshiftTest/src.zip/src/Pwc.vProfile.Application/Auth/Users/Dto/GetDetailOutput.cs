﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.AutoMapper;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.Core.ExtendFields;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    [AutoMapFrom(typeof(User))]
    public class GetDetailOutput
    {
        [JsonProperty("id")]
        public long SeqId { get; set; }

        public string StuffCode { get; set; }

        public string InternationalCode { get; set; }

        public string UserName { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public bool IsEmailConfirmed { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string EmailConfirmationCode { get; set; }

        public bool IsLockoutEnabled { get; set; }

        public DateTime? LockoutEndDateUtc { get; set; }

        public string Phone { get; set; }

        public bool IsPhoneConfirmed { get; set; }

        public bool IsTwoFactorEnabled { get; set; }

        public bool IsActive { get; set; }

        public DateTime? LastLoginTime { get; set; }

//        public List<string> RoleIds { get; set; }
//
//        public List<string> GroupIds { get; set; }
//
//        public List<string> PermissionIds { get; set; }

        public List<ExtendValue> Extends { get; set; }

        public DateTime CreationTime { get; set; }

        public DateTime? LastModificationTime { get; set; }

    }
}
