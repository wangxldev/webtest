﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    public class GetUsersInput
    {
        public string Keyword { get; set; }

        public int Index { get; set; }

        public int Limit { get; set; }
    }
}
