﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    public class AddUsersToRoleInput
    {
        public List<long> UserId { get; set; }
    }
}
