﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using Pwc.vProfile.Utility.Swagger;

namespace Pwc.vProfile.Application.Auth.Users.Dto
{
    [SwaggerSchema(id: "CreateOrUpdateUserInput")]
    public class CreateOrUpdateInput
    {
        [Required]
        public UserEditDto User { get; set; }

        public bool SendActivationEmail { get; set; }

        public bool SetRandomPassword { get; set; }
    }
}
