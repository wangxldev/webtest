﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Json;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Pwc.vProfile.Application.Auth.Users.Dto;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.Utility.Extensions;

namespace Pwc.vProfile.Application.Auth.Users
{
    public class UserAppService: IUserAppService
    {
        private readonly UserManager _userManager;
        private readonly IPasswordHasher<User> _passwordHasher;

        public UserAppService(UserManager userManager, IPasswordHasher<User> passwordHasher)
        {
            _userManager = userManager;
            _passwordHasher = passwordHasher;
        }

        public async Task CreateOrUpdate(CreateOrUpdateInput input)
        {
            if (input.User.Id.HasValue)
            {
                await UpdateUserAsync(input);
            }
            else
            {
                await CreateUserAsync(input);
            }
        }

        public async Task Delete(EntityDto<long> input)
        {
            await _userManager.SoftDeleteByIdAsync(input.Id);
        }

        public async Task<PagedResultDto<GetUsersOutput>> GetUsers(GetUsersInput input)
        {
            var filterList = new List<FilterDefinition<User>>()
            {
                Builders<User>.Filter.Eq(u=>u.IsDeleted,false)
            };

            var pagedInfo = PagedHelper.PagedCheck(input.Index, input.Limit);

            if (!input.Keyword.IsNullOrWhiteSpace())
            {
                var pattern = $"{input.Keyword}";

                var likeCond = Builders<User>.Filter.Or(
                    Builders<User>.Filter.Regex(u => u.Name, new BsonRegularExpression(pattern, "i")),
                        Builders<User>.Filter.Regex(u => u.Name, new BsonRegularExpression(pattern, "i")),
                        Builders<User>.Filter.Regex(u => u.UserName, new BsonRegularExpression(pattern, "i")),
                        Builders<User>.Filter.Regex(u => u.FirstName, new BsonRegularExpression(pattern, "i")),
                        Builders<User>.Filter.Regex(u => u.LastName, new BsonRegularExpression(pattern, "i")),
                        Builders<User>.Filter.Regex(u => u.Email, new BsonRegularExpression(pattern, "i")),
                        Builders<User>.Filter.Regex(u => u.Phone, new BsonRegularExpression(pattern, "i"))
                    );

                filterList.Add(likeCond);
            }

            var filter = Builders<User>.Filter.And(filterList);

            var query = _userManager.Collection.Find(filter);
            // TODO 可优化,当条件不变并且没有新数据插入时,不需要重新Count
            var totalCount = await query.CountDocumentsAsync();

            var users = await query.Skip(pagedInfo.Item1).Limit(pagedInfo.Item2).ToListAsync();

            return new PagedResultDto<GetUsersOutput>()
            {
                TotalCount = (int)totalCount,
                Items = Mapper.Map<IReadOnlyList<GetUsersOutput>>(users)
            };
        }

        public async Task<GetUserForEditOutput> GetUserForEdit(NullableIdDto<long> input)
        {
            var filter = Builders<User>.Filter.And(
                    Builders<User>.Filter.Eq(u=>u.SeqId,input.Id),
                    Builders<User>.Filter.Eq(u=>u.IsDeleted,false)
                );

            var project = Builders<User>.Projection.Include(u => u.SeqId)
                    .Include(u => u.UserName)
                    .Include(u => u.Name)
                    .Include(u => u.Email)
                    .Include(u => u.Phone)
                    .Include(u => u.IsActive)
                    .Include(u => u.ShouldChangePasswordOnNextLogin)
                    .Include(u => u.IsTwoFactorEnabled)
                    .Include(u => u.IsLockoutEnabled)
                ;

            var doc = await _userManager.Collection.Find(filter).Project(project).FirstOrDefaultAsync();

            return Mapper.Map<GetUserForEditOutput>(doc.BsonTo<User>());
        }

        public async Task<GetDetailOutput> GetDetail(NullableIdDto<long> input)
        {
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, input.Id),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            // 排除字段
            var project = Builders<User>.Projection.Exclude(u => u.Password)
                    .Exclude(u => u.PasswordResetCode)
                    .Exclude(u => u.AccessFailedCount)
                    .Exclude(u => u.SecurityStamp)
                    .Exclude(u => u.ConcurrencyStamp)
                    .Exclude(u => u.SignInToken)
                    .Exclude(u => u.SignInTokenExpireTimeUtc)
                    .Exclude(u => u.Roles)
                    .Exclude(u => u.Groups)
                    .Exclude(u => u.Permissions)
                    .Exclude(u => u.ShouldChangePasswordOnNextLogin)
                ;

            var doc = await _userManager.Collection.Find(filter).Project(project).FirstOrDefaultAsync();

            return Mapper.Map<GetDetailOutput>(doc.BsonTo<User>());
        }

        public async Task SetLockout(SetLockoutInput input)
        {
            await _userManager.SetLockAsync(input.Id,input.IsLockout);
        }

        public async Task SetActivate(SetActivateInput input)
        {
            await _userManager.SetActivateAsync(input.Id,input.IsActive);
        }

        public async Task<List<string>> GetUserRoles(EntityDto<long> input)
        {
            var assignedRoles = await _userManager.UserStore.GetRolesAsync(new User() {SeqId = input.Id});
            return assignedRoles?.ToList()??new List<string>();
        }

        public async Task UpdateUserRoles(UpdateUserRolesInput input)
        {
            await _userManager.UpdateUserRoles(input.Id, input.RoleNames);
        }

        public async Task<List<GetUserGroupsOutput>> GetUserGroups(EntityDto<long> input)
        {
            var filter = Builders<User>.Filter.And(
                Builders<User>.Filter.Eq(u => u.SeqId, input.Id),
                Builders<User>.Filter.Eq(u => u.IsDeleted, false)
            );

            var project = Builders<User>.Projection.Include(u => u.Groups);

            var doc = await _userManager.Collection.Find(filter).Project(project).FirstOrDefaultAsync();

            var user = doc.BsonTo<User>();

            if (user?.Groups == null || user.Groups.Count <= 0)
            {
                return new List<GetUserGroupsOutput>();
            }

            return user.Groups.Select(rel=>new GetUserGroupsOutput()
            {
                SeqId = rel.SeqId,
                Name = rel.Name
            }).ToList();
        }

        public async Task UpdateUserGroups(UpdateUserGroupsInput input)
        {
            await _userManager.UpdateUserGroups(input.Id,input.GroupIds);
        }

        #region private

        protected virtual async Task CreateUserAsync(CreateOrUpdateInput input)
        {
            var user = Mapper.Map<User>(input.User);

            user.Password = _passwordHasher.HashPassword(user, input.User.Password);
            user.ShouldChangePasswordOnNextLogin = input.User.ShouldChangePasswordOnNextLogin;

            await _userManager.CreateAsync(user);

            // TODO 新用户消息通知
        }

        protected virtual async Task UpdateUserAsync(CreateOrUpdateInput input)
        {
            if (input.SetRandomPassword)
            {
                input.User.Password = User.CreateRandomPassword();
            }

            var user = Mapper.Map<User>(input.User);

            await _userManager.UpdateAsync(user);
        }

        #endregion
    }
}
