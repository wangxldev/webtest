﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.Authorization;
using Abp.AutoMapper;

namespace Pwc.vProfile.Application.Auth.Permissions.Dto
{
    [AutoMapFrom(typeof(Permission))]
    public class FlatPermissionDto
    {
        public String ParentName { get; set; }

        public String Name { get; set; }

        public String DisplayName { get; set; }

        public String Description { get; set; }

        public bool IsGrantedByDefault { get; set; }
    }
}
