﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Auth.Permissions.Dto
{
    public class FlatPermissionWithLevelDto: FlatPermissionDto
    {
        public int Level { get; set; }
    }
}
