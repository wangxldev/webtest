﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Abp.Application.Services.Dto;
using Abp.Authorization;
using AutoMapper;
using Pwc.vProfile.Application.Auth.Permissions.Dto;

namespace Pwc.vProfile.Application.Auth.Permissions
{
    public class PermissionAppService: IPermissionAppService
    {
        private readonly IPermissionManager _permissionManager;

        public PermissionAppService(IPermissionManager permissionManager)
        {
            _permissionManager = permissionManager;
        }

        public ListResultDto<FlatPermissionWithLevelDto> GetAllPermissions()
        {
            var permissions = _permissionManager.GetAllPermissions();

            var rootPermissions = permissions.Where(p => p.Parent == null);
            var result = new List<FlatPermissionWithLevelDto>();
            foreach (var rootPermission in rootPermissions)
            {
                var level = 0;
                AddPermission(rootPermission, permissions, result, level);
            }

            return new ListResultDto<FlatPermissionWithLevelDto>(result);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parent">父节点</param>
        /// <param name="allPermissions">所有权限列表</param>
        /// <param name="result">返回结果集</param>
        /// <param name="level">level</param>
        private void AddPermission(Permission parent, IReadOnlyList<Permission> allPermissions,
            List<FlatPermissionWithLevelDto> result, Int32 level)
        {
            var flatPermission = Mapper.Map<FlatPermissionWithLevelDto>(parent);
            flatPermission.Level = level;
            result.Add(flatPermission);

            if (parent.Children == null) return;

            // 获取对应节点的所有子节点
            var children = allPermissions.Where(p => p.Parent != null && p.Parent.Name == parent.Name).ToList();
            foreach (var childPermission in children)
            {
                AddPermission(childPermission, allPermissions, result, level + 1);
            }
        }
    }
}
