﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using Pwc.vProfile.Application.Auth.Permissions.Dto;

namespace Pwc.vProfile.Application.Auth.Permissions
{
    public interface IPermissionAppService:ITransientDependency
    {
        ListResultDto<FlatPermissionWithLevelDto> GetAllPermissions();
    }
}
