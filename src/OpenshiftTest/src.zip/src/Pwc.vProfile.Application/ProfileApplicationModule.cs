﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using Microsoft.Extensions.DependencyInjection;
using Pwc.vProfile.Core;
using Pwc.vProfile.Data;

namespace Pwc.vProfile.Application
{
    [DependsOn(typeof(ProfileCoreModule),typeof(ProfileDataModule))]
    public class ProfileApplicationModule:AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ProfileApplicationModule).GetAssembly());
        }
    }
}
