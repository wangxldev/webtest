﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Dependency;
using Pwc.vProfile.Application.Apps.Dto;

namespace Pwc.vProfile.Application.Apps
{
    public interface IAppAppService:ITransientDependency
    {
        Task<List<GetListOutput>> GetList(GetListInput input);

        Task CreateOrUpdate(CreateOrUpdateInput input);

        Task Delete(string id);
    }
}
