﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.AutoMapper;
using MongoDB.Bson.Serialization.Attributes;
using Pwc.vProfile.Core.Apps;
using Pwc.vProfile.Core.Tenants;

namespace Pwc.vProfile.Application.Apps.Dto
{
    [AutoMapFrom(typeof(App))]
    public class GetListOutput
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public bool IsActive { get; set; }

        public string SubUrl { get; set; }

        /// <summary>
        /// <see cref="AuthTypeEnum"/>
        /// 表示App的认证方式
        /// </summary>
        public string AuthType { get; set; }

        public bool IsTwoFactorEnabled { get; set; }

        public string Desc { get; set; }

        /// <summary>
        /// app被收藏的次数
        /// </summary>
        public int FavCount { get; set; }

        public int LikeCount { get; set; }

        public DateTime CreationTime { get; set; }

        public DateTime? LastModificationTime { get; set; }

    }
}
