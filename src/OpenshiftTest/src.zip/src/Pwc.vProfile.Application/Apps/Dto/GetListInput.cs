﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Application.Apps.Dto
{
    public class GetListInput
    {
        public string Keyword { get; set; }

        public string AuthType { get; set; }
    }
}
