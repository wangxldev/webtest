﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.AutoMapper;
using Pwc.vProfile.Core.Apps;

namespace Pwc.vProfile.Application.Apps.Dto
{
    [AutoMapTo(typeof(App))]
    public class CreateOrUpdateInput
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public bool IsActive { get; set; }

        public string LogoUrl { get; set; }

        public string AuthType { get; set; }

        public bool IsTwoFactorEnabled { get; set; }

        public string Desc { get; set; }

    }
}
