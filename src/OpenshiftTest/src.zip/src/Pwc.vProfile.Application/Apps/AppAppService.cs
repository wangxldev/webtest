﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Abp.Extensions;
using AutoMapper;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Application.Apps.Dto;
using Pwc.vProfile.Core.Apps;

namespace Pwc.vProfile.Application.Apps
{
    public class AppAppService: IAppAppService
    {
        private readonly IAppManager _appManager;

        public AppAppService(IAppManager appManager)
        {
            _appManager = appManager;
        }

        public async Task<List<GetListOutput>> GetList(GetListInput input)
        {
            var filterList = new List<FilterDefinition<App>>();

            if (!input.Keyword.IsNullOrWhiteSpace())
            {
                filterList.Add(Builders<App>.Filter.Regex(a => a.Name, BsonRegularExpression.Create(input.Keyword)));
            }
            if (!input.AuthType.IsNullOrWhiteSpace())
            {
                filterList.Add(Builders<App>.Filter.Eq(a=>a.AuthType,input.AuthType));
            }

            var apps = await _appManager.Collection.Find(Builders<App>.Filter.And(filterList)).ToListAsync();
            return Mapper.Map<List<GetListOutput>>(apps);
        }

        public async Task  CreateOrUpdate(CreateOrUpdateInput input)
        {
            var app = Mapper.Map<App>(input);
            if (input.Id.IsNullOrWhiteSpace())
            {
                await _appManager.Create(app);
            }
            else
            {
                app.Id = ObjectId.Parse(input.Id);
                await _appManager.Update(app);
            }
        }

        public async Task Delete(string id)
        {
            await _appManager.Delete(id);
        }

    }
}
