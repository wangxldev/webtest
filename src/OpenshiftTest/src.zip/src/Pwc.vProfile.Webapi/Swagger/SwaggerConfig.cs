﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Abp.Extensions;
using Castle.Core.Internal;
using Microsoft.Extensions.DependencyInjection;
using Pwc.vProfile.Utility.Swagger;
using Swashbuckle.AspNetCore.Swagger;

namespace Pwc.vProfile.WebApi.Swagger
{
    public static class SwaggerConfig
    {
        public static void Register(IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "vProfile", Version = "v1" });

                // 为 Swagger JSON and UI设置xml文档注释路径
                var basePath = Path.GetDirectoryName(typeof(SwaggerConfig).Assembly.Location);//获取应用程序所在目录（绝对，不受工作目录影响，建议采用此方法获取路径）
                c.IncludeXmlComments(Path.Combine(basePath, "Pwc.vProfile.WebApi.xml"));
                c.IncludeXmlComments(Path.Combine(basePath, "Pwc.vProfile.Application.xml"));
            });

            services.ConfigureSwaggerGen(options =>
            {
                options.CustomSchemaIds(type =>
                {
                    var id = type.GetAttribute<SwaggerSchemaAttribute>()?.Id;

                    if (id.IsNullOrWhiteSpace())
                    {
                        return type.FullName;
                    }

                    return id;
                });
            });
        }
    }
}
