﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.AspNetCore.Mvc.Results.Wrapping;
using Abp.Dependency;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Pwc.vProfile.Application;
using Pwc.vProfile.Utility;

namespace Pwc.vProfile.WebApi.Startup
{

    [DependsOn(
        typeof(ProfileApplicationModule),
        typeof(AbpAspNetCoreModule),
        typeof(ProfileUtilityModule)
    )]
    public class ProfileWebModule:AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(AbpAspNetCoreModule).GetAssembly()
                );

        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ProfileWebModule).GetAssembly());
        }
    }
}
