﻿using System;
using System.Collections.Generic;
using System.IO;
using Abp.AspNetCore;
using Abp.Castle.Logging.Log4Net;
using Abp.Dependency;
using Castle.Facilities.Logging;
using IdentityServer4.Models;
using IdentityServer4.Test;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Pwc.vProfile.Core.Auth;
using Pwc.vProfile.Core.Auth.Ids;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.Core.Sequences;
using Pwc.vProfile.WebApi.Swagger;
using Swashbuckle.AspNetCore.Swagger;

namespace Pwc.vProfile.WebApi.Startup
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            Configuration = configuration;
            Env = env;
        }

        public IConfiguration Configuration { get; }

        public IHostingEnvironment Env { get; }

        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            IdentityRegistrar.Register(services);

            // 使用内存存储的密钥，客户端和API资源来配置ids4。
            services.AddIdentityServer()
                .AddDeveloperSigningCredential()
                .AddIdsPersistedGrants()
                .AddInMemoryApiResources(TestConfig.GetApiResources())
                .AddInMemoryClients(TestConfig.GetClients())
                //                .AddTestUsers(TestConfig.GetUsers())
                .AddIds<User>()
                .AddProfileService<IdsProfileService<User>>()
                ;

            services.AddAuthentication((options) =>
                {
                    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters();
                    options.RequireHttpsMetadata = false;
                    options.Audience = "api1";//api范围
                    options.Authority = "http://localhost:1499";//IdentityServer地址
                });

            services.AddRouting(options =>
            {
                options.LowercaseUrls = true;
            });

            // 注册swagger信息
            // SwaggerConfig.Register(services);

            return services.AddAbp<ProfileWebModule>(options =>
            {
                options.IocManager.IocContainer.AddFacility<LoggingFacility>(
                    f => f.UseAbpLog4Net().WithConfig(Path.Combine(Env.ContentRootPath,"log4net.config"))
                );
            });
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseAbp(options =>
            {
                options.UseAbpRequestLocalization = false;
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseIdentityServer();

//            app.UseAuthentication();

//            app.UseHttpsRedirection();

            // app.UseSwagger();

            // app.UseSwaggerUI(c =>
            // {
            //     c.SwaggerEndpoint("/swagger/v1/swagger.json", "vProfile V1");
            // });

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }

    public class TestConfig
    {
        public static IEnumerable<ApiResource> GetApiResources()
        {
            return new List<ApiResource>
            {
                new ApiResource("api1", "My API")
            };
        }

        public static IEnumerable<Client> GetClients()
        {
            return new List<Client>
            {
                new Client
                {
                    ClientId = "native.code",
                    ClientName = "Native Client (Code with PKCE)",

                    RedirectUris = { "https://notused" },
                    PostLogoutRedirectUris = { "https://notused" },

                    RequireClientSecret = false,

                    AllowedGrantTypes = GrantTypes.Code,
                    RequirePkce = true,
                    AllowedScopes = {  "api1" },

                    AllowOfflineAccess = true,
                    RefreshTokenUsage = TokenUsage.ReUse
                },
                new Client
                {
                    ClientId = "client_code",

                    RedirectUris = { "https://notused" },
                    PostLogoutRedirectUris = { "https://notused" },

//                    AllowedGrantTypes = GrantTypes.Code,
                    AllowedGrantTypes = new List<string> { "authorization_code" },

                    RequireClientSecret = false,

                    RequirePkce = true,

                    // 客户端有权访问的范围（Scopes）
                    AllowedScopes = { "api1" },
                    RequireConsent = true,
                    Enabled = true,
                    AllowOfflineAccess = true,
                    RefreshTokenUsage = TokenUsage.ReUse

                },

                new Client
                {
                    ClientId = "client",
                    // 没有交互性用户，使用 clientid/secret 实现认证。
                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    // 用于认证的密码
                    ClientSecrets =
                    {
                        new Secret("secret".Sha256())
                    },
                    // 客户端有权访问的范围（Scopes）
                    AllowedScopes = { "api1" },


                },
                new Client
                {
                    ClientId = "ro.client",
                    AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,

                    ClientSecrets =
                    {
                        new Secret("secret".Sha256())
                    },
                    AllowedScopes = { "api1" },
                },
                new Client()
                {
                    ClientId = "client.sms",
                    AllowedGrantTypes = new List<string>(){ "sms" },
                    ClientSecrets =
                    {
                        new Secret("secret".Sha256())
                    },
                    AllowedScopes = { "api1" },
                    RefreshTokenExpiration = TokenExpiration.Sliding,
                    SlidingRefreshTokenLifetime = 1296000, // 这是默认值15天
                    UpdateAccessTokenClaimsOnRefresh = true
                }
            };
        }

        public static List<TestUser> GetUsers()
        {
            return new List<TestUser>
            {
                new TestUser
                {
                    SubjectId = "1",
                    Username = "alice",
                    Password = "password"
                },
                new TestUser
                {
                    SubjectId = "2",
                    Username = "bob",
                    Password = "password"
                }
            };
        }
    }

}
