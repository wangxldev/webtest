﻿using Abp.Application.Services.Dto;
using Microsoft.AspNetCore.Mvc;
using Pwc.vProfile.Application.Groups;
using Pwc.vProfile.Application.Groups.Dto;
using System.Threading.Tasks;

namespace Pwc.vProfile.WebApi.Controllers
{
    /// <summary>
    /// Group API
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class GroupController : ProfileControllerBase
    {
        private readonly IGroupAppService _groupAppService;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="groupAppService"></param>
        public GroupController(IGroupAppService groupAppService)
        {
            _groupAppService = groupAppService;
        }
        [HttpGet("ping")]
        public async Task<string> Ping()
        {
            return "success";
        }
        /// <summary>
        /// New save group API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("AddGroup")]
        public async Task AddGroup([FromBody]AddGroupInput input)
        {
            await _groupAppService.AddGroup(input);
        }
        /// <summary>
        /// Query all groups API
        /// </summary>
        /// <returns></returns>
        [HttpPost("GetGroupListAll")]
        public async Task<PagedResultDto<GroupDto>> GetGroupListAll()
        {
            return await _groupAppService.GetGroupListAll();
        }
        /// <summary>
        ///  Query groups by the name match(like %%) API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("GetGroupList")]
        public async Task<PagedResultDto<GroupDto>> GetGroupList([FromBody]GetGroupListInput input)
        {
            return await _groupAppService.GetGroupList(input);
        }
        /// <summary>
        /// Query group details by group name API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("GetGroup")]
        public async Task<GroupDto> GetGroup(GetGroupInput input)
        {
            return await _groupAppService.GetGroup(input);
        }
        /// <summary>
        ///  Update group API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("UpdateGroup")]
        public async Task UpdateGroup(UpdateGroupInput input)
        {
            await _groupAppService.UpdateGroup(input);
        }
        /// <summary>
        /// Update Group list API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("UpdateGroupList")]
        public async Task UpdateGroupList(UpdateGroupListInput input)
        {
            await _groupAppService.UpdateGroupList(input);
        }
        /// <summary>
        /// Delete group API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("DeleteGroup")]
        public async Task DeleteGroup(DeleteGroupInput input)
        {
            await _groupAppService.DeleteGroup(input);
        }
        /// <summary>
        /// Delete group list API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("DeleteGroupList")]
        public async Task DeleteGroupList(DeleteGroupListInput input)
        {
            await _groupAppService.DeleteGroupList(input);
        }
        /// <summary>
        /// Delete all group info API
        /// </summary>
        /// <returns></returns>
        [HttpPost("DeleteGroupAll")]
        public async Task DeleteGroupAll()
        {
            await _groupAppService.DeleteGroupAll();
        }
        /// <summary>
        ///  Move a group from Original node to target node API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("MoveGroup")]
        public async Task MoveGroup(MoveGroupInput input)
        {
            await _groupAppService.MoveGroup(input);
        }

        /// <summary>
        /// Get user total count of one group by group seqid API
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("GetUserCountByGroupName")]
        public async Task<int> GetUserCountByGroupName(GetUserCountByGroupNameInput input)
        {
            return await _groupAppService.GetUserCountByGroupName(input);
        }

    }
}