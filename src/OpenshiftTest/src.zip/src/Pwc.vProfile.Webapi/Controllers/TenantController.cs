﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pwc.vProfile.Application.Tenants;
using Pwc.vProfile.Application.Tenants.Dto;

namespace Pwc.vProfile.WebApi.Controllers
{
    /// <summary>
    /// Tenant Init API
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class TenantController : ProfileControllerBase
    {
        private readonly ITenantAppService _tenantAppService;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tenantAppService"></param>
        public TenantController(ITenantAppService tenantAppService)
        {
            _tenantAppService = tenantAppService;
        }
        [HttpGet("ping")]
        public async Task<string> Ping()
        {
            return "success";
        }
        /// <summary>
        /// Create database and admin user for each tenant in mongodb
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("InitTenantDb")]
        public async Task InitTenantDb([FromBody]InitTenantDbInput input)
        {
            await _tenantAppService.InitTenantDb(input);
        }
        /// <summary>
        /// update group rule under each tenant
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("UpdateGroupRule")]
        public async Task UpdateGroupRule(UpdateGroupRuleInput input)
        {
            await _tenantAppService.UpdateGroupRule(input);
        }
    }
}