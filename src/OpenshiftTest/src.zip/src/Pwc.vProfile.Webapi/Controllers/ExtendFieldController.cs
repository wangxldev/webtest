﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pwc.vProfile.Application.ExtendFields;
using Pwc.vProfile.Application.ExtendFields.Dto;

namespace Pwc.vProfile.WebApi.Controllers
{
    /// <summary>
    /// ExtendField API
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ExtendFieldController :   ProfileControllerBase
    {
        private readonly IExtendFieldAppService _extendFieldAppService;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="extendFieldAppService"></param>
        public ExtendFieldController(IExtendFieldAppService extendFieldAppService)
        {
            _extendFieldAppService = extendFieldAppService;
        }
        /// <summary>
        /// ping
        /// </summary>
        /// <returns></returns>
        [HttpGet("ping")]
        public async Task<string> Ping()
        {
            return "success";
        }
        /// <summary>
        /// Add ExtendField
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("AddExtendField")]
        public async Task AddExtendField([FromBody]AddExtendFieldInput input)
        {
            await _extendFieldAppService.AddExtendField(input);
        }
        /// <summary>
        /// Get BussType List
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetBussTypeList")]
        public async Task<PagedResultDto<string>> GetBussTypeList()
        {
            return await _extendFieldAppService.GetExtendFieldBussTypeList();
        }
        /// <summary>
        /// Get ExtendField List All
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetExtendFieldListAll")]
        public async Task<PagedResultDto<ExtendFieldDto>> GetExtendFieldListAll()
        {
            return await _extendFieldAppService.GetExtendFieldListAll();
        }
        /// <summary>
        /// Get ExtendField List by name(match contain) and bussType
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("GetExtendFieldList")]
        public async Task<PagedResultDto<ExtendFieldDto>> GetExtendFieldList(GetExtendFieldListInput input)
        {
            return await _extendFieldAppService.GetExtendFieldList(input);
        }
        /// <summary>
        /// Get ExtendField List of BussType
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("GetExtendFieldListByBussType")]
        public async Task<PagedResultDto<ExtendFieldDto>> GetExtendFieldListByBussType(GetExtendFieldListByBussTypeInput input)
        {
            return await _extendFieldAppService.GetExtendFieldListByBussType(input);
        }
        /// <summary>
        /// Update ExtendField
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("UpdateExtendField")]
        public async Task UpdateExtendField(UpdateExtendFieldInput input)
        {
            await _extendFieldAppService.UpdateExtendField(input);
        }
        /// <summary>
        /// Update ExtendField List
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("UpdateExtendFieldList")]
        public async Task UpdateExtendFieldList(List<UpdateExtendFieldInput> input)
        {
            await _extendFieldAppService.UpdateExtendFieldList(input);
        }
        /// <summary>
        /// Delete ExtendField by name and bussType
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost("DeleteExtendField")]
        public async Task DeleteExtendField(DeleteExtendFieldInput input)
        {
            await _extendFieldAppService.DeleteExtendField(input);
        }
        /// <summary>
        /// Delete ExtendField All
        /// </summary>
        /// <returns></returns>
        [HttpPost("DeleteExtendFieldAll")]
        public async Task DeleteExtendFieldAll()
        {
            await _extendFieldAppService.DeleteExtendFieldAll();
        }
    }
}