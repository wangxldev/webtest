﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pwc.vProfile.Application.Auth.Permissions;
using Pwc.vProfile.Application.Auth.Permissions.Dto;

namespace Pwc.vProfile.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PermissionController : ProfileControllerBase
    {
        private readonly IPermissionAppService _permissionAppService;

        public PermissionController(IPermissionAppService permissionAppService)
        {
            _permissionAppService = permissionAppService;
        }

        [HttpGet("getall")]
        public async Task<ListResultDto<FlatPermissionWithLevelDto>> GetAll()
        {
            return _permissionAppService.GetAllPermissions();
        }
    }
}