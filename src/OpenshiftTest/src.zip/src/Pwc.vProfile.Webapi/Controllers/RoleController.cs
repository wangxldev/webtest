﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pwc.vProfile.Application.Auth.Roles;
using Pwc.vProfile.Application.Auth.Roles.Dto;

namespace Pwc.vProfile.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ProfileControllerBase
    {
        private readonly IRoleAppService _roleAppService;

        public RoleController(IRoleAppService roleAppService)
        {
            _roleAppService = roleAppService;
        }

        [HttpPost("createOrUpdate")]
        public async Task CreateOrUpdate(CreateOrUpdateInput model)
        {
            await _roleAppService.CreateOrUpdate(model);
        }

        [HttpGet("delete")]
        public async Task Delete(string name)
        {
            await _roleAppService.Delete(name);
        }

        [HttpPost("getRoles")]
        public async Task<PagedResultDto<RoleListDto>> GetRoles(GetRolesInput model)
        {
            return await _roleAppService.GetRoles(model);
        }

        [HttpGet("getRoleForEdit")]
        public async Task<GetRoleForEditOutput> GetRoleForEdit(string name)
        {
            return await _roleAppService.GetRoleForEdit(name);
        }

        [HttpGet("getRolePremissions")]
        public async Task<List<string>> GetRolePremissions(string name)
        {
            return await _roleAppService.GetRolePremissions(name);
        }
    }
}