﻿using Microsoft.AspNetCore.Mvc;
using Pwc.vProfile.Application.Favourites;
using System.Threading.Tasks;

namespace Pwc.vProfile.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FavouriteController : ProfileControllerBase
    {
        private readonly IFavouriteAppService _favouriteAppService;
        
        public FavouriteController(IFavouriteAppService favouriteAppService)
        {
            _favouriteAppService = favouriteAppService;
        }
        [HttpGet("ping")]
        public async Task<string> Ping()
        {
            return "success";
        }
    }
}