﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Threading.Tasks;
using Abp.Authorization;
using Abp.UI;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.Options;
using MongoDB.Driver;
using Pwc.vProfile.Core;
using Pwc.vProfile.Core.Auth.Permissions;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.Core.ExtendFields;
using Pwc.vProfile.Data.TenantDb;
using Pwc.vProfile.Utility.Extensions;

namespace Pwc.vProfile.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManagerController : ProfileControllerBase
    {
        private readonly ITenantDbContext _tenantDbContext;

        public ManagerController(ITenantDbContext tenantDbContext)
        {
            _tenantDbContext = tenantDbContext;
        }

        /// <summary>
        /// ping接口
        /// </summary>
        /// <returns></returns>
        [HttpGet("ping")]
        public async Task<string> Ping()
        {



//            await AddExtends();

            return "success";
        }

//        [AbpAuthorize(AppPermissions.Tenant_Admin_Users_Create)]
        [HttpGet("authTest")]
        public async Task<string> AuthTest()
        {
            return "success";
        }

        [HttpGet("UserExtendsTest")]
        public async Task<List<BsonDocument>> UserExtendsTest()
        {
            var collection = _tenantDbContext.DbSet<TestUser>();

            var filter = Builders<TestUser>.Filter.Eq("extends_01.age", "14");

            var project = Builders<TestUser>.Projection.Include(u => u.Id).Include(u => u.UserName).Include(u => u.Email).Include("extends_01.age");

            var sort = Builders<TestUser>.Sort.Descending(u => u.Id);

//            var count = await collection.CountDocumentsAsync(filter);

            var list = await collection.Find(filter).Project(project).Limit(10).Sort(sort).ToListAsync();

            return list;
        }

        private async Task AddExtends()
        {
            var collection = _tenantDbContext.DbSet<TestUser>();

            var filterAll = Builders<TestUser>.Filter.Empty;
//            var filterAll = Builders<TestUser>.Filter.Eq(u=>u.Id,new ObjectId("57cea1da236ea70899fbf6d9"));

            var idsDoc = await collection.Find(filterAll).Project(Builders<TestUser>.Projection.Include(u=>u.Id)).ToListAsync();

            var ids = new List<string>();

            foreach (var doc in idsDoc)
            {
                var user = doc.BsonTo<TestUser>();
                if (user!=null)
                {
                    var dic = new Dictionary<string, string>();

                    dic.Add("age",new Random().Next(10,100).ToString());
                    dic.Add("address",Guid.NewGuid().ToString());

                    var update = Builders<TestUser>.Update.Set(u=>u.Extends, dic);

                    var filter = Builders<TestUser>.Filter.Eq(u => u.Id, user.Id);

                    await collection.UpdateManyAsync(filter, update, new UpdateOptions()
                    {
                        IsUpsert = true
                    });
                }
            }
        }
    }

    [Table("Users")]
    public class TestUser:MongoEntityBase
    {
        public string OfficeCode { get; set; }

        public string CountryCode { get; set; }

        public string Email { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Password { get; set; }

        public string Phone { get; set; }

        public string UserName { get; set; }

        public string OrganizationCode { get; set; }

        public string ActiveUrl { get; set; }

        public string Salt { get; set; }

        public DateTime? CreateDate { get; set; }

        public string UserID { get; set; }

//        [BsonExtraElements]
        public string StaffCode { get; set; }

        public string Department { get; set; }

        public string GUID { get; set; }

        public bool ActiveFlag { get; set; }

        public List<string> Devices { get; set; }

        public bool ActivationFlag { get; set; }

        public string LastAction { get; set; }

        public string LastBatchNo { get; set; }

        public DateTime? LastUpdate { get; set; }

        public string JobTitle { get; set; }

        public string OfficeNo { get; set; }

        public string MobileNo { get; set; }

        public string OfficeFax { get; set; }

        public string OfficeLocation { get; set; }

        public string MobileNum { get; set; }



        [BsonDictionaryOptions(DictionaryRepresentation.Document)]
        [BsonElement("extends_01")]
        public Dictionary<string, string> Extends { get; set; }
    }
}