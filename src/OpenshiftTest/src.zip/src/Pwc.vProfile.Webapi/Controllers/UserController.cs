﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pwc.vProfile.Application.Auth.Users;
using Pwc.vProfile.Application.Auth.Users.Dto;

namespace Pwc.vProfile.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ProfileControllerBase
    {
        private readonly IUserAppService _userAppService;

        public UserController(IUserAppService userAppService)
        {
            _userAppService = userAppService;
        }

        [HttpPost("createOrUpdate")]
        public async Task CreateOrUpdate(CreateOrUpdateInput model)
        {
            await _userAppService.CreateOrUpdate(model);
        }

        [HttpGet("delete")]
        public async Task Delete(long id)
        {
            await _userAppService.Delete(new EntityDto<long>(id));
        }

        [HttpPost("getUsers")]
        public async Task<PagedResultDto<GetUsersOutput>> GetUsers(GetUsersInput model)
        {
            return await _userAppService.GetUsers(model);
        }

        [HttpGet("getUserForEdit")]
        public async Task<GetUserForEditOutput> GetUserForEdit(long id)
        {
            return await _userAppService.GetUserForEdit(new NullableIdDto<long>(id));
        }

        [HttpPost("setLockout")]
        public async Task SetLockout(SetLockoutInput model)
        {
            await _userAppService.SetLockout(model);
        }

        [HttpPost("setActivate")]
        public async Task SetActivate(SetActivateInput model)
        {
            await _userAppService.SetActivate(model);
        }

        [HttpGet("getUserRoles")]
        public async Task<List<string>> GetUserRoles(long id)
        {
            return await _userAppService.GetUserRoles(new EntityDto<long>(id));
        }

        [HttpPost("updateUserRoles")]
        public async Task UpdateUserRoles(UpdateUserRolesInput model)
        {
            await _userAppService.UpdateUserRoles(model);
        }

        [HttpGet("getDetail")]
        public async Task<GetDetailOutput> GetDetail(long id)
        {
            return await _userAppService.GetDetail(new NullableIdDto<long>(id));
        }

        [HttpGet("GetUserGroups")]
        public async Task<List<GetUserGroupsOutput>> GetUserGroups(long id)
        {
            return await _userAppService.GetUserGroups(new EntityDto<long>(id));
        }

        [HttpPost("UpdateUserGroups")]
        public async Task UpdateUserGroups(UpdateUserGroupsInput model)
        {
            await _userAppService.UpdateUserGroups(model);
        }
    }
}