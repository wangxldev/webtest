﻿using System;
using Abp.Dependency;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Pwc.vProfile.Core.Auth;
using Pwc.vProfile.WebLogin.Extensions;

namespace Pwc.vProfile.WebLogin.Context
{
    /// <summary>
    /// 当前用户上下文信息
    /// </summary>
    public class SSOContext:ITransientDependency
    {
        private bool _isInited = false;

        public SSOContextUser User { get; private set; }

        public HttpContext Context { get; private set; }

        public string SId { get; set; }

        /// <summary>
        /// 是否去服务端验证过当前用户信息
        /// </summary>
        public bool IsVerified { get; set; } = false;

        public void Init(CookieValidatePrincipalContext context)
        {
            if (_isInited) return;

            Context = context.HttpContext;

            var identity = context.Principal.Identity;

            // 获取用户信息
            var tid = identity.GetTid() ;
            var uid = identity.GetUid();
            var uName = identity.GetUserName();
            var email = identity.GetEmail();

            User=new SSOContextUser(tid,uid,uName,email);

            SId = identity.GetSid();

            _isInited = true;
        }
    }
}
