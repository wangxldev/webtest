﻿namespace Pwc.vProfile.WebLogin.Context
{
    public class SSOContextUser
    {
        public SSOContextUser(long tenantId,long userId,string userName,string email)
        {
            TenantId = tenantId;
            UserId = userId;
            UserName = userName;
            Email = email;
        }

        public long TenantId { get; }

        public long UserId { get; }

        public string UserName { get; }

        public string Email { get; }
    }
}
