﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using Abp;
using Abp.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.AspNetCore.Server.Kestrel.Core.Internal.Http;
using Pwc.vProfile.Core;

namespace Pwc.vProfile.WebLogin.Extensions
{
    public static  class ClaimsIdentityExtension
    {
        /// <summary>
        /// 获取当前上下面中的TenantId
        /// </summary>
        /// <param name="identity"></param>
        /// <returns></returns>
        public static long GetTid(this IIdentity identity)
        {
            Check.NotNull(identity, nameof(identity));
            var claimsIdentity = identity as ClaimsIdentity;
            var tenantIdOrNull = claimsIdentity?.Claims?.FirstOrDefault(c => c.Type == ProfileClaimTypes.TenantId);
            if (tenantIdOrNull == null || tenantIdOrNull.Value.IsNullOrWhiteSpace())
            {
                throw new Exception();
            }
            return Convert.ToInt64(tenantIdOrNull.Value);
        }

        public static string GetSid(this IIdentity identity)
        {
            Check.NotNull(identity, nameof(identity));
            var claimsIdentity = identity as ClaimsIdentity;
            var sIdOrNull = claimsIdentity?.Claims?.FirstOrDefault(c => c.Type == ProfileClaimTypes.SignId);
            if (sIdOrNull == null || sIdOrNull.Value.IsNullOrWhiteSpace())
            {
                return null;
            }

            return sIdOrNull.Value;
        }

        public static long GetUid(this IIdentity identity)
        {
            Check.NotNull(identity, nameof(identity));
            var claimsIdentity = identity as ClaimsIdentity;
            var sIdOrNull = claimsIdentity?.Claims?.FirstOrDefault(c => c.Type == ProfileClaimTypes.UserId);
            if (sIdOrNull == null || sIdOrNull.Value.IsNullOrWhiteSpace())
            {
                throw new Exception();
            }

            return Convert.ToInt64(sIdOrNull.Value);
        }

        public static string GetUserName(this IIdentity identity)
        {
            Check.NotNull(identity, nameof(identity));
            var claimsIdentity = identity as ClaimsIdentity;
            var sIdOrNull = claimsIdentity?.Claims?.FirstOrDefault(c => c.Type == ProfileClaimTypes.UserName);
            if (sIdOrNull == null || sIdOrNull.Value.IsNullOrWhiteSpace())
            {
                return null;
            }

            return sIdOrNull.Value;
        }

        public static string GetEmail(this IIdentity identity)
        {
            Check.NotNull(identity, nameof(identity));
            var claimsIdentity = identity as ClaimsIdentity;
            var sIdOrNull = claimsIdentity?.Claims?.FirstOrDefault(c => c.Type == ProfileClaimTypes.Email);
            if (sIdOrNull == null || sIdOrNull.Value.IsNullOrWhiteSpace())
            {
                return null;
            }

            return sIdOrNull.Value;
        }
    }
}
