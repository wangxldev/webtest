﻿
    "use strict";

$(function () {

    var btnLogin = "#btn-login";

        var $loginForm = $("#login-form");
        var $alert = $("#msg-alert");

        var $loginName = $("#loginName");
        var $pwc = $("#password");

        if ($loginName.val()) {
            $pwc.focus();
        } else {
            $loginName.focus();
        }

        $(btnLogin).click(function () {

            $(btnLogin).addClass("loading");
            app.ajax({
                contentType: app.consts.contentTypes.formUrlencoded,
                url: app.appPath + "account/login",
                data: $loginForm.serialize(),
                appHandleError:false,
                success: function (d) {
                    $(btnLogin).removeClass("loading");
                    $alert.empty().hide();
                    $("#msg-info").html("<p>Login completed.</p><p>Redirecting to application . . .</p>").show();
                },
                error: function (error) {
                    $alert.html(error.message + "<h6>" + error.details + "</h6>").show();
                    $(btnLogin).removeClass("loading");
                    $loginName.focus();
                }
            });

        });

        // TODO form验证
    });