﻿using System;

namespace Pwc.vProfile.WebLogin.Cookies
{
    public class CookieConsts
    {
        /// <summary>
        /// 登录Cookie
        /// </summary>
        public const String LoginCookie = "pwc.sso";

        /// <summary>
        /// 登录cookie名称
        /// </summary>
        public const String LoginCookieName = "sid";
    }
}
