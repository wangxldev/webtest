﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Abp.Dependency;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Pwc.vProfile.Application.SSO;
using Pwc.vProfile.Utility;
using Pwc.vProfile.WebLogin.Context;

namespace Pwc.vProfile.WebLogin.Cookies
{
    public class CookieEvents
    {
        public static async Task OnValidatePrincipal(CookieValidatePrincipalContext context)
        {
            var workConext = IocManager.Instance.Resolve<SSOContext>();

            workConext.Init(context);

            var ssoAppService = IocManager.Instance.Resolve<ISSOAppService>();
            var isValid = await ssoAppService.Verify(workConext.SId, workConext.User.TenantId, workConext.User.UserId);

            if (!isValid)
            {
                context.RejectPrincipal();
                await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            }
        }
    }
}
