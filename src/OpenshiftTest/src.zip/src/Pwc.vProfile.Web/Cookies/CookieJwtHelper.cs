﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Abp.Extensions;
using JWT;
using JWT.Serializers;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Http;

namespace Pwc.vProfile.WebLogin.Cookies
{
    public class CookieJwtHelper
    {
        public static ClaimsPrincipal GetSidByCookeName(string sid)
        {
            return null;
        }

        /// <summary>
        /// 解析cookie(sid)中的jwt
        /// <para>该方法仅仅解析jwtToken,不捕获任何异常</para>
        /// </summary>
        /// <param name="jwtToken"></param>
        /// <returns></returns>
        public static ClaimsPrincipal DecodeCookieJwt(string jwtToken)
        {
            if (jwtToken.IsNullOrWhiteSpace())
            {
                return null;
            }

            var secret = "123456";

            IJsonSerializer serializer = new JsonNetSerializer();
            IDateTimeProvider provider = new UtcDateTimeProvider();
            IJwtValidator validator = new JwtValidator(serializer, provider);
            IBase64UrlEncoder urlEncoder = new JwtBase64UrlEncoder();
            IJwtDecoder decoder = new JwtDecoder(serializer, validator, urlEncoder);

            var payload = decoder.DecodeToObject<IDictionary<string, string>>(jwtToken, secret, true);

            var claims = payload.Select(kv => new Claim(kv.Key, kv.Value)).ToList();
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

            var principal = new ClaimsPrincipal(identity);

            return principal;
        }
    }
}
