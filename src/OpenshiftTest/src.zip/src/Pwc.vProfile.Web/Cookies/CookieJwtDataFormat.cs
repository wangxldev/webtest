﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Abp.Runtime.Security;
using JWT;
using JWT.Algorithms;
using JWT.Builder;
using JWT.Serializers;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.IdentityModel.Tokens;

namespace Pwc.vProfile.WebLogin.Cookies
{
    public class CookieJwtDataFormat: ISecureDataFormat<AuthenticationTicket>
    {
        public string Protect(AuthenticationTicket data)
        {
            return Protect(data,null);
        }

        public string Protect(AuthenticationTicket data, string purpose)
        {
            var token = new JwtBuilder()
                .WithAlgorithm(new HMACSHA256Algorithm())
                .WithSecret("123456")
                ;

            if (data.Principal!=null && data.Principal.Claims.Any())
            {
                foreach (var claim in data.Principal.Claims)
                {
                    token.AddClaim(claim.Type, claim.Value);
                }
            }

            

            return token.Build();

        }

        public AuthenticationTicket Unprotect(string protectedText)
        {
            return Unprotect(protectedText,null);
        }

        public AuthenticationTicket Unprotect(string protectedText, string purpose)
        {
            var secret = "123456";

            try
            {
                var principal = CookieJwtHelper.DecodeCookieJwt(protectedText);
                
                // 验证SessionId

                // Validation passed. Return a valid AuthenticationTicket:
                return new AuthenticationTicket(principal, new AuthenticationProperties()
                {
                    IsPersistent = true
                }, CookieAuthenticationDefaults.AuthenticationScheme);
            }
            catch (TokenExpiredException)
            {
                throw new Exception("Token has expired");
            }
            catch (SignatureVerificationException)
            {
                throw new Exception("Token has invalid signature");
            }
        }
    }
}
