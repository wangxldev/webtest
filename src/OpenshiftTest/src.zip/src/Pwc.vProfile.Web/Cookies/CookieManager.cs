﻿using System;
using System.IO;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;

namespace Pwc.vProfile.WebLogin.Cookies
{
    public class CookieManager
    {
        public static void AddCookie(IServiceCollection services, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                services
                    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                    .AddIdentityCookies(builder =>
                    {
                        builder.ApplicationCookie.Configure(options =>
                        {
                            options.Cookie.Name = "sid";
                            options.Cookie.HttpOnly = true;
                            options.Cookie.Path = "/";
                        });

                        builder.ExternalCookie.Configure(options =>
                        {
                            options.Cookie.Name = "ext";
                            options.Cookie.HttpOnly = true;
                        });

                        builder.TwoFactorRememberMeCookie.Configure(options =>
                        {
                            options.Cookie.Name = "tf_rm";
                            options.Cookie.HttpOnly = true;
                        });

                        builder.TwoFactorUserIdCookie.Configure(options =>
                        {
                            options.Cookie.Name = "tf_uid";
                            options.Cookie.HttpOnly = true;
                        });
                    });
            }
            else
            {
                services.AddDataProtection(options => { options.ApplicationDiscriminator = "pwc.com"; })
                    .PersistKeysToFileSystem(new DirectoryInfo(@"c:\keys"))
                    .SetDefaultKeyLifetime(TimeSpan.FromDays(14))
                    .SetApplicationName("pwc")
                    ;

                services
                    .AddAuthentication(CookieConsts.LoginCookie)
                    .AddCookie(CookieConsts.LoginCookie, options =>
                    {
                        options.Cookie.Domain = ".pwc.com";
                        options.Cookie.Name = CookieConsts.LoginCookieName;
                        options.Cookie.HttpOnly = true;
                        options.Cookie.Path = "/";
                    });
            }


        }


    }
}