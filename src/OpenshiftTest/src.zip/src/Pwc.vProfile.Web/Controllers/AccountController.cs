﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Cache;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Configuration.Startup;
using Abp.Dependency;
using Abp.Domain.Uow;
using Abp.Extensions;
using Abp.Runtime.Security;
using Abp.UI;
using Abp.Web.Models;
using IdentityServer4.Extensions;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Pwc.vProfile.Application.Auth;
using Pwc.vProfile.Application.Sessions;
using Pwc.vProfile.Application.SSO;
using Pwc.vProfile.Application.SSO.Dto;
using Pwc.vProfile.Core;
using Pwc.vProfile.Core.Auth;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.Core.Tenants;
using Pwc.vProfile.WebLogin.Cookies;
using Pwc.vProfile.WebLogin.Extensions;
using Pwc.vProfile.WebLogin.Models.Account;

namespace Pwc.vProfile.WebLogin.Controllers
{
    public class AccountController : ProfileControllerBase
    {
        private readonly ISessionAppService _sessionAppService;
        private readonly IMultiTenancyConfig _multiTenancyConfig;
        private readonly LogInManager _logInManager;
        private readonly SignInManager _signInManager;
        private readonly UserManager _userManager;
        private readonly IHostingEnvironment _env;
        private readonly LoginResultTypeHelper _loginResultTypeHelper;
        private readonly ISSOAppService _ssoAppService;

        public AccountController(ISessionAppService sessionAppService, IMultiTenancyConfig multiTenancyConfig, LogInManager logInManager , SignInManager signInManager, UserManager userManager, IHostingEnvironment env, LoginResultTypeHelper loginResultTypeHelper, ISSOAppService ssoAppService)
        {
            _sessionAppService = sessionAppService;
            _multiTenancyConfig = multiTenancyConfig;
            _logInManager = logInManager;
            _signInManager = signInManager;
            _userManager = userManager;
            _env = env;
            _loginResultTypeHelper = loginResultTypeHelper;
            _ssoAppService = ssoAppService;
        }
        
        #region Login
        

        public async Task<ActionResult> Login(String loginName = "", String returnUrl = "", String successMessage = "",
            String ss = "")
        {
//            // 检查当前的登录状态
//            var principal = CheckLoginStatusByCookie();
//
//            // 如果当前已经存在cookie并且可以正常解析则直接跳转
//            if (principal!=null)
//            {
//                var sid = principal.Identity.GetSid();
//                var tid = principal.Identity.GetTid();
//                var uid = principal.Identity.GetUid();
//                if (!sid.IsNullOrWhiteSpace() && tid>0)
//                {
//                    // 验证sid
//                    var isValid = await _ssoAppService.Verify(sid, tid, uid);
//                    if (!isValid)
//                    {
//                        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
//                    }
//                    else
//                    {
//                        returnUrl = NormalizeReturnUrl(returnUrl);
//                        if (returnUrl == GetAppHomeUrl())
//                        {
//                            return Redirect(returnUrl);
//                        }
//
//                        returnUrl = AddSingleSignInParametersToReturnUrl(returnUrl, sid, tid);
//                        return Redirect(returnUrl);
//                    }
//                }
//            }

//            if (!String.IsNullOrWhiteSpace(ss) && ss.Equals("true", StringComparison.OrdinalIgnoreCase) &&
//                AbpSession.UserId > 0)
//            {
//                var output = await _sessionAppService.UpdateUserSignInToken();
//                returnUrl = AddSingleSignInParametersToReturnUrl(returnUrl, output.SignInToken, AbpSession.UserId.Value);
//                return Redirect(returnUrl);
//            }
        
            ViewBag.ReturnUrl = returnUrl;
            ViewBag.SingleSignIn = ss;
        
            return View(new LoginFormViewModel()
            {
                IsSelfRegistrationEnabled = false,
                SuccessMessage = successMessage,
                LoginName = loginName
            });
        }

        [HttpPost]
        public virtual async Task<JsonResult> Login(LoginViewModel model, String returnUrl = "",
            String returnUrlHash = "", String ss = "")
        {
            returnUrl = NormalizeReturnUrl(returnUrl);
            if (String.IsNullOrWhiteSpace(returnUrlHash))
            {
                returnUrl = returnUrl + returnUrlHash;
            }
        
            var loginResult = await GetLoginResultAsync(model.LoginName, model.Password);
        
//            if (!String.IsNullOrEmpty(ss) && ss.Equals("true", StringComparison.OrdinalIgnoreCase) &&
//                loginResult.Result == LogInResultTypeEnum.Success)
//            {
//                loginResult.User.SetSignInToken();
//                returnUrl = AddSingleSignInParametersToReturnUrl(returnUrl, loginResult.User.SignInToken, loginResult.User.SeqId);
//            }

            //            if (loginResult.User.ShouldChangePasswordOnNextLogin)
            //            {
            //                loginResult.User.SetNewPasswordResetCode();
            //                return Json(new AjaxResponse
            //                {
            //                    TargetUrl = Url.Action(
            //                            "ResetPassword",
            //                            new ResetPasswordViewModel
            //                            {
            //                                TenantId = AbpSession.TenantId,
            //                                UserId = loginResult.User.Id,
            //                                ResetCode = loginResult.User.PasswordResetCode,
            //                                ReturnUrl = returnUrl,
            //                                SingleSignIn = ss
            //                            })
            //                });
            //            }

            //            var signInResult = await _signInManager.SignInOrTwoFactorAsync(loginResult, loginModel.RememberMe);


//            loginResult.Identity.AddClaim(new Claim(ProfileClaimTypes.SignId, loginResult.User.SignInToken));

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(loginResult.Identity), new AuthenticationProperties()
            {
                IsPersistent = true
            });

            var cookie = Request.Cookies[""];

            Response.Cookies..Expires = DateTime.Now.AddDays(1);
            // TODO Ignore TwoFactor

            return Json(new AjaxResponse() { TargetUrl = returnUrl });
        }
        
        private async Task<LogInResult> GetLoginResultAsync(String loginName, String password)
        {
            var loginResult = await _logInManager.LoginAsync(loginName, password);
            switch (loginResult.Result)
            {
                case LogInResultTypeEnum.Success:
                    return loginResult;
                default:
                    throw _loginResultTypeHelper.CreateExceptionForFailedLoginAttempt(loginResult.Result, loginName);
            }
        }

        /// <summary>
        /// 为ReturnUrl添加单点登录参数
        /// </summary>
        /// <param name="returnUrl"></param>
        /// <param name="sid"></param>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        private String AddSingleSignInParametersToReturnUrl(String returnUrl, String sid,long tenantId)
        {
            returnUrl += (returnUrl.Contains("?") ? "&" : "?") +
                         "sid=" + sid +
                         "&tid=" + Convert.ToBase64String(Encoding.UTF8.GetBytes(tenantId.ToString()))
                ;
        
            return returnUrl;
        }


        /// <summary>
        /// 通过cookie检查登录状态
        /// </summary>
        /// <returns></returns>
        private ClaimsPrincipal CheckLoginStatusByCookie()
        {
            if (HttpContext.Request.Cookies.ContainsKey("sid"))
            {
                try
                {
                    var jwt = HttpContext.Request.Cookies["sid"];

                    if (jwt.IsNullOrWhiteSpace()) return null;

                    var principal = CookieJwtHelper.DecodeCookieJwt(jwt);

                    return principal;
                }
                catch (Exception e)
                {
                    return null;
                }
            }

            return null;
        }
        
        #endregion
        
        #region Logout
        
        public async Task<ActionResult> Logout(String returnUrl = "")
        {
            var sid = User.Identity.GetSid();
            var uid = User.Identity.GetUid();
            var tid = User.Identity.GetTid();

            await _ssoAppService.SignOutAsync(sid,tid,uid);

//            await _signInManager.SignOutAsync();

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignOutAsync(IdentityConstants.ApplicationScheme);
            await HttpContext.SignOutAsync(IdentityConstants.ExternalScheme);
            await HttpContext.SignOutAsync(IdentityConstants.TwoFactorUserIdScheme);

            if (!String.IsNullOrEmpty(returnUrl))
            {
                return Redirect(returnUrl);
            }
            
            return RedirectToAction("Login");
        }
        
        #endregion
        
        //        #region ResetPassword
        //
        //        public async Task<ActionResult> ResetPassword(ResetPasswordViewModel model)
        //        {
        //            await SwitchToTenantIfNeeded(model.TenantId);
        //
        //            var user = await _userManager.GetUserByIdAsync(model.UserId);
        //            if (user == null)
        //            {
        //                throw new UserFriendlyException("未找到用户信息");
        //            }
        //
        //            model.PasswordComplexitySetting = await _passwordComplexitySettingStore.GetSettingsAsync();
        //
        //            return View(model);
        //        }
        //
        //        [HttpPost]
        //        public async Task<ActionResult> ResetPassword(ResetPasswordInput input)
        //        {
        //            var output = await _accountAppService.ResetPassword(input);
        //
        //            if (output.CanLogin)
        //            {
        //                var user = await _userManager.GetUserByIdAsync(input.UserId);
        //                await _signInManager.SignInAsync(user, false);
        //
        //                if (!String.IsNullOrEmpty(input.SingleSignIn) &&
        //                    input.SingleSignIn.Equals("true", StringComparison.OrdinalIgnoreCase))
        //                {
        //                    user.SetSignInToken();
        //                    var returnUrl = AddSingleSignInParametersToReturnUrl(input.ReturnUrl, user.SignInToken, user.Id, user.TenantId);
        //                    return Redirect(returnUrl);
        //                }
        //            }
        //
        //            return Redirect(NormalizeReturnUrl(input.ReturnUrl));
        //        }
        //
        //        #endregion
        //
        //        #region Common
        //
//        private string GetTenancyNameOrNull()
//        {
//            if (!AbpSession.TenantId.HasValue)
//            {
//                return null;
//            }
//        
//            return _tenantCache.GetOrNull(AbpSession.TenantId.Value)?.TenancyName;
//        }
        //
        //        private async Task SwitchToTenantIfNeeded(Int32? tenantId)
        //        {
        //            if (tenantId != AbpSession.TenantId)
        //            {
        //                if (_webUrlService.SupportTenancyNameInUrl)
        //                {
        //                    throw new InvalidOperationException($"Given tenantid ({tenantId}) does not match to tenant's URL!");
        //                }
        //
        ////                SetTenantIdCookie(tenantId);
        //                CurrentUnitOfWork.SetTenantId(tenantId);
        //                await _signInManager.SignOutAsync();
        //            }
        //        }
        //
        //        #endregion
        //
        #region Helper
        
        public string GetAppHomeUrl()
        {
            return Url.Action("Index", "Home");
        }
        
        private String NormalizeReturnUrl(String returnUrl, Func<String> defaultValueBuilder = null)
        {
            if (defaultValueBuilder == null)
            {
                defaultValueBuilder = GetAppHomeUrl;
            }
        
            if (returnUrl.IsNullOrEmpty())
            {
                return defaultValueBuilder();
            }
            return defaultValueBuilder();
        }
        
        #endregion
    }
}