﻿using Abp.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Pwc.vProfile.WebLogin.Controllers
{
    public abstract class ProfileControllerBase : AbpController
    {
    }
}