﻿using System;
using Abp.Authorization;
using Abp.Dependency;
using Abp.Runtime.Caching;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Pwc.vProfile.WebLogin.Controllers
{

    [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    public class HomeController : ProfileControllerBase
    {
        private readonly ICacheManager _cacheManager;

        public HomeController(ICacheManager cacheManager)
        {
            _cacheManager = cacheManager;
        }

        public IActionResult Index()
        {
            var user = HttpContext.User;

            return View();
        }

        [AllowAnonymous]
        public IActionResult Test()
        {
            var user = HttpContext.User;

            return View();
        }

    }
}
