﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pwc.vProfile.Application.SSO;
using Pwc.vProfile.Application.SSO.Dto;

namespace Pwc.vProfile.WebLogin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SSOController : ProfileControllerBase
    {
        private readonly ISSOAppService _ssoAppService;

        public SSOController(ISSOAppService ssoAppService)
        {
            _ssoAppService = ssoAppService;
        }

        /// <summary>
        /// 根据sid获取用户信息
        /// </summary>
        /// <param name="sid"></param>
        /// <returns></returns>
        public async Task GetUserInfo(string sid, long tid, long uid)
        {

        }

        /// <summary>
        /// 验证sid是否有效
        /// </summary>
        /// <param name="sid"></param>
        /// <param name="tid"></param>
        /// <param name="uid"></param>
        /// <returns></returns>
        public async Task<bool> Verify(string sid,long tid,long uid)
        {
            return await Task.FromResult(false);
        }

    }
}