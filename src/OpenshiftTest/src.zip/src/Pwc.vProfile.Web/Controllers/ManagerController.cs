﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Pwc.vProfile.WebLogin.Controllers
{
    public class ManagerController : ProfileControllerBase
    {
        [HttpGet("ping")]
        public async Task<string> Ping()
        {
            return "success";
        }

    }
}