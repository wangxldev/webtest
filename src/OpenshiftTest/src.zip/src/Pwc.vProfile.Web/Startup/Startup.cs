﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Abp.AspNetCore;
using Abp.Castle.Logging.Log4Net;
using Castle.Facilities.Logging;
using IdentityServer4.Models;
using IdentityServer4.Test;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Pwc.vProfile.Core.Auth;
using Pwc.vProfile.Core.Auth.Ids;
using Pwc.vProfile.Core.Auth.Users;
using Pwc.vProfile.WebLogin.Cookies;

namespace Pwc.vProfile.WebLogin.Startup
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IHostingEnvironment environment)
        {
            Configuration = configuration;
            Environment = environment;
        }
        
        public IConfiguration Configuration { get; }

        public IHostingEnvironment Environment { get; }
        
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            IdentityRegistrar.Register(services);

            services.AddRouting(options =>
            {
                options.LowercaseUrls = true;
            });

            services.AddDataProtection(options => { options.ApplicationDiscriminator = "pwc.com"; })
                .PersistKeysToFileSystem(new DirectoryInfo(@"c:\keys"))
                .SetDefaultKeyLifetime(TimeSpan.FromDays(14))
                .SetApplicationName("vProfile")
                ;

            services
                .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
            {
                options.Cookie.Name = "sid";
//                options.Cookie.Domain = ".pwc.com";
                options.Cookie.HttpOnly = true;
                options.Cookie.Path = "/";
//                options.TicketDataFormat=new CookieJwtDataFormat();
//                options.Events.OnValidatePrincipal = CookieEvents.OnValidatePrincipal;

                options.SlidingExpiration = true;

            })
            ;

            //            CookieManager.AddCookie(services,Environment);

            return services.AddAbp<ProfileWebModule>(options =>
            {
                options.IocManager.IocContainer.AddFacility<LoggingFacility>(
                    f => f.UseAbpLog4Net().WithConfig(Path.Combine(Environment.ContentRootPath, "log4net.config"))
                );
            });
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseAbp(options =>
            {
                options.UseAbpRequestLocalization = false;
                options.UseSecurityHeaders = true;
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseAuthentication();

            

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
