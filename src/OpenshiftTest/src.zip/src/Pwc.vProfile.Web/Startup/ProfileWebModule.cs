﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.AspNetCore.Mvc.Results.Wrapping;
using Abp.Dependency;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Abp.Runtime.Caching.Redis;
using Pwc.vProfile.Application;
using Pwc.vProfile.Utility;
using Pwc.vProfile.Web.Core;

namespace Pwc.vProfile.WebLogin.Startup
{

    [DependsOn(
        typeof(AbpRedisCacheModule),
        typeof(ProfileApplicationModule),
        typeof(ProfileWebCoreModule)
    )]
    public class ProfileWebModule:AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Modules.AbpAspNetCore()
                .CreateControllersForAppServices(
                    typeof(AbpAspNetCoreModule).GetAssembly()
                );

            Configuration.Caching.UseRedis(options =>
            {
                options.ConnectionString = "hkappdwv015:6379,password=P@ss1234,ConnectTimeout=10000,abortConnect=false";
                options.DatabaseId = 15;
            });
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ProfileWebModule).GetAssembly());
        }
    }
}
