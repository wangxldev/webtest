﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Pwc.vProfile.WebLogin.Models.Account
{
    public class ResetPasswordViewModel
    {
        public Int32? TenantId { get; set; }

        [Range(1,long.MaxValue)]
        public long UserId { get; set; }

        public String ResetCode { get; set; }

//        public PasswordComplexitySetting PasswordComplexitySetting { get; set; }

        public String ReturnUrl { get; set; }

        public String SingleSignIn { get; set; }
    }
}
