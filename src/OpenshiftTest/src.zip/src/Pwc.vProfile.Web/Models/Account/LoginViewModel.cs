﻿namespace Pwc.vProfile.WebLogin.Models.Account
{
    public class LoginViewModel:LoginModel
    {
        public bool RememberMe { get; set; }
    }
}
