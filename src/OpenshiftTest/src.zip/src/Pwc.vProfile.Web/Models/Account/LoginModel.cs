﻿using System;
using System.ComponentModel.DataAnnotations;
using Abp.Auditing;

namespace Pwc.vProfile.WebLogin.Models.Account
{
    public class LoginModel
    {
        [Required(ErrorMessage = "请输入登录名")]
        public String LoginName { get; set; }

        [Required(ErrorMessage = "请输入密码")]
        [DisableAuditing]
        public String Password { get; set; }

        /// <summary>
        /// 登录方式
        /// </summary>
        public string Type { get; set; }
    }
}
