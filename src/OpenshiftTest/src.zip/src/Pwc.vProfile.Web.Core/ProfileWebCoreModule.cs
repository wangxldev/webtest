﻿using System;
using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.AspNetCore.Mvc.ExceptionHandling;
using Abp.AspNetCore.Mvc.Results;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Pwc.vProfile.Utility;

namespace Pwc.vProfile.Web.Core
{
    [DependsOn(
        typeof(AbpAspNetCoreModule),
        typeof(ProfileUtilityModule)
    )]
    public class ProfileWebCoreModule:AbpModule
    {
        public override void PreInitialize()
        {
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(ProfileWebCoreModule).GetAssembly());
        }
    }
}
