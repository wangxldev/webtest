﻿using Abp.Domain.Entities;
using MongoDB.Bson;
using MongoDB.Driver;

namespace Pwc.vProfile.Data
{
    public interface IProfileDbContext: IMongoDbContext
    {
    }
}
