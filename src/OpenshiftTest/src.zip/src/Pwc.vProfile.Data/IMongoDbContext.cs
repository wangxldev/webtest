﻿using System;
using System.Collections.Generic;
using System.Text;
using Abp.Domain.Entities;
using MongoDB.Bson;
using MongoDB.Driver;

namespace Pwc.vProfile.Data
{
    public interface IMongoDbContext
    {
        /// <summary>
        /// 具体的表连接器
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        IMongoCollection<T> DbSet<T>() where T : IEntity<ObjectId>;

        /// <summary>
        /// 通过collectionName来获取IMongoCollection对象
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collectionName"></param>
        /// <returns></returns>
        IMongoCollection<T> DbSet<T>(string collectionName) where T : IEntity<ObjectId>;
    }
}
