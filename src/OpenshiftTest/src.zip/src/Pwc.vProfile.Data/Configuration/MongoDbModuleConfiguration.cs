﻿namespace Pwc.vProfile.Data.Configuration
{
    public class MongoDbModuleConfiguration:IMongoDbModuleConfiguration
    {
        public string ConnectionString { get; set; }
        public string DatatabaseName { get; set; }
    }
}
