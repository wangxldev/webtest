﻿namespace Pwc.vProfile.Data.Configuration
{
    public interface IMongoDbModuleConfiguration
    {
        string ConnectionString { get; set; }

        string DatatabaseName { get; set; }
    }
}
