﻿using System.Reflection;
using Abp;
using Abp.Modules;
using Pwc.vProfile.Data.Configuration;
using Pwc.vProfile.Data.TenantDb;

namespace Pwc.vProfile.Data
{
    [DependsOn(typeof(AbpKernelModule))]
    public class ProfileDataModule:AbpModule
    {
        public override void PreInitialize()
        {
            IocManager.Register<IMongoDbModuleConfiguration, MongoDbModuleConfiguration>();
            IocManager.Register<IProfileDbContext, ProfileDbContext>();
            IocManager.Register<ITenantDbContext, TenantDb.TenantDbContext>();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
        }
    }
}
