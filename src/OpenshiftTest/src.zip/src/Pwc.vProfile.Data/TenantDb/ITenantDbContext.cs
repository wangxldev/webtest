﻿using Abp.Domain.Entities;
using MongoDB.Bson;
using MongoDB.Driver;

namespace Pwc.vProfile.Data.TenantDb
{
    public interface ITenantDbContext: IMongoDbContext
    {

    }
}
