﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities;
using Castle.Core.Internal;
using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Data.Configuration;

namespace Pwc.vProfile.Data.TenantDb
{
    public class TenantDbContext: ITenantDbContext
    {
        private IMongoDbModuleConfiguration Configuration { get; }

        private IMongoDatabase Database { get; }

        /// <summary>
        /// 可读写实例
        /// </summary>
        private MongoClient Client { get; }

        /// <summary>
        /// 只读实例
        /// </summary>
        private MongoClient Readonly { get; }

        public TenantDbContext(IConfiguration config)
        {
            //            Configuration = configuration;
            //            Client=new MongoClient(Configuration.ConnectionString);
            //            Database = Client.GetDatabase(Configuration.DatatabaseName);

            var connStr =
                String.Format(
                    "mongodb://Admin:{0}@HKDBSDWV002:29031,HKDBSDWV002:29032,HKDBSDWV002:29033?replicaSet=rs_ExceedNotes_DEV&readPreference=primaryPreferred",
                    "pass1234");

            Client = new MongoClient(connStr);
            Database = Client.GetDatabase("Tenant01");
        }

        public IMongoCollection<T> DbSet<T>() where T : IEntity<ObjectId>
        {
            return Database.GetCollection<T>(GetTableName(typeof(T)));
        }

        public IMongoCollection<T> DbSet<T>(string collectionName) where T : IEntity<ObjectId>
        {
            return Database.GetCollection<T>(collectionName);
        }

        /// <summary>
        /// 获取表名称
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private String GetTableName(Type type)
        {
            var tableName = type.GetAttribute<TableAttribute>()?.Name;

            if (String.IsNullOrWhiteSpace(tableName))
            {
                tableName = type.Name;
            }

            return tableName;
        }
    }
}
