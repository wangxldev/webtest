﻿using Nito.AsyncEx.Synchronous;
using Pwc.vProfile.Data.Seed.Tenants;
using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Data.Seed
{
    public static class SeedHelper
    {
        public static void SeedTenantDb(string connectString, string dbName)
        {
            // Host seed
            new TenantBuilder(connectString, dbName).Create().WaitAndUnwrapException(); ;
        }
    }
}
