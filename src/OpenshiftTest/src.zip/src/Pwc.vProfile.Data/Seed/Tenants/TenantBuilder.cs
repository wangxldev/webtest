﻿using MongoDB.Bson;
using MongoDB.Driver;
using Nito.AsyncEx.Synchronous;
using Pwc.vProfile.Utility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Pwc.vProfile.Data.Seed.Tenants
{
    public class TenantBuilder
    {
        private readonly string _connectString;
        private readonly string _dbName;

        public TenantBuilder(string connectString,string dbName)
        {
            _connectString = connectString;
            _dbName = dbName;
        }

        public async Task  Create()
        {
            //var task = CreateTenantDb();
            //task.WaitAndUnwrapException();
            await CreateTenantDbAsync();
        }
        private async Task CreateTenantDbAsync()
        {
            //tenant
            //take database name from connection string
            //var _databaseName = MongoUrl.Create(_connectString).DatabaseName;
            var _client = new MongoClient(_connectString);
            var db = _client.GetDatabase(_dbName);
            db.CreateCollection("dummy_collection");

            //create user

            // Construct the write concern
            var writeConcern = WriteConcern.WMajority
                .With(wTimeout: TimeSpan.FromMilliseconds(25000));

            // Construct the createUser command.
            var defaultAdmin = string.Format("{0}_{1}", _dbName, TenantDefault.Admin);
            var defaultPassword = RandomGenerator.RandomStringByText(_dbName, TenantDefault.PasswordLength); ;// RandomGenerator.RandomString(8);
            var command = new BsonDocument
            {
                { "createUser", defaultAdmin },
                //{ "pwd", TenantDefault.Password },
                { "pwd",defaultPassword},
                { "roles", new BsonArray
                    {
                        new BsonDocument
                        {
                            { "role", "dbOwner" },
                            { "db", _dbName }
                        },
                        new BsonDocument
                        {
                            { "role", "readAnyDatabase" },
                            { "db", "admin" }
                        },
                        new BsonDocument
                        {
                            { "role", "read" },
                            { "db", "local" }
                        }
                    }
                }
                //,{ "writeConcern", writeConcern.ToBsonDocument() }
            };
            await db.RunCommandAsync<BsonDocument>(command);

            await CreateDbAdminUserAsync();
 
        }

        private async Task CreateDbAdminUserAsync()
        {
            var _client = new MongoClient(_connectString);
            var db = _client.GetDatabase("admin");

            //list user
            var defaultAdmin = string.Format("{0}_{1}", _dbName, TenantDefault.Admin);
            var defaultPassword = RandomGenerator.RandomStringByText(_dbName, TenantDefault.PasswordLength);
            var commandUserInfo = new BsonDocument("usersInfo", defaultAdmin);
            var user= db.RunCommand<BsonDocument>(commandUserInfo);
            var userArray = user.GetValue("users").AsBsonArray ;
            if (userArray.Count>0)
            {
                //update
                var rolesArray=userArray[0].ToBsonDocument().GetValue("roles").AsBsonArray;
                var commandUpdate = new BsonDocument
                {
                    { "updateUser", defaultAdmin },
                    { "roles", rolesArray.Add(
                        new BsonDocument
                        {
                            { "role", "dbOwner" },
                            { "db", _dbName }
                        })
                    }
                };
                await db.RunCommandAsync<BsonDocument>(commandUpdate);
                return;
            }

            // Construct the write concern
            var writeConcern = WriteConcern.WMajority
                .With(wTimeout: TimeSpan.FromMilliseconds(25000));

            // Construct the createUser command.
            var command = new BsonDocument
            {
                { "createUser", defaultAdmin },
                { "pwd", defaultPassword },
                { "roles", new BsonArray
                    {
                        new BsonDocument
                        {
                            { "role", "dbOwner" },
                            { "db", _dbName }
                        },
                        new BsonDocument
                        {
                            { "role", "readAnyDatabase" },
                            { "db", "admin" }
                        }
                    }
                }
                //,{ "writeConcern", writeConcern.ToBsonDocument() }
            };
            await db.RunCommandAsync<BsonDocument>(command);
        }
 
 
    }
}
