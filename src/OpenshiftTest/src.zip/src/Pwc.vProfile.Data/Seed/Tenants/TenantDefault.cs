﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.vProfile.Data.Seed.Tenants
{
    public static class TenantDefault
    {
        public const string Admin = "Admin";
        public const string Password = "pass1234";
        public const int PasswordLength = 8;
    }
}
