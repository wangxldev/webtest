﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Dependency;
using Abp.Domain.Entities;
 
using Castle.Core.Internal;
using MongoDB.Bson;
using MongoDB.Driver;
using Pwc.vProfile.Data.Configuration;
using Microsoft.Extensions.Configuration;

namespace Pwc.vProfile.Data
{
    public class ProfileDbContext: IProfileDbContext,ITransientDependency
    {
        private IMongoDbModuleConfiguration Configuration { get; }

        private IMongoDatabase Database { get; }

        private MongoClient Client { get; }

        public ProfileDbContext(IConfiguration config)
        {
            //            Configuration = configuration;
            //            Client=new MongoClient(Configuration.ConnectionString);
            //            Database = Client.GetDatabase(Configuration.DatatabaseName);

            var connStr =
                String.Format(
                    "mongodb://siteRootAdmin:{0}@HKDBSDWV002:29031,HKDBSDWV002:29032,HKDBSDWV002:29033?Connect=ReplicaSet",
                    "pass1234");

            Client = new MongoClient(connStr);
            Database = Client.GetDatabase("vProfile2019");
        }

        public IMongoCollection<T> DbSet<T>() where T : IEntity<ObjectId>
        {
            return Database.GetCollection<T>(GetTableName(typeof(T)));
        }

        public IMongoCollection<T> DbSet<T>(string collectionName) where T : IEntity<ObjectId>
        {
            return Database.GetCollection<T>(collectionName);
        }

        /// <summary>
        /// 获取表名称
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private String GetTableName(Type type)
        {
            var tableName = type.GetAttribute<TableAttribute>()?.Name;

            if (String.IsNullOrWhiteSpace(tableName))
            {
                tableName = type.Name;
            }

            return tableName;
        }
    }
}
