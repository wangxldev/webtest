﻿using System;

namespace Pwc.HttpTracer.NLog
{
    public static class HttpTracerBuilderExtensions
    {
        public static HttpTracerBuilder AddNLogWriter(this HttpTracerBuilder builder,Action<HttpTracerNLogOptions> action = null)
        {
            HttpTracerNLogOptions options=new HttpTracerNLogOptions();

            action?.Invoke(options);

            builder.Options.WriterProviders.AddProvider(new HttpTraceNLogWriter(options));

            return builder;
        }
    }
}
