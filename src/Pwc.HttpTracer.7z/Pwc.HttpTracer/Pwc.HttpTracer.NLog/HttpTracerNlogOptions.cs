﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.HttpTracer.NLog
{
    public class HttpTracerNLogOptions
    {
        public string LogInstanceName { get; set; } = "HttpTraceNLogWriter";
    }
}
