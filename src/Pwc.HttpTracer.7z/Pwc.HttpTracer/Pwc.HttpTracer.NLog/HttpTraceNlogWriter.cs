﻿using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NLog;
using Pwc.HttpTracer.Entities;
using Pwc.HttpTracer.Providers;

namespace Pwc.HttpTracer.NLog
{
    public class HttpTraceNLogWriter : IHttpTraceWriter
    {
        private readonly ILogger _log;
        private readonly HttpTracerNLogOptions _options;

        public HttpTraceNLogWriter(HttpTracerNLogOptions options)
        {
            _options = options;
            _log = LogManager.GetLogger(_options.LogInstanceName);
        }

        public string Name { get; set; } = "HttpTraceNLogWriter";

        public Task Write(HttpTraceContext context,TraceLog traceLog)
        {
            _log.Info(JsonConvert.SerializeObject(traceLog));

            return Task.CompletedTask;
        }
    }
}
