﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using NLog;
using Pwc.HttpTracer.Extensions;
using Pwc.HttpTracer.Mvc.Demo.Models;

namespace Pwc.HttpTracer.Mvc.Demo.Controllers
{
    public class HomeController : Controller
    {
        private readonly HttpTraceContext _traceContext;

        public HomeController(HttpTraceContext traceContext)
        {
            _traceContext = traceContext;
        }

        public IActionResult Index()
        {
            _traceContext.AddBussLog(buss:"UserManager",action:"Add","Add User","User", extend: new Dictionary<string, object>()
            {
                { "UserId","10001"},
                { "UserName","Roy"}
            });

            return View();
        }
        private readonly ILogger _logger = LogManager.GetLogger("default");
        public int Calculator(string id, string name)
        {
            var a = 1; var b = 0;

            try
            {
                var c = a / b;
            }
            catch (Exception e)
            {
                _traceContext.ManualTraceException(e);
            }

            return 0;
        }

        public IActionResult Privacy()
        {
            return View();
        }


        [HttpPost]
        public int Post1(Student student)
        {
            var a = 1; var b = 0;

            return a / b;
        }

        [HttpPost]
        public int Post2([FromBody]Student student)
        {
            var a = 1; var b = 0;

            return a / b;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }

    public class Student
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}
