﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NLog.Web;
using Pwc.HttpTracer.Extensions;
using Pwc.HttpTracer.Mongodb;
using Pwc.HttpTracer.NLog;

namespace Pwc.HttpTracer.WebApi.Demo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            services.AddHttpTracer(options =>
                {
                    options.AppName = "HttpTracer";
                })
//                .AddMongodbWriter(options =>
//                {
//                    var connStr =
//                        $"mongodb://Admin:{"pass1234"}@HKDBSDWV002:29031,HKDBSDWV002:29032,HKDBSDWV002:29033?replicaSet=rs_ExceedNotes_DEV&readPreference=primaryPreferred";
//                    options.ConnectionString = connStr;
//                    options.DbName = "Tenant01";
//
//                })
                .AddNLogWriter(options =>
                {
                
                })
                ;
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            env.ConfigureNLog("NLog.config");

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            // Http Tracer
            app.UseHttpTracer();

            app.UseHttpsRedirection();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
