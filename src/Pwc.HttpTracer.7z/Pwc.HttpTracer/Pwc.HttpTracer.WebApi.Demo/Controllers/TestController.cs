﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Pwc.HttpTracer.WebApi.Demo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly HttpTraceContext _traceContext;

        public TestController(HttpTraceContext traceContext)
        {
            _traceContext = traceContext;
        }

        [HttpGet("get1")]
        public Task Get1(string id,string name)
        {
            var x = 1; var y = 0;

            var result = x / y;

            return Task.CompletedTask;
        }

        [HttpPost("post1")]
        public Task Post1([FromBody]Student student)
        {
            var x = 1;var y = 0;

            var result = x / y;

            return Task.CompletedTask;
        }
    }

    public class Student
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}