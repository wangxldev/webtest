﻿namespace Pwc.HttpTracer.Mongodb
{
    public class HttpTracerMongodbOptions
    {
        /// <summary>
        /// 连接字符串
        /// </summary>
        public string ConnectionString { get; set; }

        /// <summary>
        /// 数据库名称
        /// </summary>
        public string DbName { get; set; }

        /// <summary>
        /// collection名
        /// </summary>
        public string Collection { get; set; } = "HttpTracerLogs";
    }
}
