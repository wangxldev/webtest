﻿using System;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using Newtonsoft.Json;
using Pwc.HttpTracer.Entities;
using Pwc.HttpTracer.Providers;

namespace Pwc.HttpTracer.Mongodb
{
    public class HttpTraceMongodbWriter : IHttpTraceWriter
    {
        private readonly HttpTracerMongodbOptions _options;

        public HttpTraceMongodbWriter(HttpTracerMongodbOptions options)
        {
            _options = options;
        }

        public string Name { get; set; } = "HttpTraceMongodbWriter";

        public async Task Write(HttpTraceContext context,TraceLog traceLog)
        {
            var client = new MongoClient(_options.ConnectionString);
            var db = client.GetDatabase(_options.DbName);
            var collection = db.GetCollection<BsonDocument>(_options.Collection,new MongoCollectionSettings()
            {
                AssignIdOnInsert = false
            });

            var json = JsonConvert.SerializeObject(traceLog);
            var document = BsonDocument.Parse(json);

            try
            {
                await collection.InsertOneAsync(document);
            }
            catch (Exception e)
            {
                throw;
            }

        }
    }
}
