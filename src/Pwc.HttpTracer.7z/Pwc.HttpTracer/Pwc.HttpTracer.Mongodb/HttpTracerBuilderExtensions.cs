﻿using System;

namespace Pwc.HttpTracer.Mongodb
{
    public static class HttpTracerBuilderExtensions
    {
        public static HttpTracerBuilder AddMongodbWriter(this HttpTracerBuilder builder,Action<HttpTracerMongodbOptions> action = null)
        {
            HttpTracerMongodbOptions options=new HttpTracerMongodbOptions();

            action?.Invoke(options);

            builder.Options.WriterProviders.AddProvider(new HttpTraceMongodbWriter(options));

            return builder;
        }
    }
}
