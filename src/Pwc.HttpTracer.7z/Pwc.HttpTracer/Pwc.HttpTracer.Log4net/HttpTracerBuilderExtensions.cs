﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.HttpTracer.Log4net
{
    public static class HttpTracerBuilderExtensions
    {
        public static HttpTracerBuilder AddLog4netWriter(this HttpTracerBuilder builder)
        {
            builder.Options.WriterProviders.AddProvider(new HttpTraceLog4netWriter());

            return builder;
        }
    }
}
