﻿using System.Threading.Tasks;
using log4net;
using log4net.Core;
using Newtonsoft.Json;
using Pwc.HttpTracer.Configuration;
using Pwc.HttpTracer.Entities;
using Pwc.HttpTracer.Providers;

namespace Pwc.HttpTracer.Log4net
{
    public class HttpTraceLog4netWriter : IHttpTraceWriter
    {
        private readonly ILog _log;

        public HttpTraceLog4netWriter()
        {
            _log = LogManager.GetLogger(typeof(HttpTraceLog4netWriter));//获取一个日志记录器

//            _log = LogManager.GetLogger("HttpTraceLog4netWriter", "HttpTracerLog");
        }

        public string Name { get; set; } = "HttpTraceLog4netWriter";

        public Task Write(HttpTraceContext context, TraceLog traceLog)
        {
            _log.Info(message:JsonConvert.SerializeObject(traceLog));

            return Task.CompletedTask;
        }
    }
}
