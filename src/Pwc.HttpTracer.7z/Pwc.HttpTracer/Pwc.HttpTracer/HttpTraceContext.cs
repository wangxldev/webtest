﻿using Microsoft.AspNetCore.Http;
using Pwc.HttpTracer.Entities;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Pwc.HttpTracer.Configuration;

namespace Pwc.HttpTracer
{
    /// <summary>
    /// Http trace 上下文对象
    /// </summary>
    public sealed class HttpTraceContext : IDisposable
    {
        public HttpTraceContext(IHttpContextAccessor httpContextAccessor , IServiceProvider provider)
        {
            ServiceProvider = provider;
            HttpContext = httpContextAccessor.HttpContext;
            Options = provider.GetService<HttpTraceOptions>();
            TraceWorker = new HttpTraceWorker(this);
        }

        #region Properties

        /// <summary>
        /// 当前请求上下文对象
        /// </summary>
        public HttpContext HttpContext { get; }

        /// <summary>
        /// IServiceProvider 引用
        /// </summary>
        internal IServiceProvider ServiceProvider { get; }

        /// <summary>
        /// HttpTraceOptions
        /// </summary>
        internal HttpTraceOptions Options { get; }

        /// <summary>
        /// 请求追踪对象
        /// </summary>
        internal HttpTraceWorker TraceWorker { get; }

        /// <summary>
        /// 请求日志对象
        /// </summary>
        internal TraceLog TraceLog => TraceWorker.TracerLog;

        #endregion

        internal async Task TraceAsync(Exception exception=null)
        {
            await TraceWorker.TraceAsync(exception);
        }

        /// <summary>
        /// 手动捕获异常信息
        /// </summary>
        /// <param name="code">错误编码</param>
        /// <param name="exception">异常类型,该参数不能为空</param>
        public void ManualTraceException(Exception exception,string code=null)
        {
            if (exception == null)
            {
                throw new ArgumentNullException(nameof(exception));
            }

#pragma warning disable 4014
            TraceWorker.TraceError(exception,code);
#pragma warning restore 4014
        }

        #region public

        /// <summary>
        /// 添加自定义日志 字段
        /// </summary>
        /// <param name="key">key</param>
        /// <param name="value">value</param>
        public void AddExtend(String key, String value)
        {
            this.TraceLog.Extend.Add(key,value);
        }

        /// <summary>
        /// 添加自定义操作日志
        /// </summary>
        /// <param name="buss">业务模块</param>
        /// <param name="action">操作</param>
        /// <param name="desc">日志描述</param>
        /// <param name="tag">自定义tag,用于筛选</param>
        /// <param name="extend"></param>
        public void AddBussLog(String buss=null, string action=null,String desc=null, String tag = null, Dictionary<String, Object> extend = null)
        {
            TraceLog.BussLogs.Add(new BussLog()
            {
                Buss = buss,
                Desc = desc,
                Action = action,
                Tag = tag,
                Extend = extend
            });
        }

        /// <summary>
        /// 获取操作日志集合
        /// </summary>
        /// <returns></returns>
        public List<BussLog> GetBussLogs()
        {
            return this.TraceLog.BussLogs;
        }

        #endregion

        public void Dispose()
        {

        }
    }
}
