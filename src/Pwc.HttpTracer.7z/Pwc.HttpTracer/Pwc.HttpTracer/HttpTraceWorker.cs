﻿using Microsoft.AspNetCore.Http;
using Pwc.HttpTracer.Entities;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using Pwc.HttpTracer.Configuration;

namespace Pwc.HttpTracer
{
    public class HttpTraceWorker
    {
        private DateTime _begin = DateTime.Now;
        private readonly HttpTraceContext _traceContext;

        public HttpTraceWorker(HttpTraceContext httpTraceContext)
        {
            _traceContext = httpTraceContext;

            TracerLog = new TraceLog()
            {
                AppName = _traceContext.Options.AppName,
                AppVersion = _traceContext.Options.AppVersion,
                HostName = _traceContext.Options.HostName
            };
        }

        public TraceLog TracerLog { get; }

        /// <summary>
        /// 结束追踪
        /// </summary>
        internal async Task TraceAsync(Exception exception = null)
        {
            var httpContext = _traceContext.HttpContext;

            // 优先级计算时间
            TracerLog.Duration = (DateTime.Now-_begin).Milliseconds;

            TracerLog.TraceId = httpContext.TraceIdentifier;
            TracerLog.Ip = httpContext.Connection.RemoteIpAddress.ToString();

            // 获取Request日志
            TracerLog.Request = GetRequestLog(httpContext);
            // 获取Response日志
            TracerLog.Response = GetResponseLog(httpContext);

            var user = httpContext.User;
            if (user != null && user.Identity != null)
            {
            }

            if (exception != null)
            {
                var baseException = exception.GetBaseException();

                TracerLog.Error=new ErrorInfo()
                {
                    ExceptionType = baseException.GetType().Name,
                    Message = baseException.Message,
                    Details = baseException.StackTrace
                };

                // 在系统出错时,记录request数据,这里判断是针对于GET和POST请求,但是并没用Method=GET OR POST的方式,以保持最大的兼容性
                TracerLog.Request.Data = GetRequestData(httpContext);

                TracerLog.Response.Status = 500;
            }

            _traceContext.Options.WriterProviders?.Write(_traceContext);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="code"></param>
        /// <param name="exception"></param>
        /// <returns></returns>
        internal void TraceError(Exception exception, string code = null)
        {
            var httpContext = _traceContext.HttpContext;
            var baseException = exception.GetBaseException();

            TracerLog.Error = new ErrorInfo()
            {
                IsManual = true,
                ExceptionType = baseException.GetType().Name,
                Code = code,
                Message = baseException.Message,
                Details = baseException.StackTrace
            };

            // 在系统出错时,记录request数据,这里判断是针对于GET和POST请求,但是并没用Method=GET OR POST的方式,以保持最大的兼容性
            TracerLog.Request.Data = GetRequestData(httpContext);
        }

        #region Private

        /// <summary>
        /// 获取Request日志
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        private RequestLog GetRequestLog(HttpContext context)
        {
            var request = context.Request;

            var log = new RequestLog
            {
                Browser = request.Headers["User-Agent"].ToString(),
                Url = request.GetDisplayUrl(),
                UrlReferrer = request.Headers["Referer"].ToString(),
                Method = request.Method,
                IsAjax = request.Headers["X-Requested-With"] == "XMLHttpRequest",
                IsHttps = request.IsHttps,
                ContentLength = request.ContentLength?.ToString(),
                ContentType = request.ContentType
            };

            var routeData = context.GetRouteData();
            if (routeData != null && routeData.Values.Count > 0)
            {
                log.Controller = routeData.Values["controller"]?.ToString();
                log.Action = routeData.Values["action"]?.ToString();
            }

            return log;
        }

        /// <summary>
        /// 获取Response日志
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        private ResponseLog GetResponseLog(HttpContext context)
        {
            var response = context.Response;

            var log = new ResponseLog
            {
                Status = response.StatusCode,
                ContentType = response.ContentType,
                ContentLength = response.ContentLength?.ToString()
            };

            return log;
        }

        /// <summary>
        /// 获取请求数据
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        private object GetRequestData(HttpContext context)
        {
            object data = null;
            if (context.Request.Method.Equals("POST", StringComparison.OrdinalIgnoreCase))
            {
                // x-www-form-urlencoded
                if (context.Request.HasFormContentType)
                {
                    data = context.Request.Form?.ToDictionary(pair => pair.Key, pair => pair.Value.ToString());
                }
                // 获取json post数据
                else if (context.Request.ContentType.Equals("application/json", StringComparison.OrdinalIgnoreCase))
                {
                    if (context.Request.Body.CanRead && context.Request.Body.CanSeek)
                    {
                        context.Request.Body.Seek(0,SeekOrigin.Begin);
                    }

                    var reader = new StreamReader(context.Request.Body, Encoding.UTF8);
                    try
                    {
                        data = JsonConvert.DeserializeObject(reader.ReadToEnd());
                    }
                    catch (Exception e)
                    {
                        data = e.GetBaseException().Message;
                    }
                    finally
                    {
                        reader.Dispose();
                    }
                }
            }

            if (context.Request.QueryString.HasValue)
            {
                data = context.Request.Query?.ToDictionary(pair => pair.Key, pair => pair.Value.ToString());
            }

            return data;
        }

        #endregion
    }
}
