﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;

namespace Pwc.HttpTracer
{
    public sealed class HttpTraceHelper
    {
        /// <summary>
        /// 获取请求的Ip
        /// </summary>
        /// <returns></returns>
        public static string GetIp(HttpContext context)
        {
            return context.Connection.RemoteIpAddress.ToString();
        }

        /// <summary>
        /// 获取Agent信息
        /// </summary>
        /// <returns></returns>
        public static string GetBrowser(HttpContext context)
        {
            return context.Request.Headers["User-Agent"].ToString();
        }

        /// <summary>
        /// 获取url path
        /// </summary>
        /// <returns></returns>
        public static string GetUrl(HttpContext context)
        {
            return context.Request.GetDisplayUrl();
        }

        /// <summary>
        /// 获取前一个url
        /// </summary>
        /// <returns></returns>
        public static string GetUrlReferrer(HttpContext context)
        {
            return context.Request.Headers["Referer"].ToString();
        }

        /// <summary>
        /// 获取前一个url
        /// </summary>
        /// <returns></returns>
        public static string GetHttpMethod(HttpContext context)
        {
            return context.Request.Method;
        }

        public static bool GetIsAjax(HttpContext context)
        {
            return context.Request.Headers["X-Requested-With"] == "XMLHttpRequest";
        }
    }
}
