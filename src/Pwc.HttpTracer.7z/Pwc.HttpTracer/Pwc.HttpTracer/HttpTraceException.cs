﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Pwc.HttpTracer
{
    public class HttpTraceException:Exception
    {
        public HttpTraceException(SerializationInfo serializationInfo, StreamingContext context)
            : base(serializationInfo, context)
        {

        }

        public HttpTraceException(string message)
            : base(message)
        {

        }

        public HttpTraceException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}
