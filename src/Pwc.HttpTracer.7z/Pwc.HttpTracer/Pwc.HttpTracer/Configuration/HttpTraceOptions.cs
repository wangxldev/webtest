﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using Pwc.HttpTracer.Providers;
using System.Reflection;

namespace Pwc.HttpTracer.Configuration
{
    public class HttpTraceOptions
    {
        public HttpTraceOptions()
        {
            WriterProviders = new HttpTraceWriterProviders();

            var app = new Microsoft.Extensions.PlatformAbstractions.ApplicationEnvironment();
            AppName = app.ApplicationName;
            AppVersion = app.ApplicationVersion;
            HostName = Environment.MachineName;
        }

        /// <summary>
        /// 格式化输出提供器
        /// </summary>
        public HttpTraceWriterProviders WriterProviders { get; }

        /// <summary>
        /// 是否启用追踪日志
        /// </summary>
        public bool Enabled { get; set; } = true;

        /// <summary>
        /// 应用程序名称,默认为项目应用程序名
        /// </summary>
        public string AppName { get; set; }

        /// <summary>
        /// 程序版本
        /// </summary>
        public string AppVersion { get; set; }

        /// <summary>
        /// 当前服务器名称
        /// </summary>
        public string HostName { get; set; }

        /// <summary>
        /// 用来过滤是否要追踪Http请求,返回 true表示监听当前请求,false表示忽略,不会Tracer
        /// </summary>
        public Func<HttpTraceContext,bool> HttpTraceFilter { get; set; }



        #region Private



        #endregion
    }
}
