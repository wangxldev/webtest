﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Pwc.HttpTracer.Configuration;
using Pwc.HttpTracer.Providers;

namespace Pwc.HttpTracer.Extensions
{
    public static class HttpTraceServiceCollectionExtensions
    {
        public static HttpTracerBuilder AddHttpTracer(this IServiceCollection services, Action<HttpTraceOptions> action=null)
        {
            //            services.Configure<MvcOptions>(mvcOptions =>
            //            {
            //                mvcOptions.Add(services);
            //            });



           var builder = new HttpTracerBuilder(services);

           services.AddSingleton<HttpTracerBuilder>(builder);

            builder.AddHttpTracer(action);

            return builder;
        }
    }
}



