﻿using System;
using Microsoft.AspNetCore.Builder;
using Pwc.HttpTracer.Configuration;

namespace Pwc.HttpTracer.Extensions
{
    public static class HttpTraceMiddlewareExtensions
    {
        public static IApplicationBuilder UseHttpTracer(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<HttpTraceMiddleware>();
        }
    }
}
