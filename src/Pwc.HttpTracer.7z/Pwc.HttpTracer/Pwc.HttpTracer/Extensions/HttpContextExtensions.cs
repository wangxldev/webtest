﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace Pwc.HttpTracer.Extensions
{
    public static class HttpContextExtensions
    {
//        internal const string HttpTraceContextKey = "HttpTraceContextKey";
//
//        internal static void SetHttpTraceContext(this HttpContext context, HttpTraceContext traceContext)
//        {
//            if (!context.Items.ContainsKey(HttpTraceContextKey))
//            {
//                context.Items.Add(HttpTraceContextKey,traceContext);
//            }
//        }
//
//        public static HttpTraceContext GetHttpTraceContext(this HttpContext context)
//        {
//            if (context.Items.ContainsKey(HttpTraceContextKey))
//            {
//                var traceContext = context.Items[HttpTraceContextKey] as HttpTraceContext;
//                return traceContext;
//            }
//
//            return null;
//        }
    }
}
