﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.HttpTracer.Entities
{
    [Serializable]
    public class BussLog
    {
        public BussLog()
        {
            //ServerIPAddress = RequestLogConfiguration.LogConfig.LocalIp;
        }

        /// <summary>
        /// 业务模块
        /// </summary>
        [JsonProperty("buss")]
        public string Buss { get; set; }

        /// <summary>
        /// 操作名称
        /// </summary>
        [JsonProperty("action")]
        public string Action { get; set; }

        [JsonProperty("desc")]
        public string Desc { get; set; }

        /// <summary>
        /// 操作标签
        /// </summary>
        [JsonProperty("tag")]
        public string Tag { get; set; }

        /// <summary>
        /// 自定义数据
        /// </summary>
        [JsonExtensionData]
        [JsonProperty("extend")]
        public Dictionary<String, Object> Extend { get; set; }
    }
}
