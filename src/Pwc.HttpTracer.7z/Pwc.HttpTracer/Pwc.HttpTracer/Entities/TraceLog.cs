﻿using Newtonsoft.Json;
using Pwc.HttpTracer.Configuration;
using System;
using System.Collections.Generic;

namespace Pwc.HttpTracer.Entities
{
    /// <summary>
    /// 请求日志数据
    /// </summary>
    [Serializable]
    public class TraceLog
    {
        [JsonProperty("version")]
        public String Version { get; internal set; } = "1.0";

        /// <summary>
        /// 追踪请求的唯一标示
        /// </summary>
        [JsonProperty("traceId")]
        public string TraceId { get; internal set; }

        /// <summary>
        /// 日志时间
        /// </summary>
        [JsonProperty("time")]
        public DateTime LogTime { get; internal set; } = DateTime.Now;

        /// <summary>
        /// 应用程序名称
        /// </summary>
        [JsonProperty("appName")]
        public string AppName { get; set; }

        /// <summary>
        /// 程序版本
        /// </summary>
        [JsonProperty("appVersion")]
        public string AppVersion { get; set; }

        /// <summary>
        /// 用户Id
        /// </summary>
        [JsonProperty("userId")]
        public String UserId { get; internal set; }

        /// <summary>
        /// 用户Name
        /// </summary>
        [JsonProperty("userName")]
        public String UserName { get; internal set; }

        /// <summary>
        /// 服务器名称
        /// </summary>
        [JsonProperty("host")]
        public String HostName { get; internal set; }

        /// <summary>
        /// Ip地址
        /// </summary>
        [JsonProperty("ip")]
        public string Ip { get; internal set; }

        /// <summary>
        /// 请求信息
        /// </summary>
        [JsonProperty("request")]
        public RequestLog Request { get; internal set; } = new RequestLog();

        /// <summary>
        /// 返回信息
        /// </summary>
        [JsonProperty("response")]
        public ResponseLog Response { get; internal set; } = new ResponseLog();

        /// <summary>
        /// 执行时间,单位:毫秒
        /// </summary>
        [JsonProperty("duration")]
        public Int64 Duration { get; internal set; }

        /// <summary>
        /// 异常信息
        /// </summary>
        [JsonProperty("error")]
        public ErrorInfo Error { get; internal set; }

        /// <summary>
        /// 业务日志记录
        /// </summary>
        [JsonProperty("buss")]
        internal List<BussLog> BussLogs { get; set; } = new List<BussLog>();

        /// <summary>
        /// 用户自定义数据
        /// </summary>
//        [JsonExtensionData]
        [JsonProperty("extend")]
        internal Dictionary<String, Object> Extend { get; } = new Dictionary<String, Object>();
    }
}
