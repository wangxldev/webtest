﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Pwc.HttpTracer.Entities
{
    [Serializable]
    public class ResponseLog
    {
        /// <summary>
        /// 请求的ContentType
        /// </summary>
        [JsonProperty("contentType")]
        public string ContentType { get; set; }

        /// <summary>
        /// 消息长度
        /// </summary>
        [JsonProperty("contentLength")]
        public string ContentLength { get; set; }

        /// <summary>
        /// http状态码
        /// </summary>
        [JsonProperty("status")]
        public Int32 Status { get; set; }
    }
}
