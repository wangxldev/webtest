﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Pwc.HttpTracer.Entities
{
    [Serializable]
    public class RequestLog
    {
        /// <summary>
        ///     浏览器信息
        /// </summary>
        [JsonProperty("browser")]
        public string Browser { get; set; }

        /// <summary>
        ///  访客访问的Url
        /// </summary>
        [JsonProperty("url")]
        public string Url { get; set; }

        /// <summary>
        /// 前一个链接
        /// </summary>
        [JsonProperty("referrer")]
        public String UrlReferrer { get; set; }

        /// <summary>
        /// Controller名称
        /// </summary>
        [JsonProperty("controller")]
        public String Controller { get; set; }

        /// <summary>
        /// Action名称
        /// </summary>
        [JsonProperty("action")]
        public String Action { get; set; }

        /// <summary>
        /// 请求的类型
        /// </summary>
        [JsonProperty("method")]
        public String Method { get; set; }

        /// <summary>
        /// 请求数据,对于Get请求,该值等于Query,对于POST请求,该值等于Form
        /// </summary>
        [JsonProperty("data")]
        public object Data { get; set; }

        /// <summary>
        /// 请求的ContentType
        /// </summary>
        [JsonProperty("contentType")]
        public string ContentType { get; set; }

        /// <summary>
        /// 消息长度
        /// </summary>
        [JsonProperty("contentLength")]
        public string ContentLength { get; set; }

        /// <summary>
        /// 判断是否是Ajax请求
        /// </summary>
        [JsonProperty("isAjax")]
        public Boolean IsAjax { get; set; }

        /// <summary>
        /// 是否为https
        /// </summary>
        [JsonProperty("isHttps")]
        public Boolean IsHttps { get; set; }
    }
}
