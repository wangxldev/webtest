﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.HttpTracer.Entities
{
    [Serializable]
    public class ErrorInfo
    {
        /// <summary>
        /// 判断是否为手动捕获异常
        /// </summary>
        [JsonProperty("isManual")]
        internal bool IsManual { get; set; }

        /// <summary>
        /// 错误异常
        /// </summary>
        [JsonProperty("exceptionType")]
        public string ExceptionType { get; set; }

        /// <summary>
        /// 异常code
        /// </summary>
        [JsonProperty("code")]
        public string Code { get; set; }

        /// <summary>
        /// 异常信息
        /// </summary>
        [JsonProperty("message")]
        public string Message { get; set; }

        /// <summary>
        /// 异常详细信息(栈信息)
        /// </summary>
        [JsonProperty("detail")]
        public string Details { get; set; }
    }
}
