﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pwc.HttpTracer
{
    public static class HttpTraceConsts
    {
        public const string Repository = "HttpTracer";

        public const String DefaultLog = "HttpTracer";

        public const String LogInstanceName = "HttpTracer";
    }
}
