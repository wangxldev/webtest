﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Pwc.HttpTracer.Entities;

namespace Pwc.HttpTracer.Providers
{
    public interface IHttpTraceWriter
    {
        /// <summary>
        /// Provider名称
        /// </summary>
        string Name { get; }

        /// <summary>
        /// 记录日志操作
        /// </summary>
        /// <param name="traceContext"></param>
        /// <returns></returns>
        Task Write(HttpTraceContext traceContext,TraceLog traceLog);
    }
}
