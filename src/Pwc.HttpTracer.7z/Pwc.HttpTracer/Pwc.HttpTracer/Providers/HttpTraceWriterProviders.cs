﻿using Pwc.HttpTracer.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;

namespace Pwc.HttpTracer.Providers
{
    public class HttpTraceWriterProviders
    {
        // Provider字典列表 Key:Provider Name  value:provider instance
        internal Dictionary<String, IHttpTraceWriter> Providers = new Dictionary<string, IHttpTraceWriter>();

        internal void Write(HttpTraceContext context)
        {
            foreach (KeyValuePair<String, IHttpTraceWriter> pair in Providers)
            {
                // TODO 异常处理
                pair.Value.Write(context, context.TraceLog);
            }
        }

        public void AddProvider(IHttpTraceWriter provider)
        {
            if (String.IsNullOrWhiteSpace(provider.Name))
            {
                throw new ArgumentException("Provider的ProviderName属性不可为空");
            }
            Providers.Add(provider.Name, provider);
        }

        public void RemoveProvider(String providerName)
        {
            // TODO 可能会产生并发问题
            if (Providers.ContainsKey(providerName))
            {
                Providers.Remove(providerName);
            }
        }

        public IHttpTraceWriter GetProvider(String providerName)
        {
            if (Providers.ContainsKey(providerName))
            {
                return Providers[providerName];
            }

            return null;
        }

        public void Clear()
        {
            Providers.Clear();
        }
    }
}
