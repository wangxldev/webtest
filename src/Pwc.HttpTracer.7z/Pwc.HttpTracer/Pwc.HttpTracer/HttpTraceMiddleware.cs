﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Pwc.HttpTracer.Configuration;
using Pwc.HttpTracer.Extensions;

namespace Pwc.HttpTracer
{
    public class HttpTraceMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly HttpTraceOptions _httpTraceOptions;
        private readonly IServiceProvider _serviceProvider;

        public HttpTraceMiddleware(RequestDelegate next, HttpTraceOptions httpTraceOptions,
            IServiceProvider serviceProvider)
        {
            _next = next;
            _httpTraceOptions = httpTraceOptions;
            _serviceProvider = serviceProvider;
        }

        public async Task InvokeAsync(HttpContext context, HttpTraceContext httpTraceContext)
        {
            if (_httpTraceOptions == null)
            {
                throw new HttpTraceException("HttpTraceOptions Can't be null");
            }

            if (!_httpTraceOptions.Enabled || (_httpTraceOptions.Enabled && _httpTraceOptions.HttpTraceFilter!=null && !_httpTraceOptions.HttpTraceFilter(httpTraceContext)))
            { 
                await _next(context);
            }
            else
            {
                try
                {
                    await _next(context);

#pragma warning disable 4014
                    httpTraceContext.TraceAsync();
#pragma warning restore 4014

                }
                catch (Exception ex)
                {

#pragma warning disable 4014
                    httpTraceContext.TraceAsync(ex);
#pragma warning restore 4014

                    throw;
                }
            }
        }
    }
}