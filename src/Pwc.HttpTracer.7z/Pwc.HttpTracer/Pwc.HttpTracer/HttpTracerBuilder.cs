﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Pwc.HttpTracer.Configuration;

namespace Pwc.HttpTracer
{
    public sealed class HttpTracerBuilder
    {
        public HttpTracerBuilder(IServiceCollection services)
        {
            Services = services;
        }

        public IServiceCollection Services { get; }

        public HttpTraceOptions Options { get; set; }

        public HttpTracerBuilder AddHttpTracer(Action<HttpTraceOptions> action = null)
        {
            Services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            //            services.TryAddSingleton<IActionContextAccessor, ActionContextAccessor>();

            Services.AddScoped<HttpTraceContext>();
            //            services.AddSingleton<HttpTraceWriterProviders>();
            var options = new HttpTraceOptions();
            Services.AddSingleton<HttpTraceOptions>(options);

            action?.Invoke(options);

            Options = options;

            return this;
        }
    }
}
